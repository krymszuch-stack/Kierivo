## Chrome tab 2063916241

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Senior Backend Developer (.NET) (m/f)
Grupa PracujO firmie

ważna jeszcze miesiąc

(do 30 paź)

110,00 – 125,00 zł
netto (+ VAT) / godz. | kontrakt B2B
Prosta 68, Wola, Warszawamazowieckie
kontrakt b2b
starszy specjalista / starsza specjalistka (senior)
praca zdalna
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski, polski
Siedziba firmy

Grupa Pracuj

Prosta 68, Wola, Warszawa

Sprawdź czas dojazdu

Zlokalizuj się lub podaj dokładny adres

Samochód

-

Komunikacja

-

Rower

-

Pieszo

-

Technologie, których używamy
Wymagane
.NET Core
RabbitMQ
MS SQL
C#
.NET 10
Mile widziane
Kubernetes
Azure DevOps
TeamCity
CI/CD
Claude
System operacyjny
O projekcie
Współtworzymy technologię portalu Pracuj.pl z którego korzysta ponad 5 milionów użytkowników i kilkadziesiąt tysięcy firm miesięcznie. To ogromna skala i możliwość bezpośredniego wpływu na największy polski biznes branży HR.
Szukamy osoby na 12-miesięczny projekt do zespołu pracującego nad ekosystemem eCommerce w Pracuj.pl.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjiscrum
Twój zakres obowiązków
Rozwijanie ekosystemu eCommerce w ramach Pracuj.pl
Budowa nowych funkcjonalności w oparciu o architekturę mikroserwisów w technologii .NET
Współopracowywanie rozwiązań od pomysłu do wdrożenia na produkcji
Projektowanie rozwiązań z uwzględnieniem kontekstu biznesowego
Dbałość o jakość i wydajność wypracowanych rozwiązań
Współtworzenie kierunku rozwoju technicznego aplikacji
Współpraca z innymi zespołami w tym z projektantami, architektami, badaczami, biznesem
Przeprowadzanie code review
Pair programming
Nasze wymagania
Posiadasz minimum 5-6+ lat doświadczenia komercyjnego w pracy z C#, .NET core / .NET 6+ (API, konsumenci z MassTransit)
Masz doświadczenie w pracy nad aplikacjami działającymi w środowisku rozproszonym
Znasz technologie związane z relacyjnymi bazami danych (MS SQL/ T-SQL)
Wzorce projektowe oraz zasady SOLID są Ci dobrze znane
Posiadasz doświadczenie w pracy z mikroserwisami (komunikacja synchroniczna i asynchroniczna)
Masz doświadczenie w RabbitMQ
Potrafisz projektować czytelną architekturę aplikacji, z dbałością o logikę domenową oraz zasady czystego kodu
Masz doświadczenie w tworzeniu testów jednostkowych
Potrafisz efektywnie współpracować w zespole i budować pozytywne relacje
Potrafisz świadomie i efektywnie korzystać z agentów kodujących jako wsparcia w codziennej pracy programistycznej
Mile widziane
Masz doświadczenie w pracy TeamCity, Azure DevOps i Kubernetesem
Posiadasz doświadczenie w przeprowadzaniu testów wydajnościowych
Wiesz, kiedy i jak przeprowadzać testy integracyjne
Znajomość CI/CD
Doświadczenie w pracy w metodologii Agile
To oferujemy
Zawieramy kontrakt B2B na 12 miesięcy
Projekt o realnej skali - współpracujesz na produkcie, z którego korzysta ponad 5 milionów użytkowników i kilkadziesiąt tysięcy firm miesięcznie
Tak pracujemy nad projektem
Clean Code
code review
Takie dajemy możliwości rozwoju
wsparcie merytoryczne od liderów technologicznych
wymiana wiedzy technicznej w firmie
Benefity
Elastyczny czas pracy
Brak dress code’u
Etapy rekrutacji
1

20 min rozmowa telefoniczna z Rekruterką

2

Spotkanie techniczne online z Managerem i developerami

Stack Technologiczny
Pracujemy w nowoczesnych technologiach:
Front: React.js, Redux, JavaScript, TypeScript, Next.js
Backend: .Net 6-10 , kubernetes,
Działamy w Azure z bardzo dobrze i sprawnie działającym procesem deploymentu w pełni opartym na AzureDevops
Więcej nt. naszego stacku technologicznego znajdziesz:
https://stackshare.io/grupa-pracuj/pracuj-pl#stack
Jak pracujemy w dziale Product Strategy Development
Tworzymy największy portal rekrutacyjny, z którego korzystają miliony ludzi w Polsce!
Nasze projekty są dobrze przygotowane, a funkcjonalności świetnie udokumentowane.
Badamy, testujemy, eksperymentujemy, czasem popełniamy błędy, na których się uczymy i z których wyciągamy wnioski w ramach After Action Review. Pracujemy agilowo,
Wymiana wiedzy
Regularnie organizujemy wewnętrzne spotkania wymiany wiedzy: Tech Talki i Hackhatony, gdzie nasi Eksperci poruszają tematy nowinek, dobrych praktyk oraz trendów technologicznych. Organizujemy spotkania wewnętrzne i zewnętrzne, na których nasi Ekserpci dzielą się wiedzą i inspiracjami.
Grupa Pracuj
Przewiń do profilu firmy
Grupa Pracuj jest liderem technologii w obszarze HR w Europie Środkowej i Wschodniej.
Wspieramy przedsiębiorstwa m.in. w zakresie rekrutacji, utrzymania i rozwoju Pracowników i Pracowniczek. Ułatwiamy Użytkownikom i Użytkowniczkom naszych serwisów znalezienie zatrudnienia odpowiadającego ich kwalifikacjom i potencjałowi.
Tworzymy światowej klasy technologie, które kształtują przyszłość rynku HR.
Grupa Pracuj działa od ponad 25 lat w Polsce, od 19 lat w Ukrainie, a od czerwca 2022 roku także w regionie DACH (Niemcy, Austria, Szwajcaria), zatrudniając łącznie około 1100 osób.
Od 2021 jesteśmy na Giełdzie Papierów Wartościowych w Warszawie.
Nieustannie się rozwijamy.
W skład Grupy Pracuj wchodzą m.in. największy polski serwis rekrutacyjny Pracuj.pl, serwis the:protocol.it dla branży technologicznej, ukraiński serwis rekrutacyjny Robota.ua, systemy do zarządzania rekrutacjami: polski eRecruiter i niemiecki softgarden, działające w modelu SaaS (software as a service), oraz Kadromierz - nowoczesna platforma do zarządzania czasem pracy.
Tak się u nas pracuje
Aplikuj szybko
Zapisz
Drukuj
Udostępnij

Wszystkie informacje o przetwarzaniu danych osobowych w tej rekrutacji znajdziesz w formularzu aplikacyjnym, po kliknięciu w przycisk "Aplikuj Teraz".

Praca
Warszawa
IT - Administracja
Administrowanie systemami
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
.NET Software Developer Najlepiej dopasowana
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)
Starszy programista .NET/C# (K/M) Hit!
NASK
10 000–16 000 zł brutto / mies.
Warszawa, Wola
Superoferta
Senior .NET Developer (SharePoint/Microsoft 365)
Scalo Sp. z o.o.
150 zł netto (+ VAT) / godz.
Warszawa, Ochota
Superoferta
Senior Full Stack Engineer (C#/.Net And Angular) Śpiesz się!
SQUARE ONE RESOURCES sp. z o.o.
130–150 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Senior .NET Developer
Scalo Sp. z o.o.
140 zł netto (+ VAT) / godz.
Warszawa, Ochota
Fullstack Developer (C# + Angular)
ASTEK Polska
120–137 zł netto (+ VAT) / godz.
Warszawa
Programista .NET / Programistka .NET w Obszarze Rozwoju Systemów Korporacyjnych
Bank Millennium S.A.
Warszawa, Mokotów
Pokaż więcej podobnych
16
Włącz powiadomienie

Senior Backend Developer (.NET) (m/f), Prosta 68, Wola, Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916242

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Starszy programista .NET/C# (K/M)
NASKO firmie

ważna jeszcze 16 dni

(do 16 paź)

10 000 – 16 000 zł
brutto / mies. | umowa o pracę
Stawki 40, Wola, Warszawamazowieckie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular), starszy specjalista / starsza specjalistka (senior)
praca zdalna, praca hybrydowa
praca od zaraz
szukamy wielu kandydatów
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
System wynagrodzeń:
stała podstawa wynagrodzenia + stała premia (np. kwartalna, roczna)
Specjalizacje:
Backend
Siedziba firmy

NASK

Stawki 40, Wola, Warszawa

Sprawdź czas dojazdu

Zlokalizuj się lub podaj dokładny adres

Samochód

-

Komunikacja

-

Rower

-

Pieszo

-

Technologie, których używamy
Wymagane
.NET
C#
PostgreSQL
ASP.NET
UML
BPMN
Twój zakres obowiązków
Projektowanie i implementację nowoczesnych aplikacji informatycznych zgodnie z dostarczoną specyfikacją;
Udział w tworzeniu architektury systemu i wyborze stosu technologicznego;
Tworzenie rozwiązań informatycznych w oparciu o posiadaną wiedzę i doświadczenie ;
Udział w ewaluacji i testowaniu nowych narzędzi i rozwiązań;
Współpracę w ramach zespołów programistycznych.
Nasze wymagania
Wykształcenie wyższe informatyczne lub inne wykształcenie wyższe techniczne;
Minimum 3 lat doświadczenia w tworzeniu oprogramowania;
Praktyczne doświadczenie w budowaniu wysokodostępnych i skalowalnych aplikacji webowych;
Biegła znajomość C# .NET8, w szczególności ASP.NET Core Web API;
Biegła znajomość EF Core;
Dobra znajomość wzorców projektowych tym CQRS oraz zasad programowania asynchronicznego;
Dobra znajomość relacyjnych baz danych (PostgreSql);
Praktyczne doświadczenie z architekturą sterowaną zdarzeniami (Event driven architecture) i systemami kolejkowymi (RabbitMQ);
Umiejętność pracy w środowisku oraz architekturze kontenerowej (docker,kubernetes);
Znajomość zasad Clean Code;
Znajomość notacji C4, UML, BPMN.
Mile widziane
Znajomość zasad bezpiecznego wytwarzania oprogramowania;
Znajomość języka angielskiego na poziomie umożliwiającym analizę dokumentacji technicznej;
Doświadczenie w pracy ze zwinnymi metodykami wytwarzania np. Scrum, SAFe;
Doświadczenie w tworzenie testowalnych, diagnozowalnych i obserwowalnych aplikacji;
Praktyczna wiedza o wpływie architektury aplikacji na nowoczesne procesy CI/CD.
Takie dajemy możliwości rozwoju
budżet rozwojowy
czas na rozwój Twoich pomysłów
konferencje w Polsce
konferencje zagraniczne
przestrzeń do eksperymentowania
szkolenia wewnątrzfirmowe
szkolenia zewnętrzne
wsparcie merytoryczne od liderów technologicznych
wspieramy wydarzenia dla IT
wymiana wiedzy technicznej w firmie
Benefity
Dofinansowanie zajęć sportowych
Prywatna opieka medyczna
Dofinansowanie nauki języków
Dofinansowanie szkoleń i kursów
Ubezpieczenie na życie
Elastyczny czas pracy
Owoce
Spotkania integracyjne
Preferencyjne pożyczki
Firmowa biblioteka
Brak dress code’u
Kawa / herbata
Dodatkowe świadczenia socjalne
Dofinansowanie biletów do kina, teatru
Dofinansowanie wypoczynku
NASK
Przewiń do profilu firmy
Nasz zespół składa się z blisko 40 doświadczonych specjalistów (architekci, analitycy, programiści, testerzy) pracujących nad rozwojem i utrzymaniem systemu EZD RP (https://www.gov.pl/web/ezd-rp).  EZD RP – elektroniczne zarządzanie dokumentacją w administracji publicznej - to ważny i strategiczny projekt (https://www.gov.pl/web/ezd-rp).  
Aktualnie szukamy osoby z dużym doświadczaniem w .Net/C#, która poza obszarem programowania, wesprze nas również w zakresie rozwoju architektury naszego rozwiązania.  
Liczymy na Twoje doświadczenie, świeże spojrzenie oraz ambicję w zakresie prac na techniczną stroną naszego produktu w długofalowej perspektywie.  
Dołącz do naszego zespołu!  
Tak się u nas pracuje
Aplikuj szybko
Zapisz
Drukuj
Udostępnij

Wszystkie informacje o przetwarzaniu danych osobowych w tej rekrutacji znajdziesz w formularzu aplikacyjnym, po kliknięciu w przycisk "Aplikuj Teraz".

Praca
Warszawa
IT - Administracja
Administrowanie systemami
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
Full Stack Developer (.NET / Angular / SQL) Hit!
GOLDENORE ITC sp. z o.o.
Warszawa
Superoferta
.NET Software Developer Najlepiej dopasowana
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
Programista / Programistka C#
ARKUDA Sp. z o.o.
Warszawa, Wola
Programista Java (k/m) (systemy wspomagania dowodzenia)
PIT-RADWAR S.A.
Warszawa, Praga-Południe
Programista Embedded Linux DevOps Engineer (K/M)
WB Electronics S.A.
Ożarów Mazowiecki
Programista / Programistka Full-stack
LUX MED Sp. z o.o.
Warszawa
Pokaż więcej podobnych
16
Włącz powiadomienie

Starszy programista .NET/C# (K/M), Stawki 40, Wola, Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916243

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Senior C# Developer
Xopero Software S.A.O firmie

ważna jeszcze 7 dni

(do 07 paź)

16 600 – 19 500 zł
brutto / mies. | umowa o pracę
20 000 – 23 500 zł
netto (+ VAT) / mies. | kontrakt B2B
Franciszka Walczaka 3, Gorzów Wielkopolskilubuskie
umowa o pracę, kontrakt b2b
pełny etat
starszy specjalista / starsza specjalistka (senior)
praca zdalna
praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
System wynagrodzeń:
stała podstawa wynagrodzenia
Specjalizacje:
Embedded
Wymagane języki:
angielski
Siedziba firmy

Xopero Software S.A.

Franciszka Walczaka 3, Gorzów Wielkopolski

Sprawdź czas dojazdu

Zlokalizuj się lub podaj dokładny adres

Samochód

-

Komunikacja

-

Rower

-

Pieszo

-

Technologie, których używamy
Wymagane
.NET
C#
SQL
Git
Jira
Docker
Mile widziane
Kubernetes
VMware
Hyper-V
S3 Storage
Microsoft 365
SignalR
TeamCity
Android
MacOS
iOS
System operacyjny
O projekcie
Do zespołu R&D szukamy Senior C# Developera, który pomoże nam rozwijać rozwiązania odpowiadające za bezpieczeństwo danych tysięcy organizacji na całym świecie.
Twój zakres obowiązków
✨Będziesz planować, analizować i realizować zadania rozwojowe dla naszych produktów;
✨Zadbasz o utrzymanie oraz rozwój istniejących rozwiązań;
✨Wesprzesz mniej doświadczonych członków zespołu, dzieląc się wiedzą i dobrymi praktykami;
✨Będziesz prowadzić code review oraz dbać o wysoką jakość kodu;
✨Wspólnie z zespołem będziesz rozwijać standardy wytwarzania oprogramowania;
✨Będziesz rozwiązywać złożone problemy techniczne i proponować najlepsze rozwiązania;
✨Przygotujesz testy jednostkowe oraz zadbasz o jakość tworzonych funkcjonalności;
✨Będziesz współtworzyć dokumentację techniczną i projektową;
✨Wesprzesz liderów w podejmowaniu decyzji technologicznych i projektowaniu architektury rozwiązań.
Nasze wymagania
✔ Masz minimum 5 lat doświadczenia w komercyjnym tworzeniu oprogramowania w .NET i C#;
✔ Dobrze znasz zasady programowania obiektowego, w tym SOLID oraz DRY;
✔ Potrafisz stosować wzorce projektowe w praktyce;
✔ Masz doświadczenie w pracy z bazami danych SQL i NoSQL;
✔ Dobrze znasz systemy Windows oraz Linux;
✔ Swobodnie korzystasz z Git, Jira i Docker;
✔ Potrafisz pisać testy jednostkowe.
Mile widziane
✨ Znasz Kubernetes, VMware, Hyper-V, S3 Storage, Microsoft 365, SignalR lub TeamCity;
✨ Masz doświadczenie z systemami Android, iOS lub macOS;
✨ Posiadasz doświadczenie w programowaniu niskopoziomowym.
To oferujemy
Co da Ci więcej spokoju? 🤝
✔ 26 dni płatnego wstrzymania świadczenia usług (B2B);
✔ 10 dni niezdolności do świadczenia usług (B2B);
✔ Niezbędne narzędzia i sprzęt od pierwszego dnia;
✔ Program poleceń pracowniczych.
Co wesprze Twój rozwój? 📚
✔ Budżet szkoleniowy;
✔ Bezpłatne lekcje języka angielskiego;
✔ Wymiana wiedzy z ekspertami cyberbezpieczeństwa, backupu i SaaS;
✔ Udział w projektach rozwijanych globalnie.
Co wesprze Twój wellbeing? 🌿
✔ Prywatna opieka medyczna Luxmed (pakiet już od 1zł);
✔ Dofinansowanie do karty Multisport;
✔ Dzień na U - dodatkowy dzień urlopu z przeznaczeniem na profilaktykę zdrowotną;
✔ Urlop menstruacyjny;
✔ Dofinansowanie do ubezpieczenia na życie.
Co jeszcze? 🚀
✔ Welcome pack;
✔ Xoperosy - coroczna gala wyróżniająca pracowników;
✔ Spotkania integracyjne;
✔ Świąteczne prezenty;
✔ Wyprawka dla dziecka.
Benefity
Dofinansowanie zajęć sportowych
Prywatna opieka medyczna
Dofinansowanie nauki języków
Dofinansowanie szkoleń i kursów
Ubezpieczenie na życie
Spotkania integracyjne
Etapy rekrutacji
1

Rozmowa z rekruterką

2

Spotkanie techniczne

3

Spotkanie z Head’em of Engineering’u - Łukaszem

4

Spotkanie z Dyrektorem Engineeringu i R&D - Pawłem

Xopero Software S.A.
Przewiń do profilu firmy
Cześć, tu Xopero 👋
Od ponad 17 lat pomagamy firmom chronić dane, bez których trudno wyobrazić sobie codzienną pracę. Tworzymy rozwiązania Backup & Disaster Recovery - Xopero ONE, Xopero Unified Protection i GitProtect - które dbają o bezpieczeństwo środowisk IT, aplikacji i repozytoriów kodu na całym świecie.
Być może nie widzisz naszych produktów na co dzień, ale jest duża szansa, że chronią one Twoje dane wtedy, gdy przekazujesz dane logując się do ulubionej aplikacji, robisz zakupy online, korzystasz z bankowości internetowej, czy załatwiasz codzienne sprawy przez internet.
Z naszych rozwiązań korzystają zarówno mniejsze firmy, jak i globalne marki, takie jak T-Mobile, Avis czy Quest Diagnostics.
Aplikuj
Zapisz
Drukuj
Udostępnij
Praca
Gorzów Wielkopolski
IT - Administracja
Administrowanie bazami danych i storage
Aplikuj
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
Senior .NET Developer | Branża bankowa
Edge One Solutions Sp. z o.o.
Warszawa
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
Superoferta
.Net Developer Śpiesz się!
OPTIVEUM SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
120 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Senior .NET Engineer
dotLinkers Sp. z o.o.
32 000 zł brutto / mies.
Warszawa
Superoferta
Full Stack Developer (.NET / Angular / SQL) Hit!
GOLDENORE ITC sp. z o.o.
Warszawa
Software Developer (.NET) (k/m)
Logisystem Sp. z o.o.
Warszawa, Białołęka
Superoferta
Senior Software Engineer (.NET) Śpiesz się!
IT CONNECT Sp. z o.o. Sp. k.
Warszawa
Pokaż więcej podobnych
14
Włącz powiadomienie

Senior C# Developer, Franciszka Walczaka 3, Gorzów Wielkopolski

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916244

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Programista Systemów ERP
AscoO firmie

ważna jeszcze miesiąc

(do 29 paź)

10 000 – 17 000 zł
netto (+ VAT) / mies. | kontrakt B2B
Balicka 100, Bronowice, Krakówmałopolskie
kontrakt b2b
pełny etat
specjalista / specjalistka (mid / regular), starszy specjalista / starsza specjalistka (senior)
praca stacjonarna, praca hybrydowa
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Full-stack
Siedziba firmy

Asco

Balicka 100, Bronowice, Kraków

Sprawdź czas dojazdu

Zlokalizuj się lub podaj dokładny adres

Samochód

-

Komunikacja

-

Rower

-

Pieszo

-

Technologie, których używamy
System operacyjny
Twój zakres obowiązków
Tworzenie, rozwijanie i utrzymanie systemów ERP
Projektowanie i implementacja rozwiązań informatycznych zgodnych z wymaganiami klienta
Monitorowanie i rozwiązywanie problemów związanych z działaniem systemów ERP
Współpraca z zespołem i udział w spotkaniach projektowych
Utrzymywanie i aktualizacja baz danych
Testowanie i wdrażanie nowych funkcjonalności
Nasze wymagania
Doświadczenie w programowaniu i tworzeniu systemów ERP
Znajomość i umiejętność pracy z różnymi językami programowania, takimi jak Harbour, Clipper, FoxPro, VB
Znajomość baz danych i umiejętność tworzenia i zarządzania nimi, w tym SQL, Oracle, MySQL itp.
Umiejętność analizowania i rozwiązywania problemów związanych z systemami ERP
Zdolność projektowania, implementacji i testowania nowych funkcji i modułów systemu ERP
Znajomość i przestrzeganie standardów programowania i najlepszych praktyk w branży
Komunikatywność i umiejętność pracy w zespole, w tym współpraca z innymi programistami, użytkownikami systemu ERP i innymi funkcjami działu IT
Umiejętność zarządzania czasem i priorytetami, a także wykonywania zadań w określonych terminach
Wiedza na temat procesów biznesowych i funkcji systemów ERP
Samodzielność w rozwiązywaniu problemów i podejmowaniu decyzji technicznych
Mile widziane
Znajomość innych języków programowania
Benefity
Prywatna opieka medyczna
Ubezpieczenie na życie
Możliwość pracy zdalnej
Owoce
Spotkania integracyjne
Brak dress code’u
Kawa / herbata
Napoje
Parking dla pracowników
Asco
Przewiń do profilu firmy
Firma ASCO Systemy Informatyczne jest obecnie wiodącym dostawcą systemów do obsługi sklepów, hurtowni motoryzacyjnych oraz warsztatów samochodowych w kraju. Poszukujemy kolejnego członka zespołu, który będzie przyczyniał się do rozwoju oprogramowania.
Tak się u nas pracuje
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Praca
Kraków
IT - Administracja
Administrowanie systemami
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
Java Developer/-ka
Mindbox Sp. z o.o.
19 200–20 800 zł netto (+ VAT) / mies.
Kraków
Superoferta
Windows Support Engineer Najlepiej dopasowana
ITEAMLY SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
8 000–14 000 zł / mies. (zal. od umowy)
Kraków
Superoferta
Senior QA (Automat) | Tech Services
Edge One Solutions Sp. z o.o.
Kraków
Administrator / Administratorka bezpieczeństwa IT
ARC Consulting Group sp. z o.o. sp.k.
11 000–16 800 zł / mies. (zal. od umowy)
Kraków
Superoferta
Senior C++ Developer z QT (f/m/x) Śpiesz się!
Sii Sp. z o.o.
Kraków, Podgórze
Superoferta
DevOps Engineer
Scalo Sp. z o.o.
Kraków
Superoferta
Salesforce Developer with Java (f/m/x) Wyprzedź innych kandydatów
Sii Sp. z o.o.
Kraków, Podgórze
Pokaż więcej podobnych
16
Włącz powiadomienie

Programista Systemów ERP, Balicka 100, Bronowice, Kraków

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916245

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
.NET Developer
Nexus Polska Sp. z o.o.O firmie

ważna jeszcze 21 dni

(do 21 paź)

10 000 – 15 000 zł
brutto / mies. | umowa o pracę
12 000 – 18 000 zł
netto (+ VAT) / mies. | kontrakt B2B
Poznańwielkopolskie
umowa o pracę, kontrakt b2b
pełny etat
specjalista / specjalistka (mid / regular)
praca zdalna
szukamy wielu kandydatów2 wakaty
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Technologie, których używamy
Wymagane
C#
.NET
ASP.NET Core
SQL
Git
Mile widziane
Angular 8+
TypeScript
Docker
PL/SQL
O projekcie
Szukamy programistów z doświadczeniem w pracy nad aplikacjami .NET. Dołączysz do jednego z naszych zespołów tworzących rozwiązania webowe oparte o .NET (Core / Framework) oraz Angular. Znajdziemy miejsce zarówno dla typowego backendowca, jak i full stacka lubiącego JavaScript / TypeScript. Będziesz brał udział w wytwarzaniu aplikacji oraz usług stanowiących elementy systemów szpitalnych, które wspomagają codzienną pracę personelu medycznego.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniemasz wpływ na wybór narzędzi i technologiimasz wpływ na rozwiązania technologiczneagile
Twój zakres obowiązków
tworzenie backendu (.NET / .NET Core) aplikacji w przemyślanej architekturze,
tworzenie testów automatycznych (jednostkowych, integracyjnych, E2E),
ciągły rozwój umiejętności,
projektowanie tworzonych komponentów,
code review i współpraca z innymi programistami oraz testerami (team QA),
tworzenie testów automatycznych,
wsparcie dla konsultantów, którzy zajmują się wdrażaniem tworzonych przez Ciebie funkcjonalności,
udział w spotkaniach agile'owych, brainstormach i sesjach event storming.
Nasze wymagania
dobra znajomość C# / .NET,
znajomość webowych technologii .NETowych (np. ASP.NET Core),
znajomość relacyjnych baz danych i języka SQL,
znajomość dobrych praktyk programistycznych,
znajomość Git,
znajomość języka angielskiego.
Mile widziane
znajomość Angular 8+, TypeScript,
doświadczenie w pracy w zwinnych metodykach,
doświadczenia z konteneryzacją (Docker, Kubernetes),
doświadczenie w tworzeniu rozwiązań chmurowych na platformie Azure,
praktyczna znajomość architektury mikroserwisowej,
znajomość Oracle PL/SQL.
To oferujemy
pracę w firmie o ustabilizowanej pozycji na rynku, będącej częścią grupy NEXUS AG,
czynny udział w pracach samoorganizującego się zespołu: przy projektowaniu rozwiązań, w burzach mózgów, udział w dyskusjach dotyczących organizacji pracy,
dbałość o profesjonalną organizację pracy,
issue tracker (Redmine),
code review (GitLab),
continuous integration (TeamCity / GitLab CI),
statyczna analiza kodu (SonarQube),
testy automatyczne,
elastyczny czas pracy z możliwością Home Office,
praca zdalna,
biuro w centrum miasta z bardzo dobrym dojazdem komunikacją miejską z jednym z najbardziej malowniczych widoków w Poznaniu.
Tak pracujemy nad projektem
code review
statyczna analiza kodu
Continuous Integration
DevOps
automatyzacja testów
testy manualne
Benefity
Dofinansowanie zajęć sportowych
Prywatna opieka medyczna
Dofinansowanie szkoleń i kursów
Ubezpieczenie na życie
Możliwość pracy zdalnej
Elastyczny czas pracy
Spotkania integracyjne
Jeżeli spełniasz nasze oczekiwania, jesteś zainteresowany ofertą i chciałbyś stać się członkiem naszego zespołu, prześlij nam swoje CV wraz ze zgodą na przetwarzanie danych osobowych na potrzeby rekrutacji.
Zrób pierwszy krok, podejmij wyzwanie i kliknij w „Aplikuj teraz”!
Na podstawie art. 8 ust 1 Dyrektywy Parlamentu Europejskiego i Rady (UE) 2019/1937 z dnia 23 października 2019 r. w sprawie ochrony osób zgłaszających naruszenia prawa Unii, Nexus Polska Sp. z o.o. z siedzibą w Poznaniu wprowadził procedurę zgłoszeń wewnętrznych i podejmowania działań następczych, określającą tryb przyjmowania zgłoszeń wewnętrznych dotyczących informacji o naruszeniu prawa lub regulacji i standardów etycznych ustanowionych w Spółce, a także podejmowania działań następczych w związku z tymi zgłoszeniami. Jeżeli uzna Pani/Pan, że doszło do naruszenia prawa, ma Pani/Pan możliwość dokonania zgłoszenia naruszenia prawa zgodnie z przyjętą Procedurą, dostępną na stronie: www.nexuspolska.pl
Nexus Polska Sp. z o.o.
Przewiń do profilu firmy
Nexus Polska jest jednym z największych producentów oprogramowania dla polskiego rynku ochrony zdrowia. Nasze oprogramowanie jest wdrożone w około 130 polskich szpitalach. Jesteśmy częścią grupy NEXUS AG, czołowej europejskiej firmy dostarczającej rozwiązania dla sektora opieki zdrowotnej. Tworzymy ekosystem rozwiązań, na który składa się kilkadziesiąt różnych modułów, począwszy od obsługi ruchu chorych, rejestracji, dokumentacji medycznej przez aptekę, laboratorium, pracownie diagnostyczne, szpitalne magazyny oraz moduł rozliczeń po aplikacje internetowe i usługi umożliwiające współpracę wielu jednostek medycznych. Produkty Nexus Polska budzą zainteresowanie naszych zagranicznych partnerów i mamy plany wdrożeń poza granicami kraju.
Złożone potrzeby pacjentów, lekarzy, pielęgniarek, diagnostów, analityków oraz innych osób zaangażowanych w służbę zdrowia (oraz wymogi prawne) to nasz żywioł. Branża medyczna nieustannie dostarcza nam interesujących wyzwań, tworząc znakomite warunki do rozwoju zawodowego dla programistów oraz specjalistów IT.
Aplikuj szybko
Zapisz
Drukuj
Udostępnij

Klauzula zgody, rekrutacja: Prosimy o przesłanie CV zawierającego dane określone w Art. 221 ust. 1 Kodeksu pracy, tj. imię i nazwisko, datę urodzenia, dane kontaktowe, wykształcenie, kwalifikacje zawodowe, przebieg dotychczasowego zatrudnienia. Jeżeli w Państwa dokumentach aplikacyjnych znajdują się dane wykraczające, poza zakres określony powyżej, prosimy o dodanie klauzuli: „Wyrażam zgodę na przetwarzanie przez Nexus Polska Sp. z o.o. z siedzibą w Poznaniu moich danych osobowych zawartych w przesłanych dokumentach aplikacyjnych wykraczających poza zakres określony w Art. 221 ust. 1. Administratorem Pani/Pana danych osobowych jest spółka Nexus Polska Sp. z o.o. siedzibą w Poznaniu przy ul. Szyperskiej 14, 61-754 Poznań, e-mail: biuro@nexuspolska.pl, 2. W sprawach związanych z Pani/Pana danymi proszę kontaktować się z Inspektorem Ochrony Danych Osobowych: iod@nexuspolska.pl 3. Informujemy, że Pani/Pana dane osobowe określone w przepisach prawa pracy przetwarzane będą w celu przeprowadzenia procesu rekrutacyjnego na podstawie Art. 6 ust. 1 pkt. b) RODO (przetwarzanie jest niezbędne do wykonania umowy, której stroną jest osoba, której dane dotyczą, lub do podjęcia działań na żądanie osoby, której dane dotyczą, przed zawarciem umowy), a w zakresie wykraczającym poza ten dane, na podstawie Państwa zgody - Art. 6 ust. 1 pkt. a RODO, która może zostać odwołana w dowolnym czasie 4. Dane udostępnione przez Panią/Pana nie będą podlegały udostępnieniu podmiotom trzecim. Odbiorcami danych będą tylko instytucje upoważnione z mocy prawa. 5. Pani/Pana dane osobowe będą przechowywane do czasu zakończenia procesu rekrutacji. 6. Posiada Pani/Pan prawo dostępu do treści swoich danych oraz prawo ich sprostowania, usunięcia, ograniczenia przetwarzania, prawo do cofnięcia zgody w dowolnym momencie bez wpływu na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej cofnięciem; 7. Ma Pan/Pani prawo wniesienia skargi do organu nadzorczego, tj. Prezesa Urzędu Ochrony Danych Osobowych gdy uzna Pani/Pan, iż przetwarzanie danych osobowych Pani/Pana dotyczących narusza przepisy RODO. 8. Podanie przez Pana/Panią danych osobowych w zakresie wynikającym z art. 221 Kodeksu pracy jest warunkiem wzięcia udziału w procesie rekrutacji. Podanie innych danych jest dobrowolne. 9. Administrator danych nie ma zamiaru przekazywać danych osobowych do państwa trzeciego lub organizacji międzynarodowej, a dane udostępnione przez Panią/Pana nie będą podlegały profilowaniu.

Praca
Poznań
IT - Rozwój oprogramowania
Analiza biznesowa i systemowa
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
ServiceNow Service Process Excellence Lead (f/m/x)
Sii Sp. z o.o.
Piła
Fullstack Developer (C# + Angular)
ASTEK Polska
120–137 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Youth Development Program - AI-Assisted Developer (staż/praktyki) (m/k/d)
Signal Group sp. z o.o.
Poznań, Wilda
Kierownik/Kierowniczka Zespołu Sprzedaży
HRK S.A.
8 000–12 000 zł brutto / mies.
Poznań
Webcon Citizen Developer (SDK) (m/f/d)
KRUK S.A.
Wrocław
Programista Systemów (k/m)
Briju 1920 Limited
Gniezno
Superoferta
JV Solution Lab Business Architect | Technology Managed Services
PwC
Poznań
Pokaż więcej podobnych
16
Włącz powiadomienie

.NET Developer, Poznań

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916246

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
.NET Developer
ITP IT PERFORMANCE sp. z o.o.O firmie

ważna jeszcze 11 dni

(do 11 paź)

120,00 – 145,00 zł
netto (+ VAT) / godz. | kontrakt B2B
Warszawamazowieckie
kontrakt b2b
pełny etat
specjalista / specjalistka (mid / regular), starszy specjalista / starsza specjalistka (senior)
praca hybrydowa
praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend, Security
Technologie, których używamy
Wymagane
C#
.NET
O projekcie
Poszukujemy osoby (m/k) do roli .NET Developer. Praca jest dedykowana dla naszego klienta.
Dołączysz do zespołu rozwijającego systemy z obszaru Security / Video-CCTV / Data Processing, w których kluczowe znaczenie mają wydajność, stabilność i przetwarzanie danych w czasie rzeczywistym.
Projekt rozwijany jest w środowisku on-premise, z wykorzystaniem .NET 8 i planowaną migracją do .NET 10. Praca może również obejmować, w ograniczonym zakresie, starsze komponenty systemów oparte na .NET Framework.
Tak organizujemy naszą pracę
Tak pracujemy
u klienta
Twój zakres obowiązków
Rozwój i utrzymanie aplikacji backendowych w C#/.NET w obszarze systemów bezpieczeństwa i monitoringu wizyjnego.
Implementacja nowych funkcjonalności oraz rozbudowa istniejących modułów systemu.
Praca nad efektywnym wykorzystaniem i zarządzaniem pamięcią w aplikacjach przetwarzających dane w czasie rzeczywistym.
Integracja oprogramowania z innymi systemami, a w wybranych zadaniach poprzez komunikację socketową.
Diagnozowanie i usuwanie błędów oraz usprawnianie wydajności i stabilności aplikacji.
Tworzenie czytelnego, testowalnego kodu oraz udział w code review.
Współpraca z zespołem przy doborze rozwiązań technicznych i realizacji zadań developerskich.
Nasze wymagania
Minimum 4 lata doświadczenia w tworzeniu aplikacji w C#/.NET.
Dobra znajomość .NET, ASP.NET Core oraz tworzenia i rozwijania Web API.
Praktyczna znajomość programowania asynchronicznego i wielowątkowego.
Rozumienie mechanizmów zarządzania pamięcią w .NET i ich wpływu na wydajność aplikacji.
Doświadczenie w diagnozowaniu błędów i usprawnianiu działania aplikacji, np. pod kątem czasu odpowiedzi lub zużycia pamięci.
Znajomość zasad projektowania czytelnego, łatwego w utrzymaniu kodu oraz umiejętność stosowania wzorców projektowych.
Samodzielność w realizacji zadań i gotowość do poznawania działania systemu poza samą warstwą API, w tym przetwarzania danych i komunikacji między komponentami.
To oferujemy
Kontrakt B2B
Stawka: (120 - 145) pln/h + VAT
Praca w modelu hybrydowym: (2-3 dni w tyg z biura zlokalizowanym w warszawskim Wawrze)
Długoterminowe i rozwojowe projekty
Stabilny projekt z realnym znaczeniem biznesowym
Tak pracujemy nad projektem
dokumentacja
narzędzia do trackowania zadań
środowiska testowe
ITP IT PERFORMANCE sp. z o.o.
Przewiń do profilu firmy
Jako ITP IT Performance specjalizujemy się w outsourcingu, konsultingu i rekrutacji głównie w obszarze IT.
Aplikuj
Zapisz
Drukuj
Udostępnij

Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez ITP IT PERFORMANCE sp. z o.o. z siedzibą w: Długa 29, 00-238 Warszawa (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
IT - Administracja
Bezpieczeństwo / Audyt
Aplikuj
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Software Developer (.NET) (k/m)
Logisystem Sp. z o.o.
Warszawa, Białołęka
Superoferta
.NET Software Developer Najlepiej dopasowana
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)
Programista .NET / Programistka .NET w Obszarze Rozwoju Systemów Korporacyjnych
Bank Millennium S.A.
Warszawa, Mokotów
Superoferta
.Net Developer Śpiesz się!
OPTIVEUM SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
120 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Full Stack Developer (.NET / Angular / SQL)
GOLDENORE ITC sp. z o.o.
Warszawa
Superoferta
Senior Backend Developer (.NET) (m/f)
Grupa Pracuj
110–125 zł netto (+ VAT) / godz.
Warszawa, Wola
Fullstack Developer (C# + Angular)
ASTEK Polska
120–137 zł netto (+ VAT) / godz.
Warszawa
Pokaż więcej podobnych
16
Włącz powiadomienie

.NET Developer, Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
