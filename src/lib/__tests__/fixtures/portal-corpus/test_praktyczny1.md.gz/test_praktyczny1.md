DORADCA KLIENTA - Salon sprzedaży drzwi i podłóg
Wynagrodzenie

5 000 - 10 000 zł / mies. brutto

Lokalizacja

Oświęcim

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Oświęcim


Static Map
Opis
Jesteśmy salonem sprzedaży drzwi i podłóg działającym głównie na lokalnym rynku. Poszukujemy do naszego zespołu osoby ambitnej i kreatywnej, która jest gotowa związać się z nami na dłuższy okres czasu, niewykluczone na stałe.

Co oferujemy naszym pracownikom :

Zatrudnienie w oparciu o umowę o pracę (pierwsze 3 miesiące umowa zlecenie)

Stabilny system wynagradzania: płacę podstawową + premię uzależnioną od osiąganych wyników sprzedażowych,

Program szkoleń produktowych i sprzedażowych, stacjonarnych jak i wyjazdowych,które ułatwią wdrożenie się na nowym stanowisku,

Pracę w zespole fachowców i specjalistów, którzy służą pomocą w każdej sytuacji i postarają się przekazać jak największą porcję wiedzy nowemu pracownikowi,

Elastyczny grafik pracy i w miarę naszych możliwości dopasowany do potrzeb pracownika

Czego oczekujemy od naszych pracowników :

Umiejętności komunikacyjnych i interpersonalnych - najważniejsza cecha każdego handlowca

Komputer nie może być Ci obcy, pracujemy na licznych systemach zamówień oraz wykonujemy dziennie szereg wycen

Odporności na stres, bo jak wiadomo życie handlowca do łatwych nie należy i czasami trzeba zaparzyć kubek melisy ;)

Znajomość asortymentu z branży drzwi i podłogi jest warunkiem koniecznym.

Wymagamy min. rocznego doświadczenia na podobnym stanowisku.

Czym będziesz się zajmował :

Obsługa klientów w specjalistycznym salonie wykończenia wnętrz,

Doradztwo techniczne w temacie dostępnego w salonie asortymentu,

Prowadzenie dokumentacji sprzedażowej - sporządzanie umów z klientami, wystawianie faktur,

Dbanie o porządek w miejscu pracy oraz o estetykę i czystość ekspozycji

Bardzo prosimy o kontakt mailowy - zostaw nam swoje CV. Odezwiemy się do wybranych kandydatów i zaprosimy na rozmowę.

Aplikuj

-----------------------
raca dla Kierowcy kat C Doskonałe Warunki Dniówka od 450zł na rękę
SVBL Tomasz Ziemiński
Wynagrodzenie

do 12 000 zł / mies. brutto

Lokalizacja

Zielona Góra

Wymiar pracy

Pełny etat

Typ umowy

Samozatrudnienie, Umowa zlecenie


Lokalizacja
Zielona Góra


Static Map
Opis
KIEROWCA kat. C – trasy międzynarodowe | własne auto | system 2/1, 3/1, 4/1

Zielona Góra (baza) | Atrakcyjne wynagrodzenie

Firma transportowa zatrudni doświadczonego kierowcę kat. C na trasy międzynarodowe – Niemcy, Francja, Holandia, Belgia, Włochy, Hiszpania i inne kraje UE.

OFERUJEMY:

Stałe zatrudnienie – stabilna firma z doświadczeniem

Własny samochód plandeka (przypisany na stałe)

Telefon służbowy z internetem

Praca w systemie: 3/1, 4/1, 11/3 – do ustalenia

Atrakcyjne i terminowe wynagrodzenie

Stałe wsparcie spedytora

WYMAGANIA:

Prawo jazdy kat. C

Doświadczenie w transporcie międzynarodowym

Znajomość dokumentów transportowych

Punktualność, sumienność

Zainteresowany? Zadzwoń: 79*****77 Lub prześlij CV przez OLX

BAZA: Zielona Góra Dołącz do firmy, która naprawdę dba o swoich kierowców.
-------------
Pedagog specjalny – pełny etat
Prywatna Szkoła Podstawowa Harmonia
Wynagrodzenie

55 - 80 zł / godz. brutto

Lokalizacja

Poznań, Warszawskie

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Nieszawska 13A

60-965 Poznań, Warszawskie

Wskazówki dojazdu




Static Map
Opis
Szkoła Podstawowa Harmonia w Poznaniu poszukuje pedagoga specjalnego do pracy w pełnym wymiarze godzin.

Szukamy osoby odpowiedzialnej, empatycznej i zaangażowanej, która będzie wspierać uczniów wymagających dodatkowej pomocy oraz współpracować z nauczycielami, specjalistami i rodzicami.

Zakres obowiązków:

prowadzenie zajęć i wsparcie uczniów ze specjalnymi potrzebami edukacyjnymi,

indywidualna praca z uczniami,

współpraca z nauczycielami, wychowawcami i innymi specjalistami,

współpraca z rodzicami,

udział w przygotowywaniu i realizacji dokumentacji dotyczącej pomocy psychologiczno-pedagogicznej,

wspieranie uczniów w codziennym funkcjonowaniu w szkole.

Wymagania:

ukończone studia z pedagogiki specjalnej – warunek konieczny,

kwalifikacje umożliwiające pracę na stanowisku pedagoga specjalnego,

dobre podejście do dzieci i młodzieży,

odpowiedzialność i komunikatywność,

umiejętność pracy zespołowej,

dodatkowym atutem będą uprawnienia/kwalifikacje do pracy z uczniem ze spektrum autyzmu.

Oferujemy:

pracę na pełny etat,

stabilne zatrudnienie,

możliwość długoterminowej współpracy,

wsparcie zespołu i dyrekcji szkoły,

przyjazną atmosferę pracy.

Osoby zainteresowane prosimy o przesłanie CV za pośrednictwem OLX.

--------------
Praca przy dostawach w drogerii kosmetycznej
JobmanGroup sp z.o.o Dowiedz się więcej
Lokalizacja

Sandomierz

Wymiar pracy

Praca dodatkowa

Typ umowy

Umowa zlecenie


Lokalizacja
Sandomierz


Static Map
Opis
Jobman Group Sp. z o.o. - Agencja Pracy Tymczasowej działająca na podstawie wpisu do rejestru podmiotów prowadzących agencje zatrudnienia pod nr 2163 - poszukuje osób chętnych do podjęcia pracy.

Praca przy dostawach w drogerii kosmetycznej

Miejsce pracy: Sandomierz

 

OBOWIĄZKI:

- przyjęcie towaru,

- rozładunek towaru z samochodów dostawczych i palet,

- wyłożenie towaru na półki sklepowe zgodnie z obowiązującymi standardami

WYMAGANIA:

- pełnoletniość

- chęci do pracy,

- odpowiedzialność i rzetelność,

OFERUJEMY:

- umowę zlecenie,

- wynagrodzenie w formie tygodniowej,

- stawkę 31,40 zł/h brutto

- możliwość zdobycia cennego doświadczenia,

- obsługę administracyjną on-line,

- możliwość wybrania dowolnych terminów,

- Pre-pensję od Patento - możesz wypłacić część swojej pensji, bez czekania na standardowy termin wypłaty!

- pakiet Medicover Sport, dzięki któremu zyskasz dostęp do szerokiej gamy atrakcyjnych zajęć sportowych!

- Liczne konkursy, w których do wygrania jest dodatkowa premia

 

 

 

 

DODATKOWE INFORMACJE:

Aplikacje powinny zawierać klauzulę: 'Na podstawie art. 7 ust. 1 RODO oświadczam, iż wyrażam zgodę na przetwarzanie przez administratora, którym jest Jobman Group Sp. z o.o. z siedzibą w Krakowie, ul. Bociana 22a, 31-231 Kraków moich danych osobowych w celu przeprowadzenia procedury rekrutacji na oferowane stanowisko. Mając na względzie, iż oferta dotyczy wykonywania pracy tymczasowej na rzecz pracodawcy użytkownika, którym jest klient Administratora, rozumiem i akceptuję fakt iż celem przeprowadzenia rekrutacji niezbędnym jest udostępnienie moich danych temu pracodawcy użytkownikowi.'

Aplikuj
------------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaProdukcjaObsługa produkcjiObsługa produkcji - MazowieckieObsługa produkcji - Bielsk
Odświeżono dzisiaj o 09:29

Praca - Spawacz
N&N Nadratowski Sp.j. Dowiedz się więcej
Lokalizacja

Bielsk

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Bielsk


Static Map
Opis
Kim jesteśmy

Jesteśmy prężną, polską, rodzinną firmą produkującą maszyny i urządzenia dla przemysłu spożywczego. Naszym ulubionym surowcem jest stal nierdzewna. Mamy zasięg globalny. Działamy na rynku od 2001 roku.

Twój zakres obowiązków

- Spawanie metodą TIG spoin czołowych, pachwinowych, punktowych, ciągłych z pełnym przetopem dla rur, blach, kształtowników i prętów,

- Montaż detali, podzespołów i produktów zgodnie z dokumentacją konstrukcyjną,

- Prace ślusarskie, obróbka elementów przy użyciu elektronarzędzi,

- Obsługa narzędzi ręcznych i elektronarzędzi (np. wiertarki, szlifierki, piły tarczowe, itp.),

- Prace serwisowe na obiektach,

- Prace montażowe u klientów docelowych,

- Testy i weryfikacja zmontowanych urządzeń

 Nasze oczekiwania

- Znajomość podstaw rysunku technicznego

- Aktualne uprawnienia spawalnicze TIG 141,

- Umiejętność czytania rysunków technicznych,

- Umiejętność obsługi elektronarzędzi (szlifierki, wiertarki, piły tarczowe, itp.),

- Wymagane doświadczenie w pracy na podobnym stanowisku,

- Dobra organizacja pracy, sumienność i dokładność,

- Umiejętność pracy pod presją czasu

- Komunikatywność, samodzielność, odpowiedzialność

 Na co możesz liczyć

- pracę w stabilnej firmie o ugruntowanej pozycji na rynku

- możesz liczyć na wynagrodzenie adekwatne do wykonywanych zadań

- możliwość rozwoju zawodowego, podwyższania oraz zdobywania nowych kwalifikacji

- niezbędne narzędzia i materiały do pracy

- nowa siedziba w atrakcyjnej lokalizacji

- nowoczesny park maszynowy

- bardzo dobre warunki socjalne

 

Wyślij swoje CV na adres email z klauzulą: „Wyrażam zgodę na przetwarzanie moich danych osobowych przez N&N NADRATOWSKI sp.j. w celu prowadzenia rekrutacji na aplikowane przeze mnie stanowisko” lub przyjedź do naszej siedziby na rozmowę: N&N NADRATOWSKI sp.j., ul. Akacjowa 3, 09-230 Bielsk, tel. (024) 261 52 61

Aplikuj
ID: 1100403062

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

N&N Nadratowski Sp.j.
Na OLX od czerwiec 2022

Ostatnio online w dniu 24 września 2026


Zadzwoń / SMS
Aplikuj
Mniej niż 5 kandydatów. Wykorzystaj swoją szansę.

Więcej od tego ogłoszeniodawcy

Więcej od tego ogłoszeniodawcy
Zobacz wszystkie

Elektryk - Serwisant
N&N Nadratowski Sp.j.

Bielsk

Pełny etat

Umowa o pracę

Odświeżono dnia 15 września 2026


Praca - Monter/Ślusarz
N&N Nadratowski Sp.j.

Bielsk

Pełny etat

Umowa o pracę

Odświeżono dnia 15 września 2026


Praca Tokarz-Frezer
N&N Nadratowski Sp.j.

Bielsk

Pełny etat

Umowa o pracę

Odświeżono dnia 15 września 2026

Zobacz też
Ogłoszenie o Pracę - Spawacz MAG 135
6 000 - 7 000 zł / mies. brutto

Zbójno

Pełny etat

Umowa o pracę

Odświeżono dnia 15 września 2026


Praca - Monter/Ślusarz
N&N Nadratowski Sp.j.

Bielsk

Pełny etat

Umowa o pracę

Odświeżono dnia 15 września 2026


Pracownik fizyczny
39 - 42 zł / godz. brutto

Płock

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 28 września 2026


praca spawacz płock
Płock

Pełny etat

Umowa zlecenie

Odświeżono dnia 28 września 2026


Praca dla spawacza
8 000 - 13 000 zł / mies. brutto

Płock

Pełny etat

Inny, Umowa o pracę, Samozatrudnienie, Umowa zlecenie

25 września 2026


zatrudnie samodzielna ksiegowa
Płock

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
-----------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaBudowa / remontyGlazurnikGlazurnik - WielkopolskieGlazurnik - PoznańGlazurnik - Stare Miasto
Odświeżono dzisiaj o 08:39
Praca dla PŁYTKARZA - Poznań
Lokalizacja

Poznań, Stare Miasto

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Poznań, Stare Miasto


Static Map
Opis
Zatrudnię płytkarzy.

Praca stała, na umowę, na terenie Poznania i okolic, od zaraz.

Osoby zainteresowane proszę o kontakt telefoniczny pod numerem: 79*******74

 

Aplikuj
ID: 1100171649
Wyświetlenia: 109

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Pracodawca
Na OLX od czerwiec 2021

Ostatnio online w dniu 23 września 2026


Zadzwoń / SMS
Aplikuj
Mniej niż 5 kandydatów. Wykorzystaj swoją szansę.

Więcej od tego ogłoszeniodawcy

Pracownicy budowlani Poznań
Poznań, Stare Miasto

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 08:27

Zobacz też
zatrudnię płytkarza
7 000 - 12 000 zł / mies. brutto

Poznań, Stare Miasto

Pełny etat

Umowa o pracę

Odświeżono dnia 15 września 2026


Zatrudnię płytkarza
od 40 zł / godz. brutto

Poznań, Stare Miasto

Pełny etat

Inny, Umowa o pracę, Samozatrudnienie

21 września 2026


Poszukiwany Pracownik Budowlany ! Rekrutacja Online !
35 - 55 zł / godz. brutto

Poznań, Jeżyce

Pełny etat

Umowa o pracę

Odświeżono dnia 27 września 2026


Przyjmę do pomocy - Płytkarz - Poznań
Poznań, Grunwald

Pełny etat

Inny

03 września 2026


zatrudnię płytkarza i pomocnika
6 500 - 10 000 zł / mies. brutto

Zdziechowa

Pełny etat

Umowa o pracę

Odświeżono dnia 08 września 2026



Nawiążemy stałą współpracę z instalatorami HVAC (Klimatyzacja i Wentylacja)
Poznań, Rataje

Współpraca B2B

Umowa zlecenie

29 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
Ochrona – Obiekt Logistyczny - Lublin
Juwentus Dowiedz się więcej
Wynagrodzenie

do 31,40 zł / godz. brutto

Lokalizacja

Lublin

Wymiar pracy

Pełny etat

Typ umowy

Umowa zlecenie


Lokalizacja
Lublin


Static Map
Opis
W związku z nowymi wyzwaniami i rozwojem technologii dla firm z branży ochrony i bezpieczeństwa poszukujemy Agentów Ochrony K/M

 

Obiekt: Logistyczny

Lokalizacja: Lublin

                  Mile widziane osoby posiadające status studenta/ucznia

  

 

OCZEKUJEMY:

·         sumienności i zaangażowania

·         dyspozycyjności

·         punktualności

·         niekaralności

ZAKRES CZYNNOŚCI:

·         wykonywanie czynności związanych z ochroną fizyczną mienia

·         obchody kontrolne obiektu

·         kontrola osób wchodzących i wychodzących

 

OFERUJEMY:

·         umowę zlecenie

.         stawkę: 31,40 zł/h brutto 

·         system:  07:00 - 19:00  19:00 - 07:00

·         szkolenie i wdrożenie w czynności na danym obiekcie

 

Osoby zainteresowane prosimy o przesyłanie aplikacji.

 

Dziękujemy za przesłanie aplikacji. Informujemy, iż skontaktujemy się jedynie z wybranymi osobami.

Informacje Prawne
Współadministratorami Twoich danych osobowych są spółki z Grupy Juwentus (tj. „Ochrona Juwentus” sp. z o.o., „Juwentus” Agencja Ochrony​ sp. z o.o., „Ochrona Juwentus Południe” sp. z o.o., Juwentus Serwis sp. z o.o., Juwentus Group Sp. o.o., Juwentus Talon Sp. o.o., HELPON Centrum Usług sp. z o.o.), wszystkie z siedzibą w Warszawie (02-826) przy ul. Poloneza 91. Dane kontaktowe inspektora ochrony danych: iod@juwentus.pl Dane osobowe są przetwarzane wyłącznie w celu rekrutacji, na podstawie Twojej dobrowolnej zgody. Masz prawo do wycofania zgody w dowolnym momencie, przy czym cofnięcie zgody nie ma wpływu na zgodność przetwarzania, którego dokonano na jej podstawie przed cofnięciem zgody. Dane osobowe będą przetwarzane przez okres nie dłuższy niż 6 miesięcy, chyba że wcześniej wycofasz swoją zgodę. Twoje dane osobowe nie będą przekazywane do państw trzecich. Podanie danych jest dobrowolne, ale konieczne w celu przeprowadzenia rekrutacji, w której bierzesz udział. Masz prawo dostępu do Twoich danych osobowych, ich sprostowania, usunięcia lub ograniczenia przetwarzania, prawo do przenoszenia danych oraz prawo wniesienia skargi do organu nadzorczego.
 

Zobacz więcej
-------------------------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaMontaż i serwisMontaż i serwis - PomorskieMontaż i serwis - Luzino
Odświeżono dnia 29 września 2026
Monter okien i drzwi - z doświadczeniem lub do przyuczenia
Wynagrodzenie

41 - 63 zł / godz. brutto

Lokalizacja

Luzino

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Luzino


Static Map
Opis
Poszukujemy osób na stanowisko Monter stolarki okiennej i drzwiowej. Mile widziane doświadczenie ale również osoby chętne do przyuczenia . Stawka godzinowa do ustalenia w zależności od doświadczenia i umiejętności. Możliwość zdobycia doświadczenia i rozwoju, a tym samym wyższą stawkę dla osób potrafiących samodzielnie wykonywać montaże. Praca na terenie Trójmaista, mile widziane prawo jazdy kat. B. Siedziba firmy w Luzinie, woj. pomorskie Kontakt: 69*******83. Można również kontaktować się poprzez wiadomość OLX.

Aplikuj
ID: 1089894316
Wyświetlenia: 284

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Kadry
Na OLX od styczeń 2015

Ostatnio online w dniu 03 września 2026


Zadzwoń / SMS
Aplikuj
Zobacz też
Zatrudnimy stolarza oraz pomocnika ( k/m)
4 900 - 10 000 zł / mies. brutto

Luzino

Pełny etat

Umowa o pracę

01 września 2026


Zatrudnię pracownika na stanowisko ładowacz nieczystości stałych
Ekologistik

Luzino

Pełny etat

Umowa o pracę, Umowa zlecenie

26 września 2026



Asystent/specjalista ds. Obsługi Biura i Marketingu
PARTY CAMP

4 000 - 8 000 zł / mies. brutto

Reda

Pełny etat

Umowa o dzieło, Inny, Umowa o pracę, Praktyka / staż, Samozatrudnienie, Umowa zlecenie

Odświeżono dnia 28 września 2026


Monter konstrukcji stalowych / zbiorników
10 000 - 13 500 zł / mies. brutto

Wejherowo

Pełny etat

Umowa o dzieło, Inny, Umowa o pracę, Praktyka / staż, Samozatrudnienie, Umowa zlecenie

Odświeżono dnia 08 września 2026



Pracownik Fizyczny
Elmark

Wejherowo

Pełny etat

Umowa o pracę, Samozatrudnienie, Umowa zlecenie

Odświeżono dnia 25 września 2026



Praca operator spycharki z doświadczeniem (M/K) ZIMAR
ZIMAR Ryszard Ziegert

Lębork

Pełny etat

Umowa o pracę

28 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaPrace magazynowePrace magazynowe - MałopolskiePrace magazynowe - KrakówPrace magazynowe - Czyżyny
Odświeżono dzisiaj o 11:33
Magazynierka/magazynier
PartnerTele.com
Lokalizacja

Kraków, Czyżyny

Wymiar pracy

Pełny etat

Typ umowy

Umowa zlecenie


Lokalizacja
Siwka 27

31-588 Kraków, Czyżyny

Wskazówki dojazdu




Static Map
Opis
Stanowisko: magazynierka / magazynier

umowa zlecenie

praca na pełen etat

praca stacjonarna

pracodawca nie wymaga CV

praca zmianowa tak (pierwsza zmiana 8:00 - 16:00, druga zmiana 14:00 - 22:00)

możliwa dodatkowa praca w soboty (do ustalenia z kierownictwem)

praca w godzinach nocnych: nie

wymagany jezyk: polski

Magazynier/Magazynierka

Twój zakres obowiązków

kompletacja zamówień przy użyciu skanera

przyjmowanie dostaw

weryfikacje stanu towaru przed pakowaniem

oklejanie, etykietowanie asortymentu

drobne prace magazynowe

utrzymanie czystości i porządku w miejscu pracy

Nasze wymagania

zaangażowanie i punktualność

odpowiedzialność i organizacja

pełnoletność

To oferujemy

zatrudnienie na podstawie umowy zlecenia

pracujemy od godziny 8 (możliwość zmiany)

przerwę 20 minut (kawę, herbatę, wodę gratis)

Informacje Prawne
Klauzula

Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez Partner Tele.com Sp. z o.o. Sp.k. z siedzibą w: Sołtysowska 22, 31-589 Kraków (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu. Twoje dane osobowe będą przetwarzane w oparciu o następujące podstawy prawne: (a) aby podjąć działania na Twoje żądanie przed zawarciem umowy (np. informacje o oczekiwanym wynagrodzeniu i dostępności do rozpoczęcia pracy); (b) w oparciu o nasz prawnie uzasadniony interes (np. imię, nazwisko, data urodzenia, dane kontaktowe, wykształcenie, kwalifikacje zawodowe, przebieg dotychczasowego zatrudnienia); c) w oparciu o Twoją zgodę, która wyrażona jest poprzez przesłanie dokumentów aplikacyjnych zawierających takie informacje jak np. wizerunek czy zainteresowania. Podanie wszystkich danych osobowych, o których mowa powyżej jest dobrowolne, natomiast dane wymienione w lit. a) i b) są niezbędne do wzięcia udziału w rekrutacji. Niepodanie danych skutkuje brakiem możliwości rozpatrzenia kandydatury. Podanie pozostałych danych jest dobrowolne, ale może pomóc w sprawnym przeprowadzeniu procesu rekrutacji. Masz prawo żądać dostępu do Twoich danych (w tym uzyskania ich kopii), sprostowania danych, ich usunięcia, ograniczenia przetwarzania, przeniesienia, jak również wniesienia sprzeciwu wobec ich przetwarzania. Masz także prawo wniesienia skargi do Prezesa Urzędu Ochrony Danych Osobowych. Twoje dane osobowe mogą zostać przekazane dostawcom usługi publikacji ogłoszeń o pracę, dostawcom systemów do zarządzania rekrutacjami, dostawcom usług IT (hosting), dostawcom systemów informatycznych. Podane przez Ciebie dane osobowe nie będą wykorzystywane w celu profilowania albo podejmowania decyzji w sposób zautomatyzowany. Twoje dane osobowe będą przetwarzane przez okres maks. 1 roku od zakończenia publikacji ogłoszenia, chyba, że wyraziłeś odrębną zgodę na wykorzystanie Twoich danych osobowych w przyszłych rekrutacjach. W celu realizacji praw lub w przypadku jakichkolwiek pytań związanych z przetwarzaniem Twoich danych osobowych skontaktuj się z nami pod adresem: ado@partnertele.com. ======= W związku z wejściem w życie ustawy o sygnalistach wdrożyliśmy procedurę wewnętrznego zgłaszania naruszeń. Gwarantujemy pełną poufność oraz wsparcie w przypadku zgłaszania nieprawidłowości. Szczegóły oraz procedura są dostępne na stronie www.partnertele.com.
 

Zobacz więcej
Aplikuj
ID: 1098621408

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

PartnerTele.com
Na OLX od marzec 2026

Ostatnio online w dniu 16 września 2026

Aplikuj
Zobacz też
Magazynier - Pakowacz
Med Store

5 100 - 5 500 zł / mies. brutto

Kraków, Czyżyny

Pełny etat

Umowa zlecenie

17 września 2026


Magazynier - magazyn przeładunkowy, atrakcyjne wynagrodzenie.
7 500 - 8 000 zł / mies. brutto

Kraków, Czyżyny

Pełny etat

Umowa o pracę

Odświeżono dnia 22 września 2026



Od 7000 zł | Робота на складі в Кракові | Warehouseman Cracow | Magazynier Kraków | Даємо житло | Потужні виплати
Liga Plus sp z o o

7 000 - 12 000 zł / mies. brutto

Kraków, Stare Miasto

Pełny etat

Umowa zlecenie

Odświeżono dzisiaj o 10:48



1/2 ETATU - Magazynier - 4h zmiany popołudniowe - OD ZARAZ bez CV
Euvic Future Work Sp. z o.o.

do 38,90 zł / godz. brutto

Kraków, Nowa Huta

Praca dodatkowa

Umowa zlecenie

Odświeżono dzisiaj o 11:23


Osoba do pracy na magazynie, pakowania kompletowania zamówień paczek, rozpakowywanie towaru PRACA ZMIANOWA
MK18

4 806 - 4 807 zł / mies. brutto

Kraków, Podgórze

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 24 września 2026



7000 netto | Робота в Кракові | Склад шин | Комплектація замовлень | Високі премії | Без досвіду
Liga Plus sp z o o

8 000 - 11 500 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa zlecenie

Odświeżono dzisiaj o 09:14


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
-----
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaPrace magazynowePrace magazynowe - MazowieckiePrace magazynowe - Płock
Allegro
Odświeżono dzisiaj o 11:33

Praca w Allegro! Lider/ka magazynu kurierskiego
Allegro Sp. z o.o. Dowiedz się więcej
Lokalizacja

Płock

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
09-400 Płock


Static Map
Opis
Na czym polegać będzie Twoja praca?

Na co dzień będziesz koordynować pracę zespołu w magazynie przesyłek kurierskich

Będziesz odpowiadać za prawidłowe i terminowe sortowanie przesyłek na odpowiednie oddziały

Zajmiesz się procesowaniem przesyłek uszkodzonych zgodnie z przyjętymi procedurami

Twoim zadaniem będzie eliminowanie przestojów oraz optymalizacja procesów magazynowych

Będziesz wspierać swój zespół w codziennych zadaniach

Będziesz raportować do Managera wyniki pracy zespołu

Szukamy osób, które:

Posiadają min. 2 letnie doświadczenie na podobnym stanowisku w magazynie lub firmie kurierskiej

Posiadają umiejętność delegowania zadań, planowania i organizacji pracy

Znają pakiet MS Office

Znają przepisy z zakresu BHP i PPOŻ

Wyróżniają się komunikatywnością i lubią współpracować z innymi - na co dzień pracujemy zespołowo

Charakteryzują się umiejętnością samodzielnego i szybkiego podejmowania decyzji

Cechują się wysoką kulturą osobistą

Są otwarte na pracę zmianową

Ze swojej strony oferujemy:

Pracę w zespole, na którego wsparcie zawsze możesz liczyć - na pokładzie mamy najlepszych specjalistów i ekspertów w swojej dziedzinie.

Dostęp do budżetu szkoleniowego oraz wewnętrznej platformy edukacyjnej, a także zajęcia angielskiego opłacane przez nas.

Bogaty pakiet świadczeń: system kafeteryjny, w którym to Ty decydujesz, z czego korzystasz (do wyboru pakiety medyczne, sportowe, ubezpieczenia i inne).

A to jeszcze nie wszystko! Więcej na temat benefitów możesz przeczytać tutaj.

#dobrzetubyć, czyli:

Będziesz odpowiadać za kształtowanie doświadczeń milionów klientów poprzez wpływ na tworzenie nowych rozwiązań i budowanie procesów Allegro One od podstaw.

Będziesz uczyć się w trakcie pracy, współpracując z prawdziwymi ekspertami. Otrzymasz wsparcie w ciągłym doskonaleniu i środowisko, w którym błędy traktowane są jako okazja do nauki.

Będziesz odpowiadać za wspieranie rozwoju naszej działalności w sposób zrównoważony, aktywnie przyczyniając się do dbałości o środowisko.

Wyślij nam swoje CV i… do zobaczenia w Allegro!

Aplikuj teraz
ID: 1100213588

Zgłoś
O firmie
Allegro Sp. z o.o.
Branża
Transport i Logistyka
Wielkość firmy
1001+
Lokalizacja
Poznań
Zaczęło się od małego startupu w Poznaniu… Teraz Allegro to kilkanaście spółek tworzących wiodący w Europie Środkowej e-commerce.
Wszyscy mamy tu jeden wspólny cel – chcemy dostarczać możliwie najlepsze, najszybsze i najbardziej innowacyjne usługi e-commerce.

Skupiamy się na dalszym rozwoju naszych usług, marek i platform – poszukujemy nowych rozwiązań, podejmujemy kolejne wyzwania i analizujemy potencjalne obszary rozwoju biznesu.

Dzięki temu możemy oferować naszym pracownikom różne ekscytujące możliwości – w ten sposób rozwijamy się nie tylko jako firma, ale i indywidualnie.

To coś, z czego można być dumnym, więc tacy właśnie jesteśmy.


Pokaż więcej
Zobacz profil pracodawcy
Rekruter


Allegro Sp. z o.o.
Na OLX od sierpień 2022

Ostatnio online wczoraj o 15:19

Aplikuj teraz
Zobacz profil pracodawcy
Więcej od tego ogłoszeniodawcy
Zobacz wszystkie


Koordynator/ka ds. Zwrotów i Reklamacji Dostaw
Allegro Sp. z o.o.

Piotrków Trybunalski

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:30



Praca w Allegro! Lider/ka magazynu kurierskiego
Allegro Sp. z o.o.

Piotrków Trybunalski

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:24



Praca w Allegro! Lider/ka magazynu kurierskiego - Białystok / Żółtki-Kolonia
Allegro Sp. z o.o.

Białystok, Leśna Dolina

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Lider/ka magazynu kurierskiego - Wolica
Allegro Sp. z o.o.

Pruszków

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Lider/ka magazynu kurierskiego - Wolica
Allegro Sp. z o.o.

Nadarzyn

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Lider/ka magazynu kurierskiego - Lisia Góra
Allegro Sp. z o.o.

Tarnów

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Lider/ka magazynu kurierskiego - Zakrzów
Allegro Sp. z o.o.

Niepołomice

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Dyspozytor/Dyspozytorka
Allegro Sp. z o.o.

Zielona Góra

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Koordynator/Koordynatorka ds. transportu (Depot)
Allegro Sp. z o.o.

Lublin

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Dyspozytor/Dyspozytorka - Zakrzów
Allegro Sp. z o.o.

Wieliczka

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Dyspozytor/Dyspozytorka
Allegro Sp. z o.o.

Radom

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Dyspozytor/Dyspozytorka - Zakrzów
Allegro Sp. z o.o.

Kraków, Podgórze

Pełny etat

Umowa o pracę

29 września 2026



Praca w Allegro! Koordynator/ Koordynatorka Magazynu - Legnica
Allegro Sp. z o.o.

Legnica

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



Praca w Allegro! Specjalista / Specjalistka ds. Operacji Magazynowych (Wolica)
Allegro Sp. z o.o.

Nadarzyn

Pełny etat

Umowa o pracę

Odświeżono dnia 25 września 2026



Praca w Allegro! Lider/ka magazynu kurierskiego
Allegro Sp. z o.o.

Piotrków Trybunalski

Pełny etat

Umowa o pracę

Odświeżono dnia 25 września 2026

Zobacz też

Magazynier / ka w Allegro One - Płock
33 - 39,60 zł / godz. brutto

Płock

Pełny etat

Umowa zlecenie

25 września 2026


Pracownik Administracyjny
4 900 - 5 100 zł / mies. brutto

Płock

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026


Pracownik fizyczny
39 - 42 zł / godz. brutto

Płock

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 28 września 2026


Młodszy Specjalista / Młodsza Specjalistka ds. Administracji i Wsparcia Organizacyjnego
Płock

Pełny etat

Umowa o pracę

Odświeżono dnia 17 września 2026



Koordynator/Koordynatorka Zespołu Operacji
InPost sp. z o.o.

Płock

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026


zatrudnie samodzielna ksiegowa
Płock

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
--------------------------

Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaPozostałe oferty pracyPozostałe oferty pracy - ŁódzkiePozostałe oferty pracy - ŁódźPozostałe oferty pracy - Śródmieście
Odświeżono dzisiaj o 10:23
Praca na parkingu
TIS Partners sp.zoo
Wynagrodzenie

4 806 - 5 000 zł / mies. brutto

Lokalizacja

Łódź, Śródmieście

Wymiar pracy

Pełny etat

Typ umowy

Umowa zlecenie


Lokalizacja
Prezydenta Gabriela Narutowicza 26

90-135 Łódź, Śródmieście

Wskazówki dojazdu




Static Map
Opis
Zakres obowiązków:

Obsługa kasy fiskalnej i terminala
Wskazywowanie klientom miejsc parkingowych
Pilnowanje porządku
Dbanie o czystość
Udzielanie podstawowych informacji
Przyjmowanie i wydawanie przepustek
Utrzymanie porządku w miejscu pracy
Zbieranie liści
Odśnieżanie chodniczka
Wymagania:

Sumienność i odpowiedzialność
Gotowość do pracy w systemie zmianowym
Komunikatywność
Wysoka kultura osobista
Motywacja do pracy
Doświadczenie w podobnej roli jest mile widziane
Wiek powyżej 50 lat jest mile widziany
Informacje dodatkowe:

Typ umowy: Umowa zlecenie. Dyspozycyjność: Praca zmianowa. Wymagane doświadczenie: Bez doświadczenia. Zapraszamy seniorów. Wymiar pracy: Pełny etat. Miejsce pracy: W siedzibie firmy. Zachęcamy do aplikowania!

Aplikuj
ID: 1099877073

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

TIS Partners sp.zoo
Na OLX od listopad 2011

Ostatnio online w dniu 22 września 2026


Zadzwoń / SMS
Aplikuj
Zobacz też
Osoba zliczająca pasażerów
VIA VISTULA Sp. z o. o.

do 36 zł / godz. brutto

Łódź, Śródmieście

Praca dodatkowa

Umowa zlecenie

Odświeżono dnia 28 września 2026


ogłoszenie na prace
LSP Sp. zo.o.

Łódź, Śródmieście

Pełny etat

Umowa o pracę, Samozatrudnienie, Umowa zlecenie

Odświeżono dnia 29 września 2026


Praca Smyk Magazyn
Smyk Logistyka

do 6 130 zł / mies. brutto

Łódź, Górna

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:13


Niekwlifikowany pracownik ochrony -Łódź
Łódź, Bałuty

Pełny etat

Umowa zlecenie

Odświeżono dnia 17 września 2026


Pracownik dozoru - Łódź
Combat

3 900 - 5 000 zł / mies. brutto

Łódź, Polesie

Praca dodatkowa

Inny

21 września 2026



Techniczka / Technik na produkcji w Gillette
Procter&Gamble - Fabryka Gillette w Łodzi

Łódź, Polesie

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
----------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaOchronaOchrona - WielkopolskieOchrona - Piła
Odświeżono dzisiaj o 08:48
Ochrona praca obiekt handlowy Piła
Rekrutacja
Lokalizacja

Piła

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę, Umowa zlecenie


Lokalizacja
Piła


Static Map
Opis
Agencja Ochrony Osób i Mienia w związku z dynamicznym rozwojem firmy zatrudni osoby na stanowisko: Pracownik / pracownica ochrony

Obiekt Handlowy

Wymagania:

-niekaralność

-dyspozycyjność

-sumienność i zaangażowanie

- wysoka kultura osobista

Oferujemy:

- dobre warunki pracy

- stabilne zatrudnienie

- zapewniamy elastyczny grafik pracy

– dostosowany do indywidualnych potrzeb

- terminowe wynagrodzenie

Umowa Zlecenie: wynagrodzenie 31,40 zł brutto/godz.

Umowa o pracę (pełny etat): wynagrodzenie 4806 brutto/miesiąc+ dodatki zgodne z regulaminem.

Osoby zainteresowane ofertą prosimy o kontakt pod numerem telefonu lub o przesłanie CV ze zdjęciem za pomocą portalu.

Aplikuj
ID: 1100173154

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Rekrutacja
Na OLX od lipiec 2015

Ostatnio online dziś o 12:09


Zadzwoń / SMS
Aplikuj
Więcej od tego ogłoszeniodawcy

Sprzątanie/ Pracownik gospodarczy Praca Żary
Rekrutacja

Żary

Pełny etat

Umowa zlecenie

Dzisiaj o 09:39


Ochrona Praca Dobczyce
Rekrutacja

Dobczyce

Pełny etat

Umowa zlecenie

Dzisiaj o 09:34


Ochrona praca od zaraz Łódź Bałuty/ Polesie/ Widzew
Rekrutacja

Łódź, Bałuty

Pełny etat

Umowa zlecenie

Odświeżono dzisiaj o 09:11


Sprzątanie praca magazyn logistyczny Wola Rakowa
Rekrutacja

Wola Rakowa

Pełny etat

Umowa zlecenie

Odświeżono dzisiaj o 08:55


Pracownik ochrony - Jasionka LPP
Jasionka

Pełny etat

Umowa zlecenie

Odświeżono dzisiaj o 08:46


Ochrona praca oniekt przemysłowy Zimna Wódka
Rekrutacja

Zimna Wódka

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dzisiaj o 08:45


Ochrona praca obiekt handlowy Wałbrzych
Wałbrzych

Pełny etat

Umowa zlecenie

Odświeżono dzisiaj o 08:40


Koordynator/ Koordynatorka ds ochrony fizycznej Gdańsk
Rekrutacja

Gdańsk, Śródmieście

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dzisiaj o 08:40


Koordynator/Koordynatorka ds ochrony fizycznej Poznań
Rekrutacja

Poznań, Stare Miasto

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dzisiaj o 08:37


Sprzątanie praca fabryka Gliwice
Rekrutacja

Gliwice, Łabędy

Pełny etat

Umowa zlecenie

Odświeżono dzisiaj o 07:52


Sprzątanie praca obiekt magazynowy Kokotów
Rekrutacja

Kokotów

Niepełny etat

Umowa zlecenie

Odświeżono dnia 29 września 2026


Ochrona pasaż/ informacja Zabrze
Rekrutacja

Zabrze

Pełny etat

Umowa o pracę, Umowa zlecenie

29 września 2026


Pracownik do prac porządkowych Bolesławiec.
Rekrutacja

Bolesławiec

Pełny etat

Umowa zlecenie

29 września 2026


Ochrona praca Galeria Puławy
Rekrutacja

Puławy

Pełny etat

Umowa zlecenie

Odświeżono dnia 29 września 2026


Sprzątanie praca Gorzów Wielkopolski
Rekrutacja

Gorzów Wielkopolski

Niepełny etat

Umowa zlecenie

29 września 2026

Zobacz też

pracownik ochrony (k/m) 12h dziennie
DNP Sp. z o.o.

Piła

Pełny etat

Umowa o pracę

23 września 2026


Pracownik ochrony (M/K/N) – Piła (Stogrosz, Aleja Poznańska)
Zakłady Mięsne ŁUKÓW S.A.

Piła

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026



operator produkcji/operatorka produkcji
Podanfol S.A.

6 000 - 12 000 zł / mies. brutto

Podanin

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026



Pracownik ochrony Piła. Obiekt handlowy (oferta również dla kobiet)
5 652 - 6 280 zł / mies. brutto

Piła

Pełny etat

Umowa zlecenie

Odświeżono dnia 29 września 2026



Ochrona - Piła - Time Group Polska
TIME GROUP POLSKA Sp. z o.o.

od 4 806 zł / mies. brutto

Piła

Niepełny etat

Umowa o pracę

Odświeżono dnia 23 września 2026



Pracownik ochrony - Dyspozytor
TERMETAL Piotr Glaner Sp. k.

5 500 - 6 500 zł / mies. brutto

Piła

Pełny etat

Umowa o pracę

Odświeżono dnia 25 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaBudowa / remontyPracownik ogólnobudowlanyPracownik ogólnobudowlany - MałopolskiePracownik ogólnobudowlany - Osiek
Odświeżono dnia 29 września 2026
Praca wykończenia wnętrz
Lokalizacja

Osiek

Wymiar pracy

Pełny etat

Typ umowy

Inny


Lokalizacja
Osiek


Static Map
Opis
Witam!!! Przyjmę do pracy Wykonujemy głównie gładzie oraz malowanie agregatami. Masz już doświadczenie - elegancko Nie masz doświadczenia - nauczymy Cię Wszelkie informacje zapraszam do kontaktu
Aplikuj
ID: 1100079874
Wyświetlenia: 218

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Kacper
Na OLX od październik 2014

Ostatnio online w dniu 22 września 2026


Zadzwoń / SMS
Aplikuj
Zobacz też

pracownik ogólnobudowlany
BT-SYSTEM SP. Z O.O.

6 800 - 10 000 zł / mies. brutto

Osiek

Pełny etat

Umowa o pracę, Samozatrudnienie, Umowa zlecenie

24 września 2026


Pracownik budowlany
Głębowice

Pełny etat

Umowa o pracę

18 września 2026


Praca w firmie ogrodniczej
Brzeszcze

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 28 września 2026


Pracownik ogólnobudowlany - OD ZARAZ
WMC

7 000 - 8 000 zł / mies. brutto

Kęty

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026


Pracownik Magazynowy - Pakowacz – Sklep internetowy E-commerce
ABC-RC.pl

5 000 - 5 500 zł / mies. brutto

Nidek

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 08:19


Poszukiwani murarze, zbrojarze i cieśle szalunkowi
8 000 - 12 000 zł / mies. brutto

Bielsko-Biała

Pełny etat

Umowa o pracę, Umowa zlecenie

27 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaBudowa / remontyGlazurnikGlazurnik - MazowieckieGlazurnik - Siedlce
Odświeżono dnia 29 września 2026
Praca dla glazurnikow i brukarzy
Lukaro - Bartłomiej Kryszczuk, Łukasz Kucharski s.c.
Wynagrodzenie

8 000 - 18 000 zł / mies. brutto

Lokalizacja

Siedlce

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę, Samozatrudnienie


Lokalizacja
Bronisława Krakówki 13

08-110 Siedlce

Wskazówki dojazdu




Static Map
Opis
Praca dla samodzielnych glazurników oraz ekip na powierzchniach przemysłowych. Praca dla ekip brukarskich na terenie Warszawy. Stawki z metra do ustalenia. Więcej informacji pod telefonem
Informacje Prawne
Wyrażam zgodę na przetwarzanie moich danych osobowych przez LUKARO – Bartłomiej Kryszczuk, Łukasz Kucharski s.c. w celu przeprowadzenia procesu rekrutacji na stanowisko glazurnika lub pomocnika glazurnika, zgodnie z Rozporządzeniem Parlamentu Europejskiego i Rady (UE) 2016/679 (RODO).
 
Aplikuj
ID: 1100089261

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Lukaro - Bartłomiej Kryszczuk, Łukasz Kucharski s.c.
Na OLX od październik 2015

Ostatnio online dziś o 11:55


Zadzwoń / SMS
Aplikuj
Mniej niż 5 kandydatów. Wykorzystaj swoją szansę.

Zobacz też
Pracownik do prac wykończeniowych
do 35 zł / godz. brutto

Siedlce

Pełny etat

Inny, Umowa o pracę, Samozatrudnienie, Umowa zlecenie

Odświeżono dnia 12 września 2026


BUDOWA DOMÓW SZKIELETOWYCH OD A DO Z
6 000 - 12 000 zł / mies. brutto

Siedlce

Pełny etat

Umowa o pracę

Odświeżono dnia 24 września 2026



Monter żurawi (k/m) na budowach
Sarens

Siedlce

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:14


Zatrudnię przy wykończeniach wnetrz
32 - 45 zł / godz. brutto

Siedlce

Pełny etat

Inny

Odświeżono dnia 28 września 2026


Brukarz/pomocnik brukarza, praca fizyczna
Siedlce

Pełny etat

Inny, Umowa o pracę, Umowa zlecenie

23 września 2026


Hydraulik / Monter Instalacji Sanitarnych i Grzewczych
PZW Sp. z o. o.

7 000 - 9 000 zł / mies. brutto

Siedlce

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
------------------------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaBudowa / remontyStolarzStolarz - MałopolskieStolarz - Bochnia
Odświeżono dnia 29 września 2026
Stolarz meblowy - praca na caly etat
Wynagrodzenie

5 000 - 10 000 zł / mies. brutto

Lokalizacja

Bochnia

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Bochnia


Static Map
Opis
Praca Poszukuje stolarza do skręcania mebli z płyt Wymagane doświadczenie Umowa o pracę
Aplikuj
ID: 1100017369
Wyświetlenia: 244

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Łukasz
Na OLX od grudzień 2012

Ostatnio online w dniu 25 września 2026


Zadzwoń / SMS
Aplikuj
Więcej od tego ogłoszeniodawcy
Lew Figura Z Brązu - Podstawa Z Marmuru - Wieczna Przyjażń
Lew Figura Z Brązu - Podstawa Z Marmuru - Wieczna Przyjażń

2 800 zł
Bochnia

Odświeżono dzisiaj o 11:23


Słoń Z Brązu - Patyna
Słoń Z Brązu - Patyna

1 500 zł
Bochnia

Odświeżono dzisiaj o 11:23


Kryształowy Żyrandol Żołądź Z Mosiądzem Fi 60 Cm
Kryształowy Żyrandol Żołądź Z Mosiądzem Fi 60 Cm

1 000 zł
Bochnia

Odświeżono dzisiaj o 11:23


Lampa - Żyrandol Ksiestwo Warszawskie Pająk Cieżki
Lampa - Żyrandol Ksiestwo Warszawskie Pająk Cieżki

779 zł
Bochnia

Odświeżono dzisiaj o 11:23


Lampa Naftowa Stara - Pałacowa -Wisząca
Lampa Naftowa Stara - Pałacowa -Wisząca

2 100 zł
Bochnia

Odświeżono dzisiaj o 11:23


Wisząca Lampa - Latarnia 55 Cm
Wisząca Lampa - Latarnia 55 Cm

420 zł
Bochnia

Odświeżono dzisiaj o 11:23


Złota Lampa Sufitowa Mosiądz! 100 Cm
Złota Lampa Sufitowa Mosiądz! 100 Cm

399 zł
Bochnia

Odświeżono dzisiaj o 11:23


Wisząca Lampa Kwiatowa - W Stylu Murano
Wisząca Lampa Kwiatowa - W Stylu Murano

480 zł
Bochnia

Odświeżono dzisiaj o 11:23


Lampa - Biały Lampion Do Zawieszania Metalowy
Lampa - Biały Lampion Do Zawieszania Metalowy

550 zł
Bochnia

Odświeżono dzisiaj o 11:23


Lampa Żyrandol Kryształ - Grzybek 70 X 50 Cm
Lampa Żyrandol Kryształ - Grzybek 70 X 50 Cm

1 600 zł
Bochnia

Odświeżono dzisiaj o 11:23


Wisząca Lampa Niebiesko - Zielona W Stylu Murono
Wisząca Lampa Niebiesko - Zielona W Stylu Murono

400 zł
Bochnia

Odświeżono dzisiaj o 11:23


Do wynajęcia  hala 300 m2  Wygoda - korbonskiego
Do wynajęcia hala 300 m2 Wygoda - korbonskiego

15 500 zł
Bochnia

Odświeżono dnia 29 września 2026

300 m²


Siedzący Napoleon Bonaparte - Figura Z Brązu 42 Cm
Siedzący Napoleon Bonaparte - Figura Z Brązu 42 Cm

2 150 zł
Bochnia

25 września 2026


Generał Guan Yu - Samurai Figura Z Brązu
Generał Guan Yu - Samurai Figura Z Brązu

1 950 zł
Bochnia

25 września 2026


Duży Krokodyl Z Brązu - Fontanna Gigant Aligator
Duży Krokodyl Z Brązu - Fontanna Gigant Aligator

32 000 zł
Bochnia

25 września 2026


Zobacz też
Stolarz produkcja i montaż mebli na wymiar
Kamil Majcher KAMAN

Bochnia

Pełny etat

Inny

24 września 2026



Stolarz meblowy - praca od zaraz
Artcor Sp. z o. o.

40 - 55 zł / godz. brutto

Bochnia

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 25 września 2026


Doświadczony Kucharz - Praca w Restauracji Bar Mleczny 2.0
KMS FOODS

6 000 - 12 000 zł / mies. brutto

Brzesko

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 27 września 2026


Poszukiwany stolarz meblowy
Bochnia

Pełny etat

Umowa o pracę

Odświeżono dnia 16 września 2026


Praca dla stolarza
ADPRO

6 000 - 9 000 zł / mies. brutto

Krzeczów

Pełny etat

Umowa o pracę

24 września 2026



Spawacz MIG/MAG/TIG – lekkie konstrukcje – praca na 2 zmiany
SHELMO Sp. z o.o.

Bochnia

Pełny etat

Umowa o pracę, Samozatrudnienie, Umowa zlecenie

Odświeżono dnia 29 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaGastronomiaPracownik restauracji fast-foodPracownik restauracji fast-food - MałopolskiePracownik restauracji fast-food - KrakówPracownik restauracji fast-food - Czyżyny
McDonald's Polska nr 319
Odświeżono dnia 29 września 2026

Pracownik/Pracownica zmiany nocnej
McDonald's Polska Sp. z o.o. Dowiedz się więcej
Wynagrodzenie

od 28,61 zł / godz. brutto

Lokalizacja

Kraków, Czyżyny

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Kraków, Czyżyny


Static Map
Opis
McDONALD'S KRAKOW CZYZYNY (319) - DOBRZE BYĆ CZĘŚCIĄ ZESPOŁU!

Pracownik/Pracownica zmiany nocnej

Stawka już od 28,61 zł brutto/godz

Szukasz pracy, która dopasuje się do Twojego stylu życia? Dołącz do McDonald's! Wolisz pracować, gdy inni śpią? Chcesz zobaczyć, jak wygląda restauracja nocą? To dobre miejsce, żeby spróbować!

Co zyskujesz?

JASNE WARUNKI, STABILNOŚĆ I ELASTYCZNOŚĆ
Zatrudnienie na podstawie umowy o pracę
Stawka: 28,61 zł brutto/godz
Dodatek w wysokości 20% za każdą godzinę pracy w porze nocnej, od 23:00 do 7:00
Elastyczny grafik, który możesz dopasować do swojego życia, także w niepełnym wymiarze godzin
Zniżki w restauracjach McDonald's w całej Polsce
Rabaty na posiłki w pracy
Możliwość otrzymania bonusu za polecenie znajomego do pracy (dotyczy restauracji oferujących ten program)
Szukamy osób z energią do działania, otwartych na współpracę i gotowych do nauki.

Nie musisz mieć doświadczenia - wszystkiego Cię nauczymy.

Czym zajmuje się pracownik/pracowniczka zmiany nocnej?

Pracuje w godzinach nocnych, między 21:00 a 7:00, dbając o sprawne funkcjonowanie restauracji. Przygotowuje produkty, obsługuje gości i realizuje sprzedaż. Dba również o porządek, czyści i konserwuje sprzęt, przyjmuje i rozkłada dostawy oraz przygotowuje restaurację do otwarcia kolejnego dnia.

Chcesz stać się częścią zespołu McDonald's? Aplikuj na lub wypełnij ulotkę rekrutacyjną w restauracji McDonald's KRAKOW CZYZYNY (319).

Poznaj nas i przekonaj się, że to miejsce dla Ciebie.

Aplikuj teraz
ID: 1099681072

Zgłoś
O firmie

McDonald's Polska Sp. z o.o.
Branża
Gastronomia
Wielkość firmy
1001+
Lokalizacja
Warszawa
Oferujemy naszym gościom za rozsądną cenę smaczne posiłki i profesjonalną obsługę w czystym i przyjemnym otoczeniu.

Troszczymy się o naszych ludzi i jesteśmy przekonani do założeń naszego biznesowego systemu. Bazuje on na trzech filarach: franczyzobiorcach, dostawcach i pracownikach firmy. Zachowanie równowagi interesów pomiędzy tymi grupami jest kluczowe.

Prowadzimy naszą działalność uczciwie, sprawiedliwie i rzetelnie. Rozwijamy naszą firmę z zyskiem, wspieramy Fundację Ronalda McDonalda® i pomagamy w procesie budowy lepszych lokalnych społeczności.

Chcemy wykorzystać wielkość, możliwości i środki naszej firmy, aby uczynić świat lepszym.


Pokaż więcej
Zobacz profil pracodawcy
Rekruter


McDonald's Polska Sp. z o.o.
Na OLX od lipiec 2026

Ostatnio online w dniu 24 września 2026

Aplikuj teraz
Zobacz profil pracodawcy
Więcej od tego ogłoszeniodawcy
Zobacz wszystkie


Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 29 zł / godz. brutto

Poznań, Łazarz

Pełny etat

Umowa o pracę

Dzisiaj o 11:39



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Bielsko-Biała

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:37



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 29,70 zł / godz. brutto

Żyrardów

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:36



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Kielce

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:35



Pracownik/Pracownica zmiany nocnej
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Łaziska

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:35



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Poznań, Łacina

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:33



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,61 zł / godz. brutto

Kołobrzeg

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:33



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,61 zł / godz. brutto

Lublin

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:31



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Leszno

Pełny etat

Umowa o pracę

Dzisiaj o 11:31



Manager/Managerka
McDonald's Polska Sp. z o.o.

od 37 zł / godz. brutto

Białystok, Przydworcowe

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:30



Pracownik/Pracownica zmiany nocnej
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Warszawa, Włochy

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 10:47



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Warszawa, Włochy

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 10:46



Pracownik / Pracownica restauracji McDonald’s
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Gdańsk, Kokoszki

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 09:04



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Jędrzejów

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 09:04



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 29,61 zł / godz. brutto

Kłaj

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 09:03



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,70 zł / godz. brutto

Ostrów Wielkopolski

Pełny etat

Umowa o pracę

Dzisiaj o 07:31

Zobacz też

Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,61 zł / godz. brutto

Kraków, Czyżyny

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026



Pracownik/Pracownica restauracji
McDonald's Polska Sp. z o.o.

od 28,61 zł / godz. brutto

Kraków, Krowodrza

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026



Pracownik produkcji - I zmiana
5 000 - 6 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Odświeżono dnia 27 września 2026



Pracownik Ochrony Fizycznej [K/M] Kraków
Solid Security Sp. z o.o.

Kraków, Stare Miasto

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 29 września 2026


Pracownik na Produkcji - stałe zatrudnienie umowa o pracę
7 500 - 8 000 zł / mies. brutto

Kraków, Podgórze

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026



7000 netto | Робота в Кракові | Склад шин | Комплектація замовлень | Високі премії | Без досвіду
8 000 - 11 500 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa zlecenie

Odświeżono dzisiaj o 09:14


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
-----------------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaPrace magazynowePrace magazynowe - DolnośląskiePrace magazynowe - Trzebnica

Odświeżono dzisiaj o 12:11

Amazon | 38,52 zł/godz. brutto* | +2200 brutto**
Randstad Polska Sp. z o.o. Dowiedz się więcej
Lokalizacja

Trzebnica

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Trzebnica


Static Map
Opis
Poszukujemy pracowników na stanowisko pracownika magazynu w Bielanach Wrocławskich k. Wrocławia.

 

Centrum Logistyki Amazon, podwyższa stawkę! Pracuj i zyskaj więcej, bo to Twoja zmiana i Twoja nowa, wyższa stawka godzinowa 38,52 zł/godz. brutto*     

Oprócz tego możesz liczyć na +2200 zł brutto** ekstra. Poleć znajomych do pracy, Ty i osoba polecona zyskacie wspólnie do 5000 zł brutto***!

 

Nie wymagamy od Ciebie doświadczenia. Możesz liczyć na  wsparcie wyspecjalizowanych instruktorów.

zadania

rozkładanie towarów na półki magazynu
załadunek i rozładunek przesyłek
kompletowanie, pakowanie i przygotowywanie towaru do wysyłki
obsługa skanera ręcznego
oczekujemy

gotowości i zdolności do pracy w trybie zmianowym - na zmianie dziennej i nocnej
braku przeciwwskazań do stania/chodzenia przez 10 godzin
sumienności i skrupulatności w wykonywaniu obowiązków
oferujemy

stawkę do 38,52 zł/godz. brutto*
+2200 brutto** ekstra
bonus za polecenie - poleć do pracy swojego znajomego i otrzymajcie razem bonus w wysokości do 5000 zł**
dodatek za pracę w godzinach nocnych
praca 4 dni w tygodniu, 3 dni wolnego (praca w pełnym wymiarze godzin)
umowę o pracę tymczasową (ze składką ZUS i płatnymi urlopami)
pakiet RANDSTAD PLUS, a w nim takie atrakcje, jak: karta sportowa Medicover Sport, pakiet medyczny Medicover oraz rabaty do 50% w wybranych sklepach
długą, stabilną, rozwijającą współpracę
gorące napoje i obiady z pysznym i różnorodnym menu za złotówkę
bezpłatny dojazd autobusem pracowniczym na wybranych trasach
Zaaplikuj lub zadzwoń na nr 22 454 44 44 lub +488*****777 (numer bezpłatny)

*Suma podstawowej stawki godzinowej oraz premii specjalnej za frekwencję.

**Szczegóły podczas rekrutacji.

***zgodnie z regulaminem dostępnym na stanowisku Randstad.

 

Agencja zatrudnienia – nr wpisu 47

ta oferta pracy przeznaczona jest dla osób powyżej 18 roku życia

 

 

 

Aplikuj teraz
ID: 1096939299

Zgłoś
O firmie

Randstad Polska Sp. z o.o.
Partner for talent.
Branża
Zasoby Ludzkie i Rekrutacja
Wielkość firmy
751-1000
Lokalizacja
Warszawa
Randstad Polska jest częścią Randstad N.V. – najbardziej wyspecjalizowanej firmy na świecie działającej na rzecz talentów, która dba o wyrównywanie szans.

Działając w ramach czterech specjalizacji – Operational, Professional, Digital i Enterprise – zapewniamy firmom wykwalifikowane, zróżnicowane i elastyczne zespoły, które wspierają ich w osiąganiu biznesowych sukcesów w świecie deficytu talentów. Poszukujących zatrudnienia wspieramy w zdobywaniu ważnych dla nich ról zawodowych, rozwoju właściwych kompetencji, odnajdywaniu celu i poczucia przynależności w miejscu pracy.

W Randstad pomożemy Ci znaleźć pracę, która odpowiada Twoim kwalifikacjom, wspiera równowagę między życiem zawodowym a prywatnym i Twoje cele. Współpracujemy z najlepszymi pracodawcami na rynku, zapewniając szerszy dostęp do całej gamy różnorodnych możliwości, które w większym stopniu wspierają Twoje ambicje zawodowe - bez względu na to, czy poszukujesz zatrudnienia stałego, tymczasowego czy kontraktowego. Nie tylko pomożemy znaleźć Ci pracę; pomagamy też rozwijać Twoje umiejętności i wiedzę. Dzięki inicjatywom wspierającym rozwój, wsparciu online, indywidualnemu coachingowi i centrach talentów na całym świecie, zapewniamy narzędzia i zasoby umożliwiające rozwój umiejętności i utrzymanie pozycji na konkurencyjnym rynku pracy.

Naszym priorytetem jest pozostawanie z Tobą w relacji na każdym etapie Twojego życia zawodowego. Współpracując z Randstad, zyskujesz partnera, który dba o Twoje dobre samopoczucie, zapewnia indywidualne podejście i nieustannie wspiera Cię w podążaniu satysfakcjonującą ścieżką kariery.


Pokaż więcej
Zobacz profil pracodawcy
Rekruter


Randstad Polska Sp. z o.o.
Na OLX od wrzesień 2017

Ostatnio online w dniu 28 września 2026


Zadzwoń / SMS
Aplikuj teraz
Zobacz profil pracodawcy
Więcej od tego ogłoszeniodawcy
Zobacz wszystkie


Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Oleśnica, Oleśnica

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Bożnowice

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



pracownik produkcji ( k / m) | od zaraz | zorganizowany transport z Lubawki oraz Kamiennej Góry !
Randstad Polska Sp. z o.o.

Kamienna Góra

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Dzierżoniów

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Wrocław, Stare Miasto

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Kamiennik

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Strzegom

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Oborniki Śląskie

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Głuchołazy

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Randstad Polska Sp. z o.o.

Brzeg

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



Zbuduj swoją karierę w technice! Praca: Operator Procesu Produkcji (k/m/n)
Randstad Polska Sp. z o.o.

od 7 500 zł / mies. brutto

Lubań

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11



pracownik produkcji | 4900 zł brutto + wysokie premie | wolne weekendy | od zaraz
Randstad Polska Sp. z o.o.

od 4 900 zł / mies. brutto

Zabrze

Pełny etat

Umowa o pracę

Dzisiaj o 12:03



pracownik produkcji / pracownica produkcji > bez doświadczenia > OD ZARAZ > sanepid > szybkie zatrudnienie
Randstad Polska Sp. z o.o.

Radzyń Podlaski

Pełny etat

Umowa o pracę

Dzisiaj o 11:35



Asystent/ka w dziale logistyki
Randstad Polska Sp. z o.o.

Warszawa, Mokotów

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:31



Accounting Assistant with English
Randstad Polska Sp. z o.o.

Gdańsk, Oliwa

Pełny etat

Umowa zlecenie, Umowa o pracę

Dzisiaj o 11:03

Zobacz też
Zlecenie związane z wykładaniem towaru w Trzebnicy
32 - 32,50 zł / godz. brutto

Trzebnica

Niepełny etat

Umowa zlecenie

Odświeżono dnia 28 września 2026



Amazon | 38,52 zł/godz. brutto* | +2200 brutto**
Randstad Polska Sp. z o.o.

Trzebnica

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:23



Magazynier z doświadczeniem SKLEPCARAUDIO PL
Wrocław, Krzyki

Pełny etat

Umowa o pracę, Samozatrudnienie, Umowa zlecenie

29 września 2026


Pracownik sklepu Żabka
Trzebnica

Pełny etat

Umowa zlecenie

Odświeżono dnia 24 września 2026



Praca Specjalista / Specjalistka Obsługi Klienta Stacja Paliw bp Wisznia Mała
BP POLSKA SERVICES SP. Z O.O.

5 650 - 5 800 zł / mies. brutto

Trzebnica

Pełny etat

Umowa o pracę

24 września 2026


Magazynier do hurtowni w Krzykach
31,40 - 36 zł / godz. brutto

Wrocław, Krzyki

Pełny etat

Umowa zlecenie

29 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
----------------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaBudowa / remontyPracownik ogólnobudowlanyPracownik ogólnobudowlany - Warmińsko-mazurskiePracownik ogólnobudowlany - Korsze
Odświeżono dzisiaj o 10:08
Pracownik budowlany/ monter konstrukcji stalowych, płyt warstwowych
UCD Wrona
Wynagrodzenie

8 000 - 16 000 zł / mies. brutto

Lokalizacja

Korsze

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę, Samozatrudnienie, Umowa zlecenie


Lokalizacja
Wojska Polskiego 35

11-430 Korsze

Wskazówki dojazdu




Static Map
Opis
Zajmujemy się kompleksowym wykonaniem hal produkcyjno-magazynowych, obiektów przetwórstwa rolno-spożywczego oraz obiektów technologicznych. Prace rozpoczynamy na etapie montażu konstrukcji stalowej a kończymy po obudowaniu całego obiektu. Praca w delegacji w Polsce oraz Europie

Stała podstawa - premia za wyniki + delegacje

ZAKRES OBOWIAZKOW:

Montaż konstrukcji stalowych

Montaż obudowy płytą warstwową

Montaż blachy trapezowej

Montaż pokryć dachowych

Prace ogólnobudowlane

Odpowiedzialność i dbałość o powierzone narzędzia oraz materiały budowlane

MILE WIDZIANE:

Posiadania doświadczenie na stanowisku Pracownika Ogólnobudowlanego lub pokrewnym

Umiejętność czytania i interpretowania rysunków technicznych

Znajomość przepisów BHP i umiejętność stosowania ich w praktyce

Umiejętność procy w zespole oraz komunikatywność w kontakcie z innymi pracownikami

Samodzielność w wykonywaniu zadań i dbałość o terminowość ich realizacji

Chęć do rozwoju zawodowego i zdobywania nowych umiejętności

WYMAGANIA

Zdolności manualne i sprawność fizyczna, umożliwiające wykonywalne różnych prac fizycznych na placu budowy

Gotowość do pracy w różnych warunkach atmosferycznych i na wysokościach

Znajomość podstawowych technik budowlanych oraz umiejętność obsługi niezbędnych narzędzi i maszyn budowlanych

KLAUZULA INFORMACYJNA O PRZETWARZANIU DANYCH DO ZAWARCIA W CV

Wyrażam zgodę na przetwarzanie moich danych osobowych dla potrzeb niezbędnych do realizacji procesu rekrutacji (zgodnie z ustawa z dnia 10 maja 2018 roku o ochronie danych osobowych [Dz. Ustaw z 2018, poz, 1000) oraz zgodnie z Rozporządzeniem Parlamentu Europejskiego i Redy (UE) 2016/679 z dnia 27 kwietnia 2015 r. w sprawie ochrony osób fizycznych w związku z przetwarzaniem danych osobowych i w sprawie swobodnego przepływu takich danych oraz uchylenia dyrektywy 95/46/WE (RODO).

Aplikuj
ID: 1077045363

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

UCD Wrona
Na OLX od listopad 2020

Ostatnio online w dniu 28 września 2026


Zadzwoń / SMS
Aplikuj
Więcej od tego ogłoszeniodawcy
Volkswagen crafter L3H3 7 osobowy brygadówka  69 000 netto+vat
Volkswagen crafter L3H3 7 osobowy brygadówka 69 000 netto+vat

84 870 zł
Korsze

Odświeżono dzisiaj o 09:50



Zobacz też
Pracownik ogólnobudowlany
ELEKTRYK-US Michał Pliszka

7 000 - 8 000 zł / mies. brutto

Reszel

Pełny etat

Umowa o pracę

20 września 2026


Pomocnik glazurnika
5 000 - 8 000 zł / mies. brutto

Kętrzyn

Pełny etat

Inny

01 września 2026


Zbieraczka/zbieracz pieczarek
Mrągowo

Pełny etat

Umowa o pracę

27 września 2026


Pracownik budowlany Wykończeniowiec
SAVALS

75 - 110 zł / mies. brutto

Kętrzyn

Pełny etat

Umowa zlecenie

Odświeżono dnia 24 września 2026


Monter/ technik światłowodu
5 000 - 7 000 zł / mies. brutto

Kętrzyn

Pełny etat

Inny, Umowa zlecenie

21 września 2026


Handlowiec | Auto służbowe | Gotowi klienci | Stała pensja + prowizja
EASYEKO sp. z o.o.

6 800 - 23 000 zł / mies. brutto

Olsztyn

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 29 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
-------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaPraca za granicąPraca za granicą - PodkarpackiePraca za granicą - Rzeszów
Odświeżono dnia 29 września 2026
Prace ogólnobudowlane w Danii
Lokalizacja

Rzeszów

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Kraj: Dania


Static Map
Opis
Duńska firma poszukuje pracowników do prac ogólnobudowlanych na terenie Danii (Kopenhaga)

Zapewniamy:

- Stawka 160-190dkk/h brutto w zależności od umiejętności (SH, feriepenge)

- Rotacja 4tyg / 2tyg

- Duńską umowę o prace

- Zakwaterowanie (odpłatnie)

- Dojazdy do pracy

Jeżeli jesteś zainteresowany albo masz pytania skontaktuje się z nami pod numer telefonu +4.5.5.1.8.9.8.8.2.9. albo wyślij nam swoje CV a my oddzwonimy. Nie wymagamy znajomosci języka angielskiego.

Aplikuj
ID: 1099959068

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Bartoszzz87
Na OLX od wrzesień 2023

Ostatnio online w dniu 22 września 2026


Zadzwoń / SMS
Aplikuj
Zobacz też
Praca w Danii, prace ogólnobudowlane - od zaraz
Kamień Pomorski

Pełny etat

Umowa o pracę

Odświeżono dnia 20 września 2026


Praca w danii stałe zatrudnienie
17 000 - 20 000 zł / mies. brutto

Pyrzyce

Pełny etat

Umowa o pracę

16 września 2026


praca w Belgii jako monter - pomocnik rusztowan
12 000 - 16 000 zł / mies. brutto

Rzeszów

Pełny etat

Umowa zlecenie

Odświeżono dnia 28 września 2026


Praca w Danii - rozbiórki
Koszalin

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026


Szukamy osób do pracy w Danii
Kraków, Stare Miasto

Pełny etat

Umowa o pracę

23 września 2026



Pracuj jako operator maszyn w Holandii! Atrakcyjne wynagrodzenie!
Grupa Contrain

10 000 - 12 500 zł / mies. brutto

Rzeszów

Pełny etat

Umowa o pracę

28 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
-----------------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaProdukcjaObsługa produkcjiObsługa produkcji - MałopolskieObsługa produkcji - KrakówObsługa produkcji - Nowa Huta

Odświeżono dzisiaj o 10:59

PRACA. Operator/operatorka suwnicy. KRAKÓW
EKO ENERGIA Sp. z o.o. Dowiedz się więcej
Wynagrodzenie

4 806 - 6 000 zł / mies. brutto

Lokalizacja

Kraków, Nowa Huta

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Ujastek 1

31-752 Kraków, Nowa Huta

Wskazówki dojazdu




Static Map
Opis
Zakres obowiązków:

1.      obsługa suwnic zgodnie z obowiązującymi przepisami BHP,

2.      transport i przemieszczanie materiałów na terenie zakładu,

3.      prawidłowe zabezpieczanie i podwieszanie ładunków,

4.      kontrola stanu technicznego urządzeń przed rozpoczęciem pracy,

5.      dbanie o porządek i bezpieczeństwo na stanowisku pracy.

Wymagania:

1.      uprawnienia UDT do obsługi suwnic,

2.      doświadczenie na podobnym stanowisku będzie dodatkowym atutem,

3.      odpowiedzialność i dokładność,

4.      dyspozycyjność i zaangażowanie,

5.      przestrzeganie zasad BHP.

To oferujemy

Stabilną pracę oraz możliwość rozwoju i poszerzenia kwalifikacji

Uczestnictwo w ciekawych projektach inwestycyjnych

Wynagrodzenie adekwatne do posiadanych kwalifikacji i umiejętności

Przyjazną atmosferę pracy

Pakiet świadczeń dodatkowych w tym opiekę medyczną, ubezpieczenie grupowe, możliwość korzystania z obiektów sportowych

Aplikuj
ID: 1100201750

Zgłoś
O firmie

EKO ENERGIA Sp. z o.o.
Realizacja projektów inwestycyjnych dla przemysłu i obiektów użyteczności publicznej
Branża
Energetyka, Górnictwo i Usługi Użyteczności Publicznej
Wielkość firmy
201-500
Lokalizacja
Kraków
Od czerwca 2000 roku EKO-ENERGIA działa na rynku jako samodzielny podmiot. Ci, którzy współpracują z nami od lat wiedzą, że przeszliśmy metamorfozę od niewielkiej, 80-cio osobowej Firmy, działającej lokalnie do dość sporej Organizacji (ponad 250 zatrudnionych) o ogólnopolskim zasięgu.

W przeciągu tych lat zmienił się nie tylko zasięg działania, wielkość Firmy, siedziba, ale i struktura własnościowa. Pod koniec 2009 roku Firma została wykupiona od dotychczasowego Właściciela, jakim był ArcelorMittal Poland SA (uprzednio Polskie Huty Stali, a jeszcze wcześniej Huta im.T.Sendzimira) i w chwili obecnej jest zupełnie samodzielną, niezależną Organizacją.

EKO-ENERGIA działa na szeroko pojętym rynku usług w branży elektro-energetycznej, z orientacja na ochronę środowiska i nowe technologie. Wciąż dodajemy nowe pozycje do naszej oferty, kierując się potrzebami Klientów i rynku, stawiając szczególny nacisk na jakość zrealizowanych zadań


Pokaż więcej
Zobacz profil pracodawcy
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter


EKO ENERGIA Sp. z o.o.
Na OLX od listopad 2025

Ostatnio online dziś o 09:04


Zadzwoń / SMS
Aplikuj
Zobacz profil pracodawcy
Więcej od tego ogłoszeniodawcy
Zobacz wszystkie


Os. do wyk. prac przy utrzymaniu ruchu mechanicznego i elektrycznego.
EKO ENERGIA Sp. z o.o.

6 000 - 8 000 zł / mies. brutto

Częstochowa, Raków

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:32



PRACA Operator/ka prac ślusarsko- spawalniczych. Częstochowa
EKO ENERGIA Sp. z o.o.

6 000 - 7 000 zł / mies. brutto

Częstochowa, Wyczerpy - Aniołów

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 11:00



PRACA! Ślusarz- monter K/M . Kraków
EKO ENERGIA Sp. z o.o.

6 000 - 7 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Dzisiaj o 09:08



PRACA Osoba do nadzoru nad produkcją i pracami remontowymi. AMP DG
EKO ENERGIA Sp. z o.o.

6 500 - 7 500 zł / mies. brutto

Dąbrowa Górnicza

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



PRACA Operator/ka procesów ślusarsko-spawalniczych Dąbrowa Górnicza
EKO ENERGIA Sp. z o.o.

5 000 - 7 000 zł / mies. brutto

Dąbrowa Górnicza

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



PRACA. Inżynier/ka Elektryk Kraków Nowa Huta
EKO ENERGIA Sp. z o.o.

7 000 - 8 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



PRACA Inżynier/ inżynierka budowy DG
EKO ENERGIA Sp. z o.o.

7 000 - 9 000 zł / mies. brutto

Dąbrowa Górnicza

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



PRACA. Spacjalista/tka ds ofertowania- maszyny elektryczne KRK
EKO ENERGIA Sp. z o.o.

5 500 - 7 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



PRACA Elektromonter K/M. Kraków, Częstochowa
EKO ENERGIA Sp. z o.o.

5 500 - 7 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



PRACA Inżynier/ inżynierka budowy
EKO ENERGIA Sp. z o.o.

8 000 - 12 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Odświeżono dnia 24 września 2026

Płyty gumowe wibroizolacyjne. OKAZJA.
Płyty gumowe wibroizolacyjne. OKAZJA.

40 zł
Kraków, Czyżyny

Odświeżono dnia 14 września 2026


Zobacz też
Monter Nawierzchni Kolejowej, Monterka Nawierzchni Kolejowej
4 806 - 7 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

02 września 2026



Operator maszyn (k/m)
7 000 - 7 500 zł / mies. brutto

Kraków, Grzegórzki

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



Operator Ciągnika Terminalowego C+E/ TEREBERG/
do 9 500 zł / mies. brutto

Kraków, Bronowice

Pełny etat

Umowa o pracę

28 września 2026


Praca operator suwnic ŚWINOUJŚCIE
Świnoujście

Pełny etat

Umowa o dzieło, Inny, Umowa o pracę, Samozatrudnienie, Umowa zlecenie

Odświeżono dnia 25 września 2026



Pracownik elektrociepłowni - operator urządzeń (K/M)
Adecco Poland Sp. z o.o.

Kraków, Wzgórza Krzesławickie

Pełny etat

Umowa o pracę

Odświeżono dnia 22 września 2026



Pracownik produkcji - I zmiana
5 000 - 6 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Odświeżono dnia 27 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
---------------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaProdukcjaObsługa produkcjiObsługa produkcji - PomorskieObsługa produkcji - Kartoszyno
Odświeżono dzisiaj o 11:40
Poszukujemy pracowników do pracy
Agro-Fish Sp. z o.o.
Wynagrodzenie

5 500 - 6 000 zł / mies. brutto

Lokalizacja

Kartoszyno

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Żarnowiecka 2

84-110 Kartoszyno

Wskazówki dojazdu




Static Map
Opis
Firma Agro-Fish Sp. z o.o. poszukuje operatorów maszyn do produkcji karma dla psów i kotów w miejscowości Kartoszyno . Po przyuczeniu pracownik samodzielnie będzie prowadził proces produkcyjny .

Wszelkie dodatkowe informacje pod nr. kom. 60*******55.

Aplikuj
ID: 1101175524

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Agro-Fish Sp. z o.o.
Na OLX od wrzesień 2026

Ostatnio online w dniu 28 września 2026


Zadzwoń / SMS
Aplikuj
Mniej niż 5 kandydatów. Wykorzystaj swoją szansę.

Zobacz też
Praca przy budowie domkow mobilnych
5 000 - 10 000 zł / mies. brutto

Kartoszyno

Pełny etat

Umowa o pracę

Odświeżono dnia 26 września 2026


Pracownik produkcji prefabrykatów betonowych/ stolarz cieśla
Korporacja Budowlana Dom Sp. z o.o.

Kartoszyno

Pełny etat

Umowa o pracę

24 września 2026



Pracownik Produkcji Przetwórstwa Rybnego
LIBRU SEA SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ

Strzebielinko

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 08:47


Pracownik hali prefabrykacji betonowej
MM-Tech Sp. z o.o.

6 000 - 7 500 zł / mies. brutto

Gniewino

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 09 września 2026



Kwalifikowany Pracownik Ochrony (k/m)
Solid Security Sp. z o.o.

Krokowa

Pełny etat

Umowa o pracę

Odświeżono dnia 20 września 2026


BRYGADZISTA / BRYGADZISTKA HYDRAULKI - stabilne warunki zatrudnienia
37 - 50 zł / godz. brutto

Wejherowo

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
---------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaGastronomiaKucharzKucharz - MałopolskieKucharz - KrakówKucharz - Bieżanów-Prokocim
Dodane dzisiaj o 12:10
Restauracja ALDENTE (kozłówek) zatrudni Kucharza/Kucharkę wydawkowego
ROMA S.C. Tomasz Włodarczyk, Emilia Kurnik
Wynagrodzenie

30 - 40 zł / godz. brutto

Lokalizacja

Kraków, Bieżanów-Prokocim

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę


Lokalizacja
Spółdzielców 3

30-682 Kraków, Bieżanów-Prokocim

Wskazówki dojazdu




Static Map
Opis
KUCHARZ / KUCHARKA WYDAWKOWY/A – RESTAURACJA ALDENTE

Restauracja AlDente w Krakowie przy ul. Spółdzielców 3 poszukuje osoby na stanowisko kucharza/kucharki wydawkowego/ej.

Szukamy osoby, która chce związać się z nami na stałe. Zależy nam na długofalowej współpracy i osobie, która ceni sobie dobrą atmosferę, wzajemny szacunek oraz pracę w zgranym zespole. U nas naprawdę liczy się dobra atmosfera i współpraca.

Miejsce pracy: Kraków, ul. Spółdzielców 3 System pracy: zmianowy 2/2

Zakres obowiązków:

przygotowywanie i wydawanie dań,

dbanie o estetykę i jakość wydawanych potraw,

współpraca z zespołem kuchni,

utrzymywanie porządku i przestrzeganie zasad higieny pracy.

Oczekujemy:

doświadczenia w pracy na kuchni,

dobrej organizacji pracy,

zaangażowania i odpowiedzialności,

umiejętności pracy w zespole,

chęci do stałej współpracy.

o naszego zespołu AlDente!

Co oferujemy?

stabilne zatrudnienie i możliwość długofalowej współpracy,

pracę w zgranym zespole i świetnej atmosferze,

system pracy 2/2,

przyjazne i szanujące się środowisko pracy.

Zainteresowane osoby prosimy o kontakt od poniedziałku do piątku w godzinach 8:00–17:00.

Kontakt: 73*******04

Aplikuj
ID: 1097387440

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

ROMA S.C. Tomasz Włodarczyk, Emilia Kurnik
Na OLX od styczeń 2020

Ostatnio online dziś o 12:00


Zadzwoń / SMS
Aplikuj
Więcej od tego ogłoszeniodawcy

Zatrudnimy pizzera/pizzerke Kraków/Kozłówek
ROMA S.C. Tomasz Kozieł, Tomasz Włodarczyk

30 - 35 zł / godz. brutto

Kraków, Bieżanów-Prokocim

Pełny etat

Inny, Umowa o pracę, Umowa zlecenie

16 września 2026

Zobacz też
Potrzebna KUCHARKA /KUCHARZ od zaraz
5 000 - 6 000 zł / mies. brutto

Kraków, Czyżyny

Pełny etat

Umowa o pracę

Odświeżono dnia 10 września 2026


Kucharz śniadaniowy do Premier Kraków Hotel (m/k)
CFI Hotels Group

32 - 38 zł / godz. brutto

Kraków, Prądnik Biały

Pełny etat

Umowa zlecenie

Odświeżono dnia 10 września 2026


Pracownik małej gastronomii kebab i smash burger
31 - 34 zł / godz. brutto

Kraków, Bieżanów-Prokocim

Pełny etat

Umowa zlecenie

Odświeżono dnia 19 września 2026


Kucharz, kucharka w stołówce szkolnej
4 806 - 5 800 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę, Umowa zlecenie

18 września 2026


Zatrudnimy pizzera/pizzerke Kraków/Kozłówek
ROMA S.C. Tomasz Kozieł, Tomasz Włodarczyk

30 - 35 zł / godz. brutto

Kraków, Bieżanów-Prokocim

Pełny etat

Inny, Umowa o pracę, Umowa zlecenie

16 września 2026


KUCHARZ ZMIANOWY z doświadczeniem restauracyjnym
8 000 - 11 000 zł / mies. brutto

Dobczyce

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 23 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
---------------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaPracownik sklepuKasjer, pracownik sklepuKasjer, pracownik sklepu - MałopolskieKasjer, pracownik sklepu - KrakówKasjer, pracownik sklepu - Grzegórzki
Odświeżono dnia 29 września 2026

Osoba na Stanowisko Sprzedawca / Aktualne / Soboty
Wędliny Zalewski
Lokalizacja

Kraków, Grzegórzki

Wymiar pracy

Praca dodatkowa

Typ umowy

Umowa o dzieło, Inny, Umowa zlecenie


Lokalizacja
Kraków, Grzegórzki


Static Map
Opis
Opis

Dzień Dobry,

Poszukujemy Osób na stanowisko:

Ekspedientka/Sprzedawca

Miejsce Pracy:

Kraków - Hala Targowa

ul. Grzegórzecka

Czas Pracy:

Sobota 6-14:30

Sklep z Wędlinami (Bez Mięsa)

Mile widziane doświadczenie w handlu,

Poszukujemy miłej, sympatycznej osoby do pracy.

W razie zainteresowania lub pytań zapraszamy do kontaktu telefonicznego.

CV można składać również przez formularz OLX

Zapraszamy

Aplikuj
ID: 978209756

Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?


Zadaj pytanie
Rekruter

Wędliny Zalewski
Na OLX od lipiec 2014

Ostatnio online wczoraj o 13:17


Zadzwoń / SMS
Aplikuj
Więcej od tego ogłoszeniodawcy


Sprzedawca / Ekspedientka / Aktualne
5 000 - 5 500 zł / mies. brutto

Kraków, Grzegórzki

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dzisiaj o 11:25



Osoba na Stanowisko Sprzedawca / Aktualne / Soboty
Wędliny Zalewski

Kraków, Nowa Huta

Praca dodatkowa

Umowa o dzieło, Inny, Umowa zlecenie

Odświeżono dnia 29 września 2026



Osoba na Stanowisko Sprzedawca / Aktualne / Soboty
Wędliny Zalewski

Kraków, Łagiewniki-Borek Fałęcki

Praca dodatkowa

Umowa o dzieło, Inny, Umowa zlecenie

Odświeżono dnia 29 września 2026



Ekspedientka / Aktualne
5 000 - 5 500 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę, Umowa zlecenie

29 września 2026



Sprzedawca / Ekspedientka / Aktualne
5 000 - 5 500 zł / mies. brutto

Kraków, Czyżyny

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 29 września 2026



Ekspedientka /Sprzedawca / Aktualne
Wędliny Zalewski

5 000 - 5 500 zł / mies. brutto

Jaworzno

Niepełny etat

Inny, Umowa zlecenie

Odświeżono dnia 28 września 2026

Zobacz też
Praca w soboty przy rozkładaniu towaru
Kraków, Krowodrza

Praca dodatkowa

Umowa zlecenie

23 września 2026



Osoba na Stanowisko Sprzedawca / Aktualne / Soboty
Wędliny Zalewski

Kraków, Łagiewniki-Borek Fałęcki

Praca dodatkowa

Umowa o dzieło, Inny, Umowa zlecenie

Odświeżono dnia 29 września 2026



Praca dla Studentki dziennej/zaocznej Królowa Shoppingu Kraków Galeria Bronowice
31,40 - 32 zł / godz. brutto

Kraków, Prądnik Biały

Niepełny etat

Umowa o pracę, Umowa zlecenie

29 września 2026



Osoba na Stanowisko Sprzedawca / Aktualne / Soboty
Wędliny Zalewski

Kraków, Nowa Huta

Praca dodatkowa

Umowa o dzieło, Inny, Umowa zlecenie

Odświeżono dnia 29 września 2026


WYPŁATA CO WEEKEND - praca w sklepie
Kraków, Czyżyny

Praca dodatkowa

Umowa zlecenie

Odświeżono dnia 24 września 2026



Pracownik produkcji - I zmiana
5 000 - 6 000 zł / mies. brutto

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Odświeżono dnia 27 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
-------------
Przejdź do głównej części
Przejdź do stopki
Czat

Twoje konto

Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaProdukcjaObsługa produkcjiObsługa produkcji - Kujawsko-pomorskieObsługa produkcji - Białe Błota

Odświeżono dzisiaj o 12:00

Praca na produkcji od pon. do pt. – Pakowanie orzechów
FlexHR Dowiedz się więcej
Wynagrodzenie

34 - 40 zł / godz. brutto

Lokalizacja

Białe Błota

Wymiar pracy

Pełny etat

Typ umowy

Umowa o pracę, Umowa zlecenie


Lokalizacja
86-005 Białe Błota


Static Map
Opis
Masz chęci do pracy?

Poszukujemy zaangażowanych osób do naszego zespołu!

Co zyskujesz?

Atrakcyjna stawka: 34 zł brutto/h + dodatek nocny 6 zł brutto/h

Wolne weekendy: praca wyłącznie od poniedziałku do piątku

Jasne zasady: proste obowiązki bez skomplikowanych procedur

Twój zakres obowiązków:

Pakowanie orzechów w opakowania zbiorcze

Obsługa prostych urządzeń

Układanie gotowych paczek na paletach

Nasze wymagania:

Motywacja oraz szczere chęci do pracy

Aktualne badania do celów sanitarno-epidemiologicznych

Sprawność fizyczna

Aplikuj już teraz!

Informacje Prawne
www.flexhr.pl
 
Aplikuj teraz
ID: 1098628856

Zgłoś
O firmie

FlexHR
Stawiamy na relacje, dlatego HR to Human Relation
Branża
Zasoby Ludzkie i Rekrutacja
Wielkość firmy
1-50
Lokalizacja
Toruń
Szukasz nowej pracy, ale nie wiesz, od czego zacząć? FlexHR to idealne miejsce dla Ciebie! Oferujemy różnorodne oferty pracy w wielu branżach, od stanowisk produkcyjnych po specjalistyczne role. Nasz zespół rekruterów z pasją pomoże Ci na każdym etapie procesu, od przygotowania CV, przez rozmowę kwalifikacyjną, aż po finalne zatrudnienie.

Dzięki naszym kontaktom z firmami poszukującymi pracowników, masz szansę na znalezienie idealnej pracy, która odpowiada Twoim umiejętnościom i ambicjom. Dołącz do grona zadowolonych kandydatów, którzy zrealizowali swoje marzenia zawodowe dzięki FlexHR. Czekamy na Ciebie!


Pokaż więcej
Zobacz profil pracodawcy
Rekruter


FlexHR
Na OLX od maj 2013

Ostatnio online w dniu 28 września 2026


Zadzwoń / SMS
Aplikuj teraz
Zobacz profil pracodawcy
Więcej od tego ogłoszeniodawcy
Zobacz wszystkie


Pracownik Produkcji – Pakownia / Dział Cięcia
FlexHR

4 806 - 5 500 zł / mies. brutto

Grudziądz

Praca sezonowa

Umowa zlecenie

Odświeżono dnia 29 września 2026



Pomóż nam utrzymać produkcję słodkości bez niespodzianek | Osoba na stanowisko Mechanika
FlexHR

do 8 000 zł / mies. brutto

Włocławek

Pełny etat

Umowa o pracę

Odświeżono dnia 29 września 2026



Pracownik produkcji - umiejętność spawania | Inowrocław
FlexHR

8 000 - 8 500 zł / mies. brutto

Inowrocław

Pełny etat

Umowa o pracę

Odświeżono dnia 28 września 2026



Pracownik produkcji - bezpłatne dojazdy do pracy! K/M
FlexHR

Brześć Kujawski

Pełny etat

Umowa o pracę

28 września 2026



Operator produkcji - praca w Toruniu na dwie zmiany K/M
FlexHR

Toruń

Pełny etat

Umowa o pracę

28 września 2026



Operator maszyn (K/M) | Super Benefity | Bezpośrednie zatrudnienie na stałe
FlexHR

6 300 - 8 200 zł / mies. brutto

Bydgoszcz

Pełny etat

Umowa o pracę

Odświeżono dnia 25 września 2026



Pracownik Produkcji (K/M) | Wolne weekendy | Bezpośrednie zatrudnienie na stałe
FlexHR

5 500 - 6 200 zł / mies. brutto

Grudziądz

Pełny etat

Umowa o pracę

Odświeżono dnia 25 września 2026



Magazynier UDT (K/M) | Wolne weekendy | Bezpośrednie zatrudnienie na stałe
FlexHR

5 150 - 6 000 zł / mies. brutto

Grudziądz

Pełny etat

Umowa o pracę

Odświeżono dnia 25 września 2026



Pracownik produkcji (K/M)
FlexHR

od 4 806 zł / mies. brutto

Poledno

Pełny etat

Umowa o pracę

Odświeżono dnia 25 września 2026



Pracownik Produkcji/Operator (K/M)
FlexHR

5 200 - 6 500 zł / mies. brutto

Bydgoszcz

Pełny etat

Umowa o pracę

Odświeżono dnia 24 września 2026



Operator CNC (k/m) Heidenhain
FlexHR

do 7 800 zł / mies. brutto

Grudziądz

Pełny etat

Umowa o pracę

Odświeżono dnia 24 września 2026



Pracownik / Pracowniczka produkcji | Utrzymanie Ruchu | Zapewniamy mieszkanie
FlexHR

Włocławek

Pełny etat

Umowa o pracę

Odświeżono dnia 24 września 2026



Pracownik produkcji - praca w Toruniu K/M
FlexHR

od 31,40 zł / godz. brutto

Toruń

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 24 września 2026



Pracownik produkcji OD ZARAZ
FlexHR

31,40 - 33 zł / godz. brutto

Bydgoszcz

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 23 września 2026



Pracownik / Pracowniczka produkcji | Utrzymanie Ruchu
FlexHR

Bogucin

Pełny etat

Umowa o pracę

Odświeżono dnia 21 września 2026

Zobacz też
Osoba do pakowania paczek
Ciele

Pełny etat

Umowa o pracę, Umowa zlecenie

Odświeżono dnia 17 września 2026



pracownicy produkcyjno-magazynowi, branża meblowa
5 400 - 6 200 zł / mies. brutto

Kruszyn Krajeński

Pełny etat

Umowa o pracę

Odświeżono dnia 11 września 2026



Pracownik Produkcji - 7000 zł brutto na start *, atrakcyjna lokalizacja, szkolimy od podstaw, bogaty pakiet socjalny
TELE-FONIKA KABLE S.A. Zakład w Bydgoszczy

Bydgoszcz

Pełny etat

Umowa o pracę

Odświeżono dnia 27 września 2026


Kelner / kelnerka do obsługi imprez okolicznościowych
31,40 - 40 zł / godz. brutto

Białe Błota

Niepełny etat

Umowa zlecenie

17 września 2026



Sprzedawca (K/M), praca w sklepie, Sokołów-Net, Gzella, Białe Błota
Białe Błota

Pełny etat

Umowa o pracę

Odświeżono dnia 24 września 2026



Pracownik lub Pracowniczka ds. Operacji Logistycznych i Dystrybucyjnych (3/4 etatu), IKEA Retail, Bydgoszcz
IKEA Retail Sp. z o.o.

5 400 - 8 000 zł / mies. brutto

Bydgoszcz

Niepełny etat

Umowa o pracę

24 września 2026


Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Google Play
App Store
Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl
-----------
https://nofluffjobs.com/pl/job/project-manager-consultant-with-french-link-group-remote
https://nofluffjobs.com/pl/job/project-manager-link-group-remote-11
https://nofluffjobs.com/pl/job/program-manager-link-group-remote-4
https://nofluffjobs.com/pl/job/payroll-project-manager-with-german-remote-antal
https://nofluffjobs.com/pl/job/incident-management-improvement-specialist-ework-group-warsaw
https://nofluffjobs.com/pl/job/pmo-antal-krakow-2
https://nofluffjobs.com/pl/job/tech-lead-java-engineer-gft-poland-krakow-2
https://nofluffjobs.com/pl/job/project-manager-order-management-transition-transformation-antal-warszawa
https://nofluffjobs.com/pl/job/expert-java-consultant-gft-poland-krakow-2
https://nofluffjobs.com/pl/job/senior-java-developer-moondigo-warszawa-2
https://nofluffjobs.com/pl/job/analityk-systemowy-k-m-finture-warszawa-1
https://nofluffjobs.com/pl/job/it-consultant-for-technology-strategy-and-m-a-poland-deloitte-warsaw
https://nofluffjobs.com/pl/job/senior-java-consultant-gft-poland-krakow-4
https://nofluffjobs.com/pl/job/analityk-systemowy-bankowy-pko-finat-warszawa-5
https://nofluffjobs.com/pl/job/senior-analityk-systemowy-apreel-remote-1
https://nofluffjobs.com/pl/job/it-senior-consultant-for-technology-strategy-and-m-a-poland-deloitte-warsaw

ITP IT PERFORMANCE sp. z o.o.
.NET Developer
ITP IT PERFORMANCE sp. z o.o.O firmie
ważna jeszcze 11 dni

(do 11 paź)


120,00 – 145,00 zł
netto (+ VAT) / godz. | kontrakt B2B
Warszawamazowieckie
kontrakt B2B
pełny etat
specjalista / specjalistka (mid / regular), starszy specjalista / starsza specjalistka (senior)
praca hybrydowa
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend, Security
Technologie, których używamy
Wymagane
C#
.NET
O projekcie
Poszukujemy osoby (m/k) do roli .NET Developer. Praca jest dedykowana dla naszego klienta.
Dołączysz do zespołu rozwijającego systemy z obszaru Security / Video-CCTV / Data Processing, w których kluczowe znaczenie mają wydajność, stabilność i przetwarzanie danych w czasie rzeczywistym.
Projekt rozwijany jest w środowisku on-premise, z wykorzystaniem .NET 8 i planowaną migracją do .NET 10. Praca może również obejmować, w ograniczonym zakresie, starsze komponenty systemów oparte na .NET Framework.
Tak organizujemy naszą pracę
Tak pracujemy
u klienta
Twój zakres obowiązków
Rozwój i utrzymanie aplikacji backendowych w C#/.NET w obszarze systemów bezpieczeństwa i monitoringu wizyjnego.
Implementacja nowych funkcjonalności oraz rozbudowa istniejących modułów systemu.
Praca nad efektywnym wykorzystaniem i zarządzaniem pamięcią w aplikacjach przetwarzających dane w czasie rzeczywistym.
Integracja oprogramowania z innymi systemami, a w wybranych zadaniach poprzez komunikację socketową.
Diagnozowanie i usuwanie błędów oraz usprawnianie wydajności i stabilności aplikacji.
Tworzenie czytelnego, testowalnego kodu oraz udział w code review.
Współpraca z zespołem przy doborze rozwiązań technicznych i realizacji zadań developerskich.
Nasze wymagania
Minimum 4 lata doświadczenia w tworzeniu aplikacji w C#/.NET.
Dobra znajomość .NET, ASP.NET Core oraz tworzenia i rozwijania Web API.
Praktyczna znajomość programowania asynchronicznego i wielowątkowego.
Rozumienie mechanizmów zarządzania pamięcią w .NET i ich wpływu na wydajność aplikacji.
Doświadczenie w diagnozowaniu błędów i usprawnianiu działania aplikacji, np. pod kątem czasu odpowiedzi lub zużycia pamięci.
Znajomość zasad projektowania czytelnego, łatwego w utrzymaniu kodu oraz umiejętność stosowania wzorców projektowych.
Samodzielność w realizacji zadań i gotowość do poznawania działania systemu poza samą warstwą API, w tym przetwarzania danych i komunikacji między komponentami.
To oferujemy
Kontrakt B2B
Stawka: (120 - 145) pln/h + VAT
Praca w modelu hybrydowym: (2-3 dni w tyg z biura zlokalizowanym w warszawskim Wawrze)
Długoterminowe i rozwojowe projekty
Stabilny projekt z realnym znaczeniem biznesowym
Tak pracujemy nad projektem
dokumentacja
narzędzia do trackowania zadań
środowiska testowe
ITP IT PERFORMANCE sp. z o.o.
Przewiń do profilu firmy
Jako ITP IT Performance specjalizujemy się w outsourcingu, konsultingu i rekrutacji głównie w obszarze IT.
Aplikuj

Zapisz

Drukuj

Udostępnij
Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez ITP IT PERFORMANCE sp. z o.o. z siedzibą w: Długa 29, 00-238 Warszawa (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.
Media Expert
.Net Fullstack Developer (k/m)
Media ExpertO firmie
ważna 12 godzin


Aleje Jerozolimskie 160, Ochota, Warszawamazowieckie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca zdalna
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Full-stack
Siedziba firmy
Media Expert
Media Expert

Aleje Jerozolimskie 160, Ochota, Warszawa

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Technologie, których używamy
Wymagane
.NET
.NET Core
.NET Framework
HTML
CSS
Bootstrap 3+
jQuery
Angular 9+
Angular Material
TypeScript
Entity Framework
LINQ
MSSQL
T-SQL
SOLID
Clean Code
Design Patterns
REST
Web API
SOAP
C#
Mile widziane
RWD
Blazor
Karma
Jasmine
CI/CD
Kubernetes
XML
JWT
MVC
JSON
System operacyjny
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniemasz wpływ na wybór narzędzi i technologiimasz wpływ na rozwiązania technologicznetworzysz kod "od zera"koncentrujesz się na rozwoju produktukoncentrujesz się na utrzymaniu koduscrum
Skład zespołu
fullstack developer
Twój zakres obowiązków
Rozbudowa i utrzymanie istniejących aplikacji;
Projektowanie i tworzenie nowych rozwiązań backendowych i frontendowych;
Udział w analizie wymagań oraz projektowaniu architektury rozwiązań;
Dbanie o jakość kodu zgodnie z dobrymi praktykami programistycznymi;
Współpraca z zespołem projektowym przy rozwoju i utrzymaniu aplikacji;
Rozwijanie swoich kompetencji technicznych i śledzenie trendów technologicznych;
Zgłaszanie usprawnień technicznych i procesowych.
Nasze wymagania
Bardzo dobrze znasz C#, .NET Framework, .NET 5+ / .NET Core, ASP.NET MVC 4+;
Masz doświadczenie z technologiami frontendowymi: ES2015+, HTML, CSS, Bootstrap 3+, jQuery, podstawy Angular 9+, Angular Material, TypeScript;
Znasz podstawy Entity Framework, LINQ, oraz MSSQL / T‑SQL;
Rozumiesz dobre praktyki: SOLID, Clean Code, Design Patterns;
Potrafisz pracować z SOAP, REST, Web API;
Potrafisz debugować, analizować problemy i dbać o jakość kodu;
Jesteś dobrze zorganizowany/a, komunikatywny/a, chętny/a do nauki i współpracy.
Mile widziane
Znajomość: RWD, Blazor, testów jednostkowych/E2E (Karma, Jasmine), CI/CD, Kubernetes, XML, JWT, MVC, JSON.
Tak pracujemy nad projektem
Clean Code
code review
wzorce projektowe
Continuous Deployment
Continuous Integration
deployment na poziomie zespołu
wsparcie architekta / lidera technicznego
narzędzia do trackowania zadań
zarządzanie długiem technologicznym
środowiska testowe
testy integracyjne
testy jednostkowe
Benefity
dofinansowanie zajęć sportowych
prywatna opieka medyczna
ubezpieczenie na życie
zniżki na firmowe produkty i usługi
spotkania integracyjne
firmowa drużyna sportowa
kawa / herbata
parking dla pracowników
wyprawka dla dziecka
paczki świąteczne
program rekomendacji pracowników
inicjatywy dobroczynne
Zniżki na zakup sprzętu w naszych elektromarketach
Opieka fundacji MediaExpert „Włącz się”
Premia świąteczna
Nagrody jubileuszowe
Baby Expert - wyprawka dla Twojego nowonarodzonego dziecka
Dofinansowanie do karty MultiSport
Dofinansowanie do prywatnej opieki medycznej Medicover
Kody promocyjne

Media Expert
Przewiń do profilu firmy
Media Expert to:
• Lider branży elektromarketów w Polsce (mamy ich ponad 600)
• Najlepszy omnichannel w Polsce
• 3 sklepy internetowe - ponad 20 milionów Klientów rocznie
• Zautomatyzowana i nowoczesna logistyka (6 Centrów Dystrybucji w Łodzi i ok. 30 centrów przeładunkowych)
• Ponad 13 000 pracowników
Tak się u nas pracuje

Masz pytania?

Uzyskaj odpowiedzi na podstawie danych z oferty i profilu.

Jaki typ osoby może się dobrze odnaleźć na tym stanowisku?

Zyskaj dostęp do wszystkich pytań i odpowiedzi

Zaloguj się, by zobaczyć całość.


Zaloguj się
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Wszystkie informacje o przetwarzaniu danych osobowych w tej rekrutacji znajdziesz w formularzu aplikacyjnym, po kliknięciu w przycisk "Aplikuj Teraz".

Praca
Warszawa
IT - Administracja
Administrowanie systemami
---------
TATA CONSULTANCY SERVICES LIMITED S.A. ODDZIAŁ W POLSCE
.NET Software Developer
TATA CONSULTANCY SERVICES LIMITED S.A. ODDZIAŁ W POLSCEAbout the company
valid for 8 days

(to 08 Oct)


Przyokopowa 33, Wola, WarszawaMasovian
B2B contract
full-time
specialist (Mid / Regular)
home office work
Immediate employment
remote recruitment
Робота для іноземцівбез польської
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Additional information
Model of payment:
basic salary
Specializations:
Backend
Required languages:
English, Polish
Company location
TATA CONSULTANCY SERVICES LIMITED S.A. ODDZIAŁ W POLSCE
TATA CONSULTANCY SERVICES LIMITED S.A. ODDZIAŁ W POLSCE

Przyokopowa 33, Wola, Warszawa

Check travel time


 
Locate yourself or provide an exact address
Car

-

Public transport

-

Bike

-

On foot

-


Technologies we use
Expected
C#
ASP.NET
HTML
CSS
JavaScript
SQL
Git
RESTful APIs
About the project
As TCS, an international IT and BPO company, we are seeking a highly motivated .NET developer to join one of our banking projects.
This is how we organize our work
This is how we work
at the client's siteyou focus on a single project at a timeagile
Team members
backend developerfrontend developerdevOpsproduct owner
Your responsibilities
Participate in full lifecycle of software development: architecture, solution design, quality assurance and maintenance
Deliver high-quality technical solutions to multiple global stakeholders in a fast-paced environment
Ability to effectively communicate development progress to the business lead and program management
Be comfortable introducing new technologies and new ideas as required
Work effectively as part of a large global team
Our requirements
Bachelor’s degree in computer science, Information Technology, or a related field (or equivalent experience).
3-4 years of experience in .NET development.
Advanced knowledge of C#, ASP.NET, and MVC.
Familiarity with front-end technologies such as HTML, CSS, and JavaScript.
Understanding of relational databases (SQL Server, MySQL) and basic SQL queries.
Familiarity with version control systems such as Git.
Basic understanding of RESTful APIs and web services.
Basic understanding of Domain Driven Design (DDD)
Basic understanding of Tests Driven Development (TDD)
Willingness to learn Agile/Scrum methodologies and DevOps practices.
Strong problem-solving skills and attention to detail.
Good communication and interpersonal skills, with the ability to work effectively in a team environment.
Eagerness to manage multiple tasks and priorities in a fast-paced setting.
What we offer
Cooperation on B2B contract basis
Opportunity to cooperate in the enterprise, international environment
This is how we work on a project
DDD
TDD
DevOps
Benefits
sharing the costs of sports activities
private medical care
life insurance
remote work opportunities
corporate sports team
saving & investment scheme
no dress code
coffee / tea
parking space for employees
employee referral program
charity initiatives

Recruitment stages
1
Language and knowledge check

2
Interview with the manager

TATA CONSULTANCY SERVICES LIMITED S.A. ODDZIAŁ W POLSCE
Scroll to company's profile
Hi, we’re TATA Consultancy Services (TCS) Poland! A part of the Tata group, India's largest multinational business group, TCS has over 600,000 of the world’s best-trained consultants in 46 countries. TCS has been delivering services from Poland since 2008, making us the perfect choice offering stability. TCS is an IT services, consulting and business solutions organization that delivers real results to global business, ensuring a level of certainty no other firm can match. We're #BuildingOnBelief. Get to know us on the inside. Get to know TCS Poland.
This is how we work







More +9
Masz pytania?

Uzyskaj odpowiedzi na podstawie danych z oferty i profilu.

Jaki typ osoby może się dobrze odnaleźć na tym stanowisku?

Zyskaj dostęp do wszystkich pytań i odpowiedzi

Zaloguj się, by zobaczyć całość.


Zaloguj się
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Warszawa
IT - Administracja
Administrowanie systemami
------------
QODECA sp. z o.o.
Mid Fullstack Developer
QODECA sp. z o.o.About the company
valid for 4 days

(to 04 Oct)


14 000 – 19 000 zł
net (+ VAT) / mth. | B2B contract
Grzybowska 87, Wola, WarszawaMasovian
B2B contract
full-time
specialist (Mid / Regular)
home office work
Immediate employment
remote recruitment
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Additional information
Specializations:
Backend, Full-stack
Company location
QODECA sp. z o.o.
QODECA sp. z o.o.

Grzybowska 87, Wola, Warszawa

Check travel time


 
Locate yourself or provide an exact address
Car

-

Public transport

-

Bike

-

On foot

-


Technologies we use
Expected
C#
.NET
ASP.NET Web API
Entity Framework
SQL
React.js
React Native
TypeScript
JavaScript
HTML
CSS
GitHub
ChatGPT
Claude
OpenAI API
Docker
Microsoft Azure
Optional
Docker
Microsoft Azure
Azure Cosmos DB
GitHub
ChatGPT
OpenAI API
About the project
Build a modern web and mobile product for the fitness industry using .NET, React, and React Native.
At Qodeca, we create modern digital products for clients worldwide. We are looking for a Mid Fullstack Developer with commercial experience in both .NET backend development and frontend/mobile applications based on React and React Native.
You will join an interdisciplinary team delivering a comprehensive digital product for a fitness industry client. You will work alongside experienced developers and contribute to solutions used by thousands of people every day.
This is how we organize our work
This is how we work
you focus on a single project at a timeyou have influence on the technological solutions appliedyou have influence on the productyou focus on product developmentagilescrum
Team members
backend developerfrontend developermobile developertechnical leader
Your responsibilities
Develop the product end-to-end: Build and maintain backend, web, and mobile solutions.
Build the backend in .NET: Develop secure and scalable services and REST APIs using C#, .NET 10+, ASP.NET Web API, Entity Framework Core, and SQL Server.
Create frontend and mobile applications: Implement responsive and intuitive features using React, React Native, TypeScript, JavaScript, HTML5, and CSS3.
Optimize data solutions: Develop business logic and improve SQL Server database structures using Entity Framework Core.
Ensure code quality: Apply Clean Code, SOLID principles, and design patterns while writing reliable unit and integration tests.
Leverage AI in daily work: Use tools such as GitHub Copilot, Claude Code, ChatGPT, or OpenAI API for code generation, refactoring, and workflow optimization.
Collaborate with the team: Participate in technical discussions, code reviews, task estimation, and solution development within a distributed team.
Create technical documentation: Document implemented solutions and collaborate with team members in both Polish and English.
Our requirements
Experience: Minimum 3 years of commercial software development experience.
Backend: Experience with C#, .NET Core / .NET 8+, ASP.NET Web API, Entity Framework Core, and SQL Server.
Frontend & Mobile: Practical experience with React, React Native, TypeScript, JavaScript, HTML5, and CSS3.
Quality & Best Practices: Knowledge of Clean Code, SOLID principles, and design patterns, supported by experience in unit and integration testing.
AI & Productivity: Practical experience using AI-assisted development tools, such as Claude Code, GitHub Copilot, ChatGPT, or OpenAI API.
Remote teamwork: Self-discipline, good work organization, and the ability to collaborate effectively in a remote team.
Polish language: Fluent proficiency – mandatory.
English language: Minimum B2 in speaking and writing.
Optional
Knowledge of Domain-Driven Design (DDD) and CQRS.
Hands-on experience with microservices architecture and cloud-native solutions.
Experience with Microsoft Azure services, such as App Services, Service Bus, Azure SQL, and Azure DevOps.
Good understanding of Docker and containerization.
Familiarity with Azure Cosmos DB and advanced Cloud/DevOps patterns.
Interest in integrating AI/ML into commercial applications.
Experience in fitness, health & wellness, or other B2C solutions.
Experience publishing or maintaining applications in the App Store and Google Play.
What we offer
Compensation: 14,000–19,000 PLN net + VAT under a B2B contract.
Paid time off: 26 fully paid days off per year.
Remote work: 100% remote – a model we used long before it became the standard.
Meaningful product: Work on a new digital ecosystem combining web, mobile, backend, and integrations.
Experienced team: Collaborate with people who share their knowledge and care about quality.
Modern technology stack: Work with .NET, React, React Native, Azure, cloud solutions, and AI tools.
Real growth opportunities: 90% of leadership positions at Qodeca were filled through internal promotions.
Autonomy and support: Take ownership of your work while receiving support from experienced team members.
This is how we work on a project
Clean Code
code review
design patterns
Continuous Integration
DevOps
documentation
integration tests
unit tests
Development opportunities we offer
technical knowledge exchange within the company
Benefits
sharing the costs of sports activities
private medical care
sharing the costs of professional training & courses
remote work opportunities
flexible working time
integration events

Recruitment stages
1
Screening Interview

2
Tech Interview

Ready to Join Us?
Want to grow your fullstack skills while building a product that combines .NET, web, mobile, cloud, and AI? Apply – let’s talk.
QODECA sp. z o.o.
Scroll to company's profile
We’re a dynamic company thriving on innovation, teamwork, and the challenges of solving complex problems. Our projects involve the latest technologies and methodologies, giving you the chance to grow while making an impact.
If you’re excited to be part of our journey and help us build scalable billing solutions, send us your CV. We can’t wait to hear from you!
This is how we work

Aplikuj

Zapisz

Drukuj

Udostępnij
Praca
Warszawa
IT - Administracja
Administrowanie systemami
------

BAKK Sp. z o.o.
C# Developer
BAKK Sp. z o.o.O firmie
ważna jeszcze 4 dni

(do 04 paź)


Popiołka 20, Bemowo, Warszawamazowieckie
umowa o pracę, umowa o dzieło, umowa zlecenie, kontrakt B2B
pełny etat
młodszy specjalista / młodsza specjalistka (junior), specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
Praca od zaraz
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
System wynagrodzeń:
stała podstawa wynagrodzenia + premia za wyniki
Specjalizacje:
Backend
Siedziba firmy
BAKK Sp. z o.o.
BAKK Sp. z o.o.

Popiołka 20, Bemowo, Warszawa

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Technologie, których używamy
Wymagane
C#
.NET
T-SQL
Git
Visual Studio
Mile widziane
Azure DevOps
RabbitMQ
Entity Framework
O projekcie
Opis roli:
Jako C# Developer dołączysz do naszego zespołu, gdzie będziesz wspierać rozwój i utrzymanie baz danych oraz procesów przetwarzania danych w systemach klasy enterprise. Twoje codzienne zadania będą obejmować tworzenie zapytań, funkcji i procedur w języku T-SQL, analizę danych, a także optymalizację istniejących rozwiązań. Po stronie C#/.NET będziesz wspierać rozwój aplikacji korzystających z baz SQL Server, analizować istniejący kod oraz wdrażać zmiany związane z logiką biznesową i integracją z bazą danych. Będziesz mieć okazję uczyć się od doświadczonych programistów i brać udział w realnych projektach realizowanych dla dużych klientów.
Twój zakres obowiązków
Wsparcie rozwoju aplikacji w C#/.NET współpracujących z bazami SQL Server
Analiza i modyfikacja istniejącego kodu aplikacyjnego oraz logiki bazodanowej
Utrzymanie baz danych oraz procesów przetwarzania danych w systemach klasy enterprise
Tworzenie zapytań, funkcji i procedur w języku T-SQL
Analiza danych
Optymalizacja istniejących rozwiązań
Nasze wymagania
Znasz podstawy C#/.NET i masz za sobą pierwsze doświadczenia projektowe lub komercyjne
Znasz Visual Studio
Znasz systemy kontroli wersji, np. Git
Znasz T-SQL i potrafisz pisać zapytania, procedury, funkcje oraz widoki
Rozumiesz różnice między typami JOIN i potrafisz korzystać z podzapytań
Potrafisz tworzyć i modyfikować procedury składowane oraz funkcje użytkownika
Rozumiesz podstawy działania SQL Server: indeksy, uprawnienia, diagnozowanie wolnych zapytań i podstawy optymalizacji
Mile widziane
Podstawowa znajomość Entity Framework
Podstawowa znajomość tworzenia lub integracji z REST API w .NET
Podstawowa znajomość systemów kolejkowych i przetwarzania asynchronicznego, np. RabbitMQ
Doświadczenie z narzędziami typu SSMS
Umiesz poruszać się po Azure DevOps
Wiesz jak pracuje się z dużymi zbiorami danych
To oferujemy
Wynagrodzenie dopasowane do poziomu Twoich umiejętności i doświadczenia.
Możliwość pracy zdalnej i elastyczne godziny pracy.
Pakiet benefitów: prywatna opieka medyczna, karta sportowa.
Możliwość nauki od doświadczonych specjalistów oraz udział w szkoleniach i warsztatach.
Realny wpływ na rozwój systemów wykorzystywanych przez dużych klientów z branży finansowej.
Przyjazne środowisko pracy, w którym liczy się zaangażowanie, pomysły i wzajemne wsparcie.
Benefity
dofinansowanie zajęć sportowych
prywatna opieka medyczna
dofinansowanie nauki języków
możliwość pracy zdalnej
spotkania integracyjne

Opis procesu rekrutacji
1. Screening: Krótka rozmowa wstępna mająca na celu weryfikację podstawowych informacji i oczekiwań.
2. Zadanie domowe: Zadanie do samodzielnego wykonania weryfikujące umiejętności
3. Rozmowa techniczna: Spotkanie z specjalistą technicznym.
4. Rozmowa kwalifikacyjna: Spotkanie z menedżerem
5. Oferta: Przedstawienie oficjalnej oferty zatrudnienia.
6. Zachęcamy do aplikowania za pomocą formularza aplikacyjnego!
BAKK Sp. z o.o.
Przewiń do profilu firmy
BAKK zajmuje się tworzeniem oprogramowania dla branży windykacyjnej, pożyczkowej oraz mediowej.
Oferujemy klientom kompleksowe i nowoczesne rozwiązania, co przekłada się na możliwości pracy przy rozwojowych projektach dla naszych pracowników.
Nasz team stanowi ok. 50 programistów, w tym eksperci (10+ lat doświadczenia) organizujący pracę zespołów. Do naszych klientów należą m.in. Provident, Warta, Polkomtel, Mediacom, Bank Ochrony Środowiska.
Aplikuj

Zapisz

Drukuj

Udostępnij
Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez "BAKK" sp. z o.o. z siedzibą w: Karmelicka 4 B/3, 00-149 Warszawa (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.
---------
Kucharz śniadaniowy / Kucharka śniadaniowa
SUKCES sp. z o.o.O firmie
ważna jeszcze 5 dni

(do 05 paź)


40,00 – 50,00 zł
brutto / godz. | umowa zlecenie
Zwycięzców 49, Praga-Południe, Warszawamazowieckie
umowa zlecenie
pełny etat
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
Praca od zaraz
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Praca zmianowa:
tak
Godziny pracy:
7:00-15:00
Możliwa praca w godzinach nocnych:
nie
Tryb wypłaty:
miesięczna
System wynagrodzeń:
stała podstawa wynagrodzenia + premia za wyniki

Więcej szczegółów
Siedziba firmy
SUKCES sp. z o.o.

Zwycięzców 49, Praga-Południe, Warszawa

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Twój zakres obowiązków
Zakres obowiązków:
• samodzielne przygotowywanie śniadań i dań z karty zgodnie z recepturami i standardami lokalu
• przygotowywanie produktów do serwisu – mise en place
• dbanie o estetykę i powtarzalność wydawanych dań
• organizacja pracy kuchni podczas serwisu
• przygotowywanie śniadan, sosów, dodatków i innych elementów menu
• kontrolowanie jakości i świeżości produktów
• dbanie o prawidłowe przechowywanie żywności i przestrzeganie zasad HACCP
• kontrolowanie stanów magazynowych i zgłaszanie zapotrzebowania na produkty
• utrzymywanie porządku i czystości na stanowisku pracy oraz w kuchni
• racjonalne gospodarowanie produktami i ograniczanie strat
• współpraca z zespołem sali oraz pozostałymi pracownikami lokalu
• dbanie o sprzęt kuchenny i prawidłowe korzystanie z urządzeń
• udział w tworzeniu i rozwijaniu oferty śniadaniowej
Nasze wymagania
• doświadczenie przy kuchni śniadaniowej
• samodzielność i dobra organizacja pracy
• umiejętność sprawnego przygotowywania dań podczas intensywnego serwisu
• znajomość podstawowych technik kulinarnych
• dbałość o smak, jakość i estetykę wydawanych dań
• umiejętność pracy według receptur i standardów lokalu
• znajomość zasad higieny i bezpieczeństwa żywności
• odpowiedzialność za powierzone stanowisko i produkty
• punktualność, zaangażowanie i pozytywne nastawienie do pracy
• umiejętność pracy w zespole
• aktualna książeczka sanepidowska / orzeczenie do celów sanitarno-epidemiologicznych lub gotowość do jej wyrobienia
• dyspozycyjność do pracy w systemie 2/2 po 8 h
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Warszawa
Hotelarstwo / Gastronomia / Turystyka
Katering / Restauracje / Gastronomia
-----------------
HOTEL GROMADA CENTRUM Sp. z o.o. SKA
Pomoc kuchenna
HOTEL GROMADA CENTRUM Sp. z o.o. SKAO firmie
ważna jeszcze 15 dni

(do 15 paź)


Plac Powstańców Warszawy 2, Śródmieście, Warszawamazowieckie
umowa o pracę
pełny etat
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Dni pracy:
dni robocze (poniedziałek - piątek), sobota, niedziela
Tryb wypłaty:
miesięczna
System wynagrodzeń:
stała podstawa wynagrodzenia
Siedziba firmy
HOTEL GROMADA CENTRUM Sp. z o.o. SKA
HOTEL GROMADA CENTRUM Sp. z o.o. SKA

Plac Powstańców Warszawy 2, Śródmieście, Warszawa

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Twój zakres obowiązków
utrzymywanie porządku i czystości na stanowiskach pracy oraz w pomieszczeniach kuchennych,
utrzymywanie czystości i porządku w strefie zmywania oraz prawidłowa obsługa urządzeń myjących,
obsługa zmywaka oraz mycie naczyń, szkła, sztućców i sprzętu kuchennego,
pomoc w przygotowywaniu produktów i półproduktów do produkcji gastronomicznej,
wykonywanie prostych prac związanych z przygotowaniem potraw zgodnie z zaleceniami kucharzy,
obsługa urządzeń i sprzętu kuchennego zgodnie z ich przeznaczeniem,
pomoc przy przyjmowaniu i rozmieszczaniu dostaw,
przestrzeganie zasad higieny, bezpieczeństwa żywności oraz procedur HACCP,
współpraca z kucharzami oraz pozostałymi pracownikami działu gastronomii,
wykonywanie innych bieżących prac pomocniczych związanych z funkcjonowaniem kuchni hotelowej.
Nasze wymagania
chęć do pracy i zaangażowanie w wykonywane obowiązki,
dobra organizacja pracy,
dokładność, sumienność i odpowiedzialność,
umiejętność pracy w zespole,
dbałość o czystość i higienę miejsca pracy,
gotowość do pracy zmianowej, również w weekendy i święta,
aktualne orzeczenie do celów sanitarno-epidemiologicznych lub gotowość do jego uzyskania,
mile widziane doświadczenie na podobnym stanowisku w gastronomii, hotelu lub restauracji – nie jest jednak warunkiem koniecznym.
To oferujemy
pracę w firmie o stabilnej pozycji i wieloletniej tradycji,
stabilne warunki zatrudnienia na podstawie umowy o pracę,
wynagrodzenie adekwatne do zakresu obowiązków,
udział w Pracowniczym Programie Emerytalnym oraz Funduszu Socjalnym,
grupowy program opieki medycznej,
grupowe ubezpieczenie na życie,
posiłki pracownicze,
możliwość korzystania na preferencyjnych warunkach z ofert Grupy Gromada,
możliwość zdobywania doświadczenia i rozwoju zawodowego w gastronomii hotelowej,
niezbędne narzędzia i wyposażenie do wykonywania pracy,
pracę w doświadczonym i współpracującym zespołem
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Klauzula informacyjna Zgodnie z art. 13 ust. 1 i ust. 2 Rozporządzenia Parlamentu Europejskiego i Rady (UE) 2016/679 w sprawie ochrony osób fizycznych w związku z przetwarzaniem danych osobowych i w sprawie swobodnego przepływu takich danych oraz uchylenia dyrektywy 95/46/WE, z dnia 27.04.2016 r.(dalej RODO) informuję, iż: 1. Administratorem Pani/Pana danych osobowych jest Hotel Gromada Centrum Sp. z o.o. SKA z siedzibą: Pl. Powstańców Warszawy 2, 00-030 Warszawa. 2. Dane kontaktowe do Inspektora ochrony danych: 3. Tel: 22-826-50-41 4. e-mail: iod@gromada.pl 5. adres do korespondencji: Hotel Gromada Centrum Sp. z o.o. SKA Pl. Powstańców Warszawy 2, 00-030 Warszawa. 6. Pani/Pana dane osobowe zawarte w złożonej aplikacji, przetwarzane będą w celu wyboru kandydata na określone w ogłoszeniu stanowisko. 7. Podstawą przetwarzania danych osobowych jest zgoda zamieszczona w aplikacji (art. 6 ust.1a RODO). 8. Podstawą przetwarzania danych osobowych zawartych w zaświadczeniach i oświadczeniach dotyczących niekaralności, wymaganych w przypadku zatrudniania osób do pracy z małoletnimi, jest realizacja przepisu prawnego – art. 21 Ustawy o przeciwdziałaniu zagrożeniom przestępczością na tle seksualnym (art. 6 ust. 1c RODO), 9. Aplikacje niezawierające zgody nie będą brane pod uwagę w procesie rekrutacji i zostaną zniszczone po otrzymaniu. Aplikacja osoby wybranej będzie podstawą zawarcia umowy. Pozostałe rozpatrywane aplikacje po zakończeniu procesu rekrutacji będą przechowywane przez okres 3 miesięcy tj. do czasu zakończenia weryfikacji nowozatrudnionej osoby i jeżeli w tym czasie nie zostanie wznowiona rekrutacja zostaną zniszczone. 10. Aplikacje osób, które wyraziły dodatkową zgodę na pozostawienie ich dla przyszłych rekrutacji będą przechowywane w bazie przez okres 6 miesięcy i jeżeli w tym czasie nie zostanie wznowiona rekrutacja zostaną zniszczone. 11. Posiada Pani/Pan prawo dostępu do treści swoich danych oraz prawo ich sprostowania, usunięcia, ograniczenia przetwarzania, prawo do przenoszenia danych, prawo wniesienia sprzeciwu. 12. Pani/Pana dane osobowe nie będą przekazywane do państwa trzeciego ani organizacji międzynarodowej. 13. Ma Pan/Pani prawo wniesienia skargi do organu nadzorczego gdy uzna Pani/Pan, iż przetwarzanie danych osobowych Pani/Pana dotyczących narusza przepisy RODO. 14. Pani/Pana dane nie będą przetwarzane w sposób zautomatyzowany. Nie stosuje się profilowania kandydatów do pracy.-----------

Wrocławska Akademia Kulinarna spółka z o.o.
Młodszy kucharz (K/M)
Wrocławska Akademia Kulinarna spółka z o.o.O firmie
ważna jeszcze 4 dni

(do 04 paź)


Warszawamazowieckie
umowa o pracę
pełny etat
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
Praca od zaraz
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Praca zmianowa:
tak
Dni pracy:
dni robocze (poniedziałek - piątek), sobota, niedziela
Tryb wypłaty:
miesięczna
Specjalne uprawnienia:
Aktualne badania sanitarno-epidemiologiczne
Twój zakres obowiązków
Codzienny kontakt z gościem w otwartej kuchni i dbanie o potrawy na linii ciepłej,
Przygotowywanie potraw serwowanych na ciepło zgodnie z recepturami, które od lat są naszym znakiem rozpoznawczym,
Komponowanie estetycznych bufetów, które cieszą oko i zachęcają do spróbowania,
Przestrzeganie obowiązujących norm i procedur HACCP oraz zasad BHP.
Nasze wymagania
Doświadczenie w pracy w gastronomii. Pracowałeś/-aś jako kucharz lub pomoc kuchenna? Super !
Aktualna książeczka sanepidu lub gotowość do jej wyrobienia,
Skoncentrowanie na detalu i wyczucie estetyki,
To oferujemy
Współpracę w ramach umowy o pracę,
Konkurencyjne wynagrodzenie adekwatne do Twojego doświadczenia i zaangażowania,
Zniżkę w wysokości 50% w całej sieci restauracji,
Szerokie możliwości rozwoju. Każdego roku otwieramy nowe restauracje i nowe stanowiska w całej Polsce!
Pracę na wybranych lokalach - Mokotów, Złote Tarasy, Ursus i Janki
Benefity
zniżki na firmowe produkty i usługi
kawa / herbata

Od prawie 30 lat z miłością gotujemy dania kuchni polskiej i azjatyckiej – dołącz do zespołu, który pielęgnuje smak tradycji i daje stabilne miejsce do pracy,
Wrocławska Akademia Kulinarna spółka z o.o.
Przewiń do profilu firmy
Sieć restauracji Kuchnia Marche w Warszawie poszukuje osoby na stanowisko Młodszego kucharza.
Jeśli lubisz ludzi i często słyszysz, że masz fajną energię – dołącz do nas !
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez WROCŁAWSKA AKADEMIA KULINARNA sp. z o.o. z siedzibą w: Świdnicka 53, 50-030 Wrocław (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
Hotelarstwo / Gastronomia / Turystyka
Hotelarstwo
-----------
PLASTBOR
Magazynier / Magazynierka
PLASTBORO firmie
ważna jeszcze 23 dni

(do 23 paź)


Przesmyckiego 66, Piasecznomazowieckie
umowa o pracę
pełny etat
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
Praca od zaraz
Szukamy wielu kandydatów2 wakaty
pracodawca nie wymaga CV
Bez doświadczenia
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Praca zmianowa:
nie
Dni pracy:
dni robocze (poniedziałek - piątek)
Godziny pracy:
8:00-16:00
Możliwa praca w godzinach nocnych:
nie
Tryb wypłaty:
miesięczna

Więcej szczegółów
Siedziba firmy
PLASTBOR
PLASTBOR

Przesmyckiego 66, Piaseczno

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Twój zakres obowiązków
Przyjmowanie dostaw towaru, sprawdzanie zgodności ilościowej i jakościowej z dokumentami (WZ/PZ, faktura, zamówienie)
Rozładunek i załadunek towaru
Prawidłowe rozmieszczanie towaru na regałach/strefach wg asortymentu
Kompletacja zamówień
Kompletowanie zamówień na podstawie dokumentów/zleceń z systemu
Rozróżnianie i priorytetyzacja zamówień: odbiory własne klienta vs wysyłka kurierem/spedycją
Weryfikacja kompletności i zgodności skompletowanego zamówienia
Przygotowanie zamówień do odbioru osobistego (oznaczenie, odłożenie w strefę wydań)
Pakowanie i zabezpieczanie towaru pod wysyłkę (odpowiednie opakowanie, paleta, folia stretch)
Ważenie i wymiarowanie paczek/palet do zlecenia transportowego
Wydawanie towaru odbiorcom osobistym – weryfikacja tożsamości/upoważnienia, potwierdzenie odbioru
Przekazywanie przesyłek kurierom/spedytorom, potwierdzanie zleceń transportowych (listy przewozowe)
Prowadzenie na bieżąco dokumentacji magazynowej (ewidencja przyjęć, wydań, przesunięć)
Uczestnictwo w inwentaryzacjach okresowych i wyrywkowych
Zgłaszanie braków, uszkodzeń, rozbieżności stanów przełożonemu
Utrzymanie porządku i czystości w magazynie oraz strefach kompletacji/wydań
Obsługa sprzętu magazynowego
Przestrzeganie zasad BHP i ppoż. przy pracy z towarem, sprzętem i przy załadunku/rozładunku
Dbałość o stan techniczny używanego sprzętu, zgłaszanie usterek
Bieżący kontakt z działem handlowym/logistyką w sprawie priorytetów wysyłek i odbiorów
Informowanie o brakach towarowych mogących opóźnić realizację zamówień
Wsparcie przy załadunku/rozładunku transportu własnego lub zewnętrznego
Nasze wymagania
Znajomość zasad gospodarki magazynowej (przyjęcia, wydania, inwentaryzacje)
Umiejętność obsługi podstawowego sprzętu magazynowego (wózek paletowy, dyspenser do taśmy)
Dokładność i skrupulatność przy kompletacji zamówień
Dobra organizacja pracy i umiejętność ustalania priorytetów (rozróżnianie pilnych wysyłek od odbiorów własnych)
Odpowiedzialność i uczciwość (praca z powierzonym mieniem/towarem)
Sumienność w prowadzeniu dokumentacji (WZ, listy przewozowe)
Komunikatywność – współpraca z działem handlowym, kurierami, klientami odbierającymi towar osobiście
Dobra kondycja fizyczna (praca fizyczna, dźwiganie, praca w ruchu)
Dyspozycyjność zgodna z godzinami pracy magazynu
Niekaralność (jeśli wymagana wewnętrzną polityką firmy)
Mile widziane
Uprawnienia na wózki widłowe (mile widziane, możliwość zdobycia w trakcie pracy)
Mile widziane doświadczenie na podobnym stanowisku (magazyn, logistyka, kompletacja zamówień)
Znajomość podstawowej terminologii branży instalacyjnej/hydraulicznej
To oferujemy
Stabilne zatrudnienie w oparciu o umowę o pracę
Wynagrodzenie.
Stałe godziny pracy: pon-pt, godz. 8–16
Pracę w stabilnej, 35-letniej firmie z ugruntowaną pozycją na rynku systemów PP-R
Niezbędne narzędzia i sprzęt do pracy
Przyjazną atmosferę pracy w zgranym zespole.
Możliwość zdobycia uprawnień (np. na wózki widłowe) w trakcie zatrudnienia.
Wsparcie i wdrożenie na starcie przez doświadczony zespół
Benefity
zniżki na firmowe produkty i usługi
spotkania integracyjne
kawa / herbata
parking dla pracowników
paczki świąteczne
możliwość uzyskania uprawnień
O nas
O firmie PLASTBOR
PLASTBOR to polski producent i dystrybutor systemów instalacyjnych PP-R – rur i kształtek wykorzystywanych w instalacjach wodnych i grzewczych. Działamy na rynku od kilkudziesięciu lat, dostarczając produkty profesjonalistom: instalatorom, hurtowniom i firmom wykonawczym w całej Polsce, a także w ramach eksportu za granicę.
Stawiamy na polską produkcję, wysoką jakość surowca i szybkość realizacji zamówień – to nasze największe atuty, dzięki którym budujemy trwałe relacje z klientami B2B. Nasze produkty trafiają do profesjonalnych odbiorców, dla których liczy się nie tylko cena, ale przede wszystkim niezawodność i terminowość dostaw.
Jesteśmy stabilną, dobrze zorganizowaną firmą z jasną strukturą i wieloletnim doświadczeniem w branży. Stawiamy na rzetelność wobec klientów i dobrą atmosferę pracy wewnątrz zespołu – szukamy osób, które chcą dołączyć do sprawdzonej organizacji i rozwijać się razem z nią.
----------------
Pracownik magazynu
UNIPACK MACIEJKO sp. z o.o.O firmie
ważna jeszcze 18 dni

(do 18 paź)


5 900 – 6 000 zł
brutto / mies. | umowa o pracę
Raszyńska 13, Piasecznomazowieckie
umowa o pracę
pełny etat
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
Praca od zaraz
Szukamy wielu kandydatów3 wakaty
pracodawca nie wymaga CV
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Praca zmianowa:
tak
Dni pracy:
dni robocze (poniedziałek - piątek), sobota
Godziny pracy:
6:00-14:00, 7:00-15:00, 8:00-16:00, 9:00-17:00
Możliwa praca w godzinach nocnych:
nie
Tryb wypłaty:
miesięczna

Więcej szczegółów
Siedziba firmy
UNIPACK MACIEJKO sp. z o.o.
UNIPACK MACIEJKO sp. z o.o.

Raszyńska 13, Piaseczno

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Twój zakres obowiązków
przyjmowanie i kontrola towarów dostarczanych do magazynu,
kompletowanie i pakowanie zamówień do wysyłki oraz dla klientów stacjonarnych,
utrzymywanie porządku i organizacja przestrzeni magazynowej,
obsługa urządzeń magazynowych, takich jak wózki widłowe czy skanery kodów kreskowych,
prowadzenie ewidencji magazynowej i współpraca z innymi działami firmy.
Nasze wymagania
Doświadczenie w pracy na podobnym stanowisku
Zdolność do pracy fizycznej i dobrej kondycji zdrowotnej
Znajomość zasad bezpieczeństwa i higieny pracy w magazynie
Umiejętność pracy w zespole i komunikatywność
Bardzo dobra znajomość języka polskiego
Chęć wykonywania pracy o wysokim poziomie jakości
Mile widziane
uprawnienia do prowadzenia wózków widłowych
To oferujemy
Oferujemy pracę w stabilnej, działającej od wielu lat, firmie. Jesteśmy jedną z czołowych firm w naszej branży. Możesz u nas rozwinąć swoje umiejętności zawodowe. Poczuć się docenionym. Wszystko zależy od Ciebie.
Benefity
dofinansowanie zajęć sportowych
zniżki na firmowe produkty i usługi
kawa / herbata
parking dla pracowników
dofinansowanie wypoczynku
możliwość uzyskania uprawnień
O nas
Firma UniPack Maciejko Sp. z o.o. działa od 1991 roku w sektorze HoReCa. Jesteśmy firmą dystrybucyjną, jedną z wiodących na rynku, w której wielu pracowników ma wieloletni staż pracy.
Aplikuj szybko
Pokaż numer pracodawcy

Zapisz

Drukuj

Udostępnij
Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez UNIPACK MACIEJKO sp. z o.o. z siedzibą w: Raszyńska 13, 05-500 Piaseczno (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Piaseczno
Praca fizyczna
Pracownicy magazynowi
---------------
Magazynier
WALKABOUT sp. z o.o.O firmie
ważna jeszcze dzień

(do 01 paź)


5 200 – 5 600 zł
brutto / mies. | umowa o pracę
Ruczaj 89, Wilanów, Warszawamazowieckie
umowa o pracę
pełny etat, część etatu
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
Praca od zaraz
pracodawca nie wymaga CV
Bez doświadczenia
Otwartość również na osoby 50+
Запрошуємо працівників з України
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Praca zmianowa:
nie
Dni pracy:
dni robocze (poniedziałek - piątek)
Godziny pracy:
elastyczny grafik, możliwe nadgodziny, 8:00-16:00, 9:00-17:00, 11:00 - 19:00
Możliwa praca w godzinach nocnych:
nie
Tryb wypłaty:
miesięczna

Więcej szczegółów
Siedziba firmy
WALKABOUT sp. z o.o.
WALKABOUT sp. z o.o.

Ruczaj 89, Wilanów, Warszawa

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Twój zakres obowiązków
przyjmowanie, kontrolowanie i rozkładanie dostaw;
kompletowanie i przygotowywanie zamówień dla klientów detalicznych i hurtowych;
przygotowywanie przesunięć magazynowych pomiędzy lokalizacjami firmy;
weryfikacja poprawności skompletowanych zamówień;
przygotowywanie towaru do wysyłki – pakowanie produktów zgodnie z ustalonymi procedurami, oznaczanie i adresowanie przesyłek;
drukowanie dokumentów sprzedaży – paragonów i faktur;
kontrolowanie stanów magazynowych oraz zgłaszanie przełożonemu braków, uszkodzeń lub niezgodności;
bieżące wsparcie magazynowe sklepu firmowego;
udział w regularnych inwentaryzacjach magazynu;
dbanie o porządek w magazynie i na stanowisku pracy;
współpraca z pozostałymi działami firmy;
wykonywanie innych zadań związanych z bieżącą pracą magazynu, zleconych przez przełożonego.
Nasze wymagania
dobra sprawność fizyczna;
umiejętność pracy w zespole;
komunikatywność;
dobra organizacja pracy i umiejętność planowania powierzonych zadań;
sumienność, dokładność i odpowiedzialność;
umiejętność sprawnego działania przy większej liczbie zamówień;
podstawowa znajomość obsługi komputera, w tym pakietu Microsoft Office;
mile widziane doświadczenie w pracy w magazynie, logistyce, e-commerce lub dziale reklamacji.
To oferujemy
Stabilne warunki zatrudnienia;
Możliwości rozwoju własnych umiejętności;
Ciekawą pracę w dynamicznie rozwijającym się dziale;
Wsparcie przy wdrożeniu na stanowisku pracy;
Zniżkę na asortyment dostępny w ofercie firmy;
Pakiet Multisport;
Pakiet ubezpieczenia na życie;
Benefity
dofinansowanie zajęć sportowych
ubezpieczenie na życie
zniżki na firmowe produkty i usługi
brak dress code’u
kawa / herbata
parking dla pracowników
O nas
Walkabout jest właścicielem sklepów internetowych lavaredo.pl i montiko.pl oraz Salonów Firmowych Salewa. Od lat dostarczamy miłośnikom gór i outdooru produkty renomowanych marek.
Lavaredo.pl i montiko.pl to nie tylko sklepy internetowe. Prowadzimy również sklepy stacjonarne w Warszawie i Rzeszowie oraz Outlet Salewa w Factory Annopol w Warszawie.
Od ponad 15 lat pomagamy naszym klientom dobierać odpowiedni sprzęt, odzież i obuwie outdoorowe. Stawiamy na fachową obsługę, dobrą znajomość produktów oraz sprawną organizację sprzedaży internetowej i stacjonarnej.
Jeżeli jesteś osobą dokładną, dobrze zorganizowaną i szukasz stabilnej pracy w firmie z branży outdoorowej – zapraszamy do aplikowania.
Aplikuj szybko
Pokaż numer pracodawcy

Zapisz

Drukuj

Udostępnij
Klikając przycisk „Aplikuj”, „Aplikuj teraz” lub w inny sposób wysyłając zgłoszenie rekrutacyjne do Walkabout Sp. z o.o. z siedzibą w Warszawie, ul. Ruczaj 89, 02-997 Warszawa (Pracodawca – administrator danych), zgadzasz się na przetwarzanie przez Pracodawcę Twoich danych osobowych zawartych w zgłoszeniu rekrutacyjnym w celu prowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu. W każdym czasie możesz cofnąć zgodę, kontaktując się z nami pod adresem e-mail: rekrutacja@walkabout.pl. Jeżeli chcesz, aby Twoje CV zostało wykorzystane również podczas przyszłych rekrutacji prowadzonych przez Pracodawcę, umieść dodatkowo w CV następującą zgodę: „Zgadzam się na przetwarzanie przez Walkabout Sp. z o.o. moich danych osobowych zawartych w zgłoszeniu rekrutacyjnym dla celów przyszłych rekrutacji prowadzonych przez Pracodawcę.” W każdym czasie możesz cofnąć swoją zgodę, kontaktując się z Pracodawcą pod adresem e-mail: [rekrutacja@walkabout.pl](mailto:rekrutacja@walkabout.pl). Będziemy przetwarzać informacje o Tobie w celu prowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu na następujących podstawach prawnych: a) w celu wypełnienia ciążących na nas obowiązków prawnych – w odniesieniu do danych wskazanych w Kodeksie pracy, takich jak m.in. dane identyfikacyjne, dane kontaktowe, informacje o wykształceniu, doświadczeniu zawodowym, umiejętnościach i kwalifikacjach, a także danych wymaganych na podstawie innych przepisów prawa; b) w celu podjęcia działań na Twoje żądanie przed zawarciem umowy – np. w odniesieniu do informacji o oczekiwanym wynagrodzeniu lub dostępności do rozpoczęcia pracy; c) na podstawie Twojej zgody – w odniesieniu do danych podanych przez Ciebie dobrowolnie, np. wizerunku lub zainteresowań; d) na podstawie naszego prawnie uzasadnionego interesu – np. w odniesieniu do adresu e-mail niezbędnego do identyfikacji użytkownika w formularzu Pracuj.pl. Twoje dane osobowe możemy również przetwarzać w celu prowadzenia przyszłych rekrutacji na różne stanowiska, jeżeli wyrazisz na to zgodę. Podanie danych osobowych wymaganych przepisami prawa, niezbędnych do podjęcia działań na Twoje żądanie przed zawarciem umowy lub niezbędnych ze względu na nasz prawnie uzasadniony interes jest konieczne, aby wziąć udział w rekrutacji. Podanie pozostałych danych jest dobrowolne. Masz prawo dostępu do swoich danych osobowych, w tym uzyskania ich kopii, sprostowania danych, żądania ich usunięcia, ograniczenia przetwarzania, wniesienia sprzeciwu wobec przetwarzania oraz – w przypadkach przewidzianych przepisami – przeniesienia danych do innego administratora. Masz również prawo wniesienia skargi do Prezesa Urzędu Ochrony Danych Osobowych. Cofnięcie zgody pozostaje bez wpływu na zgodność z prawem przetwarzania dokonanego na podstawie zgody przed jej cofnięciem. Twoje dane osobowe przetwarzamy w celu prowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu do czasu zakończenia procesu rekrutacyjnego. Twoje dane osobowe przetwarzamy w celu prowadzenia przyszłych rekrutacji do czasu cofnięcia zgody lub ustania celu przetwarzania, jednak nie dłużej niż przez 6 miesięcy. Twoje dane osobowe możemy przekazywać podmiotom świadczącym na naszą rzecz usługi związane z publikacją ogłoszeń o pracę, obsługą procesów rekrutacyjnych, usługami IT, hostingiem oraz dostawcom wykorzystywanych przez nas systemów informatycznych. Nie przekazujemy Twoich danych osobowych poza Europejski Obszar Gospodarczy (EOG). W razie pytań dotyczących przetwarzania danych osobowych w ramach bieżącej rekrutacji możesz skontaktować się z nami pod adresem e-mail: rekrutacja@walkabout.pl.

Praca
Warszawa
Praca fizyczna
Pracownicy magazynowi
Aplikuj szybko
Pokaż numer pracodawcy

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
Mennica Polska S.A.
Superoferta
Magazynier (k/m) Hit!
Mennica Polska S.A.
6 500 zł brutto / mies.
Warszawa, Białołęka


UniGast S.A.
Magazynier / Magazynierka Najlepiej dopasowana
UniGast S.A.
Warszawa


Steriscience Sp. z o.o.
Superoferta
Magazynier/ka Śpiesz się!
Steriscience Sp. z o.o.
Warszawa


BAG-POL ADAM GOŹDZICKI, BARBARA GOŹDZICKA SPÓŁKA KOMANDYTOWA
Magazynier - kompletacja (k/m) Tu zarobisz najwięcej!
BAG-POL ADAM GOŹDZICKI, BARBARA GOŹDZICKA SPÓŁKA KOMANDYTOWA
5 500–8 300 zł brutto / mies.
Warszawa, Włochy


HEBAR SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
Magazynier / Magazynierka Śpiesz się!
HEBAR SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
Warszawa


Franke Polska Sp. z o.o.
Superoferta
Magazynier (K/M)
Franke Polska Sp. z o.o.
Sękocin Nowy (pow. pruszkowski)


MAGIA KUCHNI
Pracownik magazynu/ Pakowacz paczek internetowych
MAGIA KUCHNI
32–33 zł brutto / godz.
Warszawa, Wawer



Pokaż więcej podobnych
16
Włącz powiadomienie
Magazynier, Ruczaj 89, Wilanów, Warszawa


Chcesz dowiedzieć się więcej o firmie?

Zobacz pełny profil firmy

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
-----------------------
UniGast S.A.
Magazynier / Magazynierka
UniGast S.A.O firmie
ważna jeszcze dzień

(do 01 paź)


Warszawamazowieckie
umowa o pracę, umowa zlecenie, umowa o pracę tymczasową
pełny etat, część etatu, dodatkowa / tymczasowa
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
Praca od zaraz
pracodawca nie wymaga CV
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Tryb wypłaty:
miesięczna
Twój zakres obowiązków
Zatrudniona osoba będzie wykonywała pracę w charakterze magazyniera i będzie odpowiedzialna za:
Kompletowanie zamówień do klientów
Przyjmowanie dostaw do magazynu
Utrzymanie porządku w magazynie
Nasze wymagania
Umiejętność pracy w zespole
Punktualność, dyspozycyjność, uczciwość, samodzielność
Mile widziane
Uprawnienia na wózki widłowe
To oferujemy
Stabilne warunki zatrudnienia w dużej polskiej firmie
Terminowe wypłaty wynagrodzenia
Pracę w młodym i zgranym zespole
Motywacyjny system wynagrodzenia
Benefity
ubezpieczenie na życie

Aplikuj szybko

Zapisz

Drukuj

Udostępnij
„Wyrażam zgodę na przetwarzanie danych osobowych zawartych w mojej ofercie pracy dla potrzeb niezbędnych do realizacji procesu rekrutacji prowadzonego przez UniGast S.A.. z siedzibą w Warszawie zgodnie z ustawą z dnia 29 sierpnia 1997 r. o ochronie danych osobowych (tj. Dz. U. z 2014 r. poz. 1182, 1662)”.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
Praca fizyczna
Kurierzy / Dostawcy
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
Mennica Polska S.A.
Superoferta
Magazynier (k/m) Hit!
Mennica Polska S.A.
6 500 zł brutto / mies.
Warszawa, Białołęka


BAG-POL ADAM GOŹDZICKI, BARBARA GOŹDZICKA SPÓŁKA KOMANDYTOWA
Magazynier - kompletacja (k/m)
BAG-POL ADAM GOŹDZICKI, BARBARA GOŹDZICKA SPÓŁKA KOMANDYTOWA
5 500–8 300 zł brutto / mies.
Warszawa, Włochy


HEBAR SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
Magazynier / Magazynierka Najlepiej dopasowana
HEBAR SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
Warszawa


Steriscience Sp. z o.o.
Superoferta
Magazynier/ka Śpiesz się!
Steriscience Sp. z o.o.
Warszawa


Franke Polska Sp. z o.o.
Superoferta
Magazynier (K/M)
Franke Polska Sp. z o.o.
Sękocin Nowy (pow. pruszkowski)


MANTA S.A.
Magazynier
MANTA S.A.
Warszawa, Targówek


MAGIA KUCHNI
Pracownik magazynu/ Pakowacz paczek internetowych
MAGIA KUCHNI
32–33 zł brutto / godz.
Warszawa, Wawer



Pokaż więcej podobnych
16
Włącz powiadomienie
Magazynier / Magazynierka, Warszawa


Chcesz dowiedzieć się więcej o firmie?
-------- (okyłkowo zaznaczone spejclanie oferty poboczne: test1)

Senior .NET Developer - Departament IT
T-MobileO firmie
ważna jeszcze 14 dni

(do 14 paź)


Marynarska 12, Mokotów, Warszawamazowieckie
kontrakt B2B
pełny etat
starszy specjalista / starsza specjalistka (senior)
praca hybrydowa
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Siedziba firmy
T-Mobile
T-Mobile

Marynarska 12, Mokotów, Warszawa

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Technologie, których używamy
Wymagane
.NET
MS SQL
Oracle
SQL
VUE
JS.NET
ASP.NET
System operacyjny
Twój zakres obowiązków
Rozwój aplikacji dla klienta wewnętrznego w oparciu o wymagania techniczne i biznesowe zgodnie z dobrymi praktykami programistycznymi oraz z przyjętą architekturą
Wsparcie zespołu w zakresie utrzymania, wprowadzania usprawnień, zmian oraz optymalizacji, usuwanie błędów, proaktywne zgłaszanie, eliminowanie wykrytych zagrożeń, tworzenie dokumentacji technicznej
Udział w testowaniu i wdrażaniu nowych wersji aplikacji
Rozwiązywanie problemów zgłaszanych przez użytkowników
Współpraca z interesariuszami w zakresie rozwoju i utrzymania usług
Nasze wymagania
Minimum 6-letnie doświadczenie na podobnym stanowisku
Praktyczna umiejętność programowania w .NET
Znajomość podstaw VUE, JS.NET, ASP.NET
Znajomość języka SQL oraz systemów baz danych MS SQL, Oracle
Doświadczenia projektowe ze standardami CI/CD
Znajomość systemów operacyjnych Windows, Linux
Umiejętności komunikacyjne, także współpracy z biznesem
Znajomość metodyk Agile
Znajomość języka angielskiego minimum na poziomie B1 (w zakresie czytania/pisania dokumentacji technicznej)
Zaangażowanie w realizację powierzonych zadań
To oferujemy
Będziesz częścią zespołu odpowiedzialnego za systemy, które realnie wspierają codzienną pracę organizacji. To dobra rola dla osoby, która chce łączyć kompetencje techniczne z pracą z biznesem, rozwijać się w obszarze IT i mieć wpływ na jakość usług używanych w dużej firmie. Jeśli chcesz pracować z aplikacjami, które mają znaczenie, i rozwijać się w zespole blisko biznesu — zapraszamy do aplikowania.
Benefity
dofinansowanie zajęć sportowych
prywatna opieka medyczna
dofinansowanie szkoleń i kursów
ubezpieczenie na życie
możliwość pracy zdalnej
elastyczny czas pracy
zniżki na firmowe produkty i usługi
służbowy telefon do użytku prywatnego
brak dress code’u
parking dla pracowników
program rekomendacji pracowników
inicjatywy dobroczynne

Etapy rekrutacji
1
Wyślij swoje CV

2
Spotkaj się z przyszłym liderem/ liderką zespołu :)

3
Witaj w T-Mobile :)

T-Mobile
Przewiń do profilu firmy
Jesteśmy firmą technologiczną, a naszym celem jest tworzenie innowacyjnych rozwiązań dla klientów indywidualnych i biznesowych.
W T-Mobile wszyscy żyjemy w świecie magenta! Kolor ten jest nam bliski, bo oznacza wiarę w powodzenie podejmowanych działań, pewność siebie i wytrzymałość. Właśnie tacy jesteśmy jako zespół.
W #MagentaTeam stawiamy na wymianę doświadczeń, zwinną pracę i szybko adaptujemy się do zmian! #MagentaTeam to jednak przede wszystkim mix różnych kompetencji i doświadczeń, osobowości, temperamentów i poglądów. Właśnie w tej różnorodności widzimy naszą największą siłę.
Tak się u nas pracuje







Więcej +4
Masz pytania?

Uzyskaj odpowiedzi na podstawie danych z oferty i profilu.

Jaki typ osoby może się dobrze odnaleźć na tym stanowisku?

Zyskaj dostęp do wszystkich pytań i odpowiedzi

Zaloguj się, by zobaczyć całość.


Zaloguj się
HR-4144
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Wszystkie informacje o przetwarzaniu danych osobowych w tej rekrutacji znajdziesz w formularzu aplikacyjnym, po kliknięciu w przycisk "Aplikuj Teraz".

Praca
Warszawa
IT - Administracja
Administrowanie bazami danych i storage
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Hit!
DIAGNOSTYKA S.A.
Kraków, Czyżyny


Next Technology Professionals Sp. z o.o.
Superoferta
.NET Fullstack Developer (Relativity) Najlepiej dopasowana
Next Technology Professionals Sp. z o.o.
170–220 zł / godz. (zal. od umowy)
Warszawa


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


SIMPLE S.A.
Programista / Programistka Śpiesz się!
SIMPLE S.A.
Warszawa, Wawer


Bank Millennium S.A.
Programista .NET / Programistka .NET w Obszarze Rozwoju Systemów Korporacyjnych
Bank Millennium S.A.
Warszawa, Mokotów


dotLinkers Sp. z o.o.
Superoferta
Senior .NET Engineer
dotLinkers Sp. z o.o.
32 000 zł brutto / mies.
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Senior .NET Developer - Departament IT, Marynarska 12, Mokotów, Warszawa


Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

SIMPLE S.A.
Programista / Programistka
SIMPLE S.A.O firmie
ważna jeszcze dzień

(do 01 paź)


Bronisława Czecha 49/51, Wawer, Warszawamazowieckie
umowa o pracę, kontrakt B2B
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
System wynagrodzeń:
premia uznaniowa
Specjalizacje:
Backend
Siedziba firmy
SIMPLE S.A.
SIMPLE S.A.

Bronisława Czecha 49/51, Wawer, Warszawa

Sprawdź czas dojazdu


 
Zlokalizuj się lub podaj dokładny adres
Samochód

-

Komunikacja

-

Rower

-

Pieszo

-


Technologie, których używamy
Wymagane
.NET
C#
PowerBuilder
T-SQL
MS SQL SERVER
System operacyjny
Twój zakres obowiązków
Tworzenie i rozwój nowych modułów systemu klasy ERP
Rozwój i optymalizacja istniejących funkcjonalności
Projektowanie struktur baz danych oraz tworzenie wydajnych zapytań i procedur składowanych
Udział w rozwoju i utrzymaniu architektury systemu
Projektowanie, budowanie rozwiązań klient - serwer w oparciu o MS SQL Server, .NET (C#) oraz PowerBuilder
Współpraca z zespołami analitycznymi, wdrożeniowymi oraz wsparcia w celu realizacji potrzeb klientów
Nasze wymagania
Dobra znajomość języka C# (.NET)
Praktyczna znajomość MS SQL Server (T-SQL, optymalizacja zapytań, procedury składowane)
Umiejętność pracy w modelu klient - serwer
Umiejętność analitycznego myślenia oraz rozwiązywania problemów
Znajomość języka angielskiego umożliwiająca czytanie dokumentacji technicznej
Mile widziane
Znajomość PowerBuilder
To oferujemy
Dofinansowanie zajęć sportowych
Prywatną opiekę medyczną
Dofinansowanie nauki języków
Dofinansowanie szkoleń i kursów
Ubezpieczenie na życie
Program rekomendacji pracowników
Niekorporacyjną atmosferę pracy
Wyjazdy integracyjne
Wsparcie merytoryczne od liderów technologicznych
Niezbędne narzędzia pracy
Benefity
dofinansowanie zajęć sportowych
prywatna opieka medyczna
dofinansowanie nauki języków
owoce
spotkania integracyjne
brak dress code’u
kawa / herbata
parking dla pracowników

SIMPLE S.A.
Przewiń do profilu firmy
SIMPLE to zespół ponad 200 pasjonatów IT, którzy od prawie 40 lat wspólnie tworzą systemy wspierające rozwój firm. Specjalizujemy się w budowie i wdrażaniu systemów klasy EPR, HCM, systemów dziekanatowych oraz medycznych. Jesteśmy sprawdzonym wieloletnim partnerem dla organizacji publicznych i prywatnych. Nasza siła tkwi w zespole - w ludziach, którzy z pasją i odpowiedzialnością podchodzą do każdego projektu. Pracujemy ramię w ramię z naszymi klientami słuchając, doradzając i dostosowując rozwiązania do ich unikalnych potrzeb. Nasze wartości to innowacja, przedsiębiorczość i zaufanie.
Od 2021 roku jesteśmy spółką należącą do Total Specific Solution (TSS) wchodzącego w skład grupy Topicus.com Inc, spółki publicznej notowanej na kanadyjskiej giełdzie TSX Venture Exchange. TSS jest właścicielem ponad 100 europejskich firm programistycznych w 14 krajach, oferujących rozwiązania dla wielu branż i biznesów.
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Wszystkie informacje o przetwarzaniu danych osobowych w tej rekrutacji znajdziesz w formularzu aplikacyjnym, po kliknięciu w przycisk "Aplikuj Teraz".

Praca
Warszawa
IT - Rozwój oprogramowania
Programowanie
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
Eurotronic Sp. z o.o.
.NET Developer Najlepiej dopasowana
Eurotronic Sp. z o.o.
Warszawa, Włochy


PEKABEX
Programista (m/k)
PEKABEX
Warszawa, Śródmieście


DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net
DIAGNOSTYKA S.A.
Kraków, Czyżyny


Software Developer (.NET) (k/m)
Logisystem Sp. z o.o.
Warszawa, Białołęka


VentiAir Innvations sp. z o.o.
Programista / Programistka
VentiAir Innvations sp. z o.o.
Częstochowa


NASK
Starszy programista .NET/C# (K/M)
NASK
10 000–16 000 zł brutto / mies.
Warszawa, Wola


Next Technology Professionals Sp. z o.o.
Superoferta
.NET Fullstack Developer (Relativity) Śpiesz się!
Next Technology Professionals Sp. z o.o.
170–220 zł / godz. (zal. od umowy)
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Programista / Programistka, Bronisława Czecha 49/51, Wawer, Warszawa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube

---------
Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

Next Technology Professionals Sp. z o.o.
.NET Fullstack Developer (Relativity)
Next Technology Professionals Sp. z o.o.O firmie
ważna 11 godzin


170,00 – 220,00 zł
netto (+ VAT) / godz. | kontrakt B2B
Siedziba firmy:
Warszawamazowieckie
Miejsce pracy:
Cała Polska (praca zdalna)
umowa o pracę, kontrakt B2B
pełny etat
starszy specjalista / starsza specjalistka (senior)
praca zdalna
Praca od zaraz
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
System wynagrodzeń:
stała podstawa wynagrodzenia
Specjalizacje:
Full-stack
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
C#
.NET
Microsoft SQL Server
Git
JavaScript
TypeScript
O projekcie
💼 Projekt: Nasz klient to firma z siedzibą w Niemczech, rozwijająca zaawansowane systemy klasy enterprise do procesowania i analizy dużych wolumenów danych. Projekt polega na budowie od podstaw nowoczesnych aplikacji oraz usług chmurowych, które zastąpią rozbudowane skrypty starszej generacji (migracja legacy). Środowiskiem bazowym, w obrębie którego tworzone są rozwiązania, jest zaawansowana platforma Relativity. Praca będzie obejmować projektowanie wydajnych serwisów REST, rozwój procesów działających w tle oraz optymalizację masowych operacji systemowych.
🛠 Stack technologiczny: C#, .NET Framework 4.8.1 (z elementami ASP.NET Core), Microsoft SQL Server (T-SQL), REST API, Git, JavaScript/TypeScript (Vue, React lub Angular), Relativity SDK.
⚙️ Metodyka pracy: Środowisko Agile / Scrum, praca w innowacyjnym modelu AI-assisted development (codzienne wykorzystanie zaawansowanych asystentów kodowania)
🌍 Model współpracy: Praca w pełni zdalna, obowiązują stałe godziny współpracy (10:00 - 18:00).
💰 Wynagrodzenie: 170 - 220 PLN/h
🚀 Start współpracy: ASAP / 1 miesiąc
Tak organizujemy naszą pracę
Tak pracujemy
u klientamasz wpływ na rozwiązania technologiczne
Twój zakres obowiązków
Projektowanie, wdrażanie oraz optymalizacja kluczowych usług backendowych i serwisów REST.
Sukcesywna migracja i przepisywanie dotychczasowych rozwiązań (legacy) na nowoczesne aplikacje.
Zaawansowana praca z architekturą bazodanową, w tym tworzenie złożonych zapytań SQL.
Aktywna integracja i codzienna praca z rozwiązaniami opartymi na sztucznej inteligencji, wspierającymi proces wytwarzania oprogramowania.
Rozwój i wsparcie warstwy frontendowej (ok. 30% czasu pracy) przy wykorzystaniu frameworków takich jak Angular, React lub Vue.
Dbanie o wysoką wydajność, czystość kodu oraz skalowalność rozwiązań w międzynarodowym środowisku technologicznym.
Nasze wymagania
Minimum 4 lata komercyjnego doświadczenia na stanowisku programisty / inżyniera oprogramowania.
Ugruntowana, praktyczna znajomość języka C# oraz ekosystemu .NET.
Doświadczenie w pracy z systemem Relativity lub silnej chęci rozwoju w tym ekosystemie.
Bardzo dobrego zrozumienia zagadnień związanych z relacyjnymi bazami danych oraz MS SQL Server.
Komercyjne doświadczenie w projektowaniu i integracji z usługami sieciowymi (REST API).
Zrozumienie nowoczesnych praktyk wersjonowania kodu (Git) i zasad projektowania obiektowego.
Gotowość o podejmowania zadań z obszaru frontendu w JavaScript/TypeScript.
Rozwinięte umiejętności analityczne oraz skuteczność w rozwiązywaniu skomplikowanych problemów technicznych.
To oferujemy
Długofalową współpracę w kluczowym projekcie transformacyjnym.
Pracę w ultranowoczesnym środowisku wykorzystującym najnowsze narzędzia AI wspomagające programistów.
Możliwość rozwoju przy budowaniu rozbudowanych architektur chmurowych.
Etapy rekrutacji
1
Rozmowa weryfikująca dopasowanie do celów operacyjnych

2
Rozmowa techniczna

Next Technology Professionals Sp. z o.o.
Przewiń do profilu firmy
Next Technology Professionals to wyspecjalizowana agencja rekrutacyjna i firma outsourcingowa o silnym profilu technologicznym.
Od ponad 10 lat wspieramy firmy w budowie zespołów IT, AI, Cybersecurity, SAP oraz w rekrutacjach dla finansów, inżynierii i marketingu.
Zrealizowaliśmy ponad 1000 skutecznych procesów rekrutacyjnych dla korporacji, scale-upów i dynamicznie rosnących startupów.
Przesyłając swoje CV do Next Technology Professionals, trafiasz do starannie wyselekcjonowanej bazy kandydatów realizujących projekty dla wiodących globalnych organizacji. Pracujemy wyłącznie w oparciu o aktualne, konkretne potrzeby klientów.
Jeśli Twój profil będzie odpowiadał jednemu z prowadzonych procesów, skontaktujemy się niezwłocznie.
W analizie aplikacji wspieramy się sztuczną inteligencją, jednak Twój profil zawsze weryfikuje rekruter – to człowiek podejmuje ostateczną decyzję
Aplikuj

Zapisz

Drukuj

Udostępnij
Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez Next Technology Professionals Sp. z o.o. z siedzibą w: Ogrodowa 58, 00-876 Warszawa (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
IT - Administracja
Administrowanie bazami danych i storage
Aplikuj

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


GOLDENORE ITC sp. z o.o.
Superoferta
Full Stack Developer (.NET / Angular / SQL)
GOLDENORE ITC sp. z o.o.
Warszawa


NOVOMATIC Technologies Poland Sp. z o.o.
Superoferta
.NET Software Developer
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


Micro Solutions Sp. z o.o.
Superoferta
Full Stack .NET Developer Śpiesz się!
Micro Solutions Sp. z o.o.
Wrocław, Fabryczna


DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny


VentiAir Innvations sp. z o.o.
Programista / Programistka Hit!
VentiAir Innvations sp. z o.o.
Częstochowa



Pokaż więcej podobnych
16
Włącz powiadomienie
.NET Fullstack Developer (Relativity), Warszawa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube
----------------
Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

VentiAir Innvations sp. z o.o.
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie
ważna jeszcze 8 dni

(do 08 paź)


Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
prywatna opieka medyczna
elastyczny czas pracy
brak dress code’u
kawa / herbata
parking dla pracowników

VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny


ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


NOVOMATIC Technologies Poland Sp. z o.o.
Superoferta
.NET Software Developer Hit!
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)


Nexus Polska Sp. z o.o.
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


benett PEOPLE
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa


TeamQuest Sp. z o.o.
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Programista / Programistka, Częstochowa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube
Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

VentiAir Innvations sp. z o.o.
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie
ważna jeszcze 8 dni

(do 08 paź)


Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
prywatna opieka medyczna
elastyczny czas pracy
brak dress code’u
kawa / herbata
parking dla pracowników

VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny


ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


NOVOMATIC Technologies Poland Sp. z o.o.
Superoferta
.NET Software Developer Hit!
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)


Nexus Polska Sp. z o.o.
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


benett PEOPLE
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa


TeamQuest Sp. z o.o.
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Programista / Programistka, Częstochowa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube
Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

VentiAir Innvations sp. z o.o.
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie
ważna jeszcze 8 dni

(do 08 paź)


Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
prywatna opieka medyczna
elastyczny czas pracy
brak dress code’u
kawa / herbata
parking dla pracowników

VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny


ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


NOVOMATIC Technologies Poland Sp. z o.o.
Superoferta
.NET Software Developer Hit!
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)


Nexus Polska Sp. z o.o.
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


benett PEOPLE
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa


TeamQuest Sp. z o.o.
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Programista / Programistka, Częstochowa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube
Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

VentiAir Innvations sp. z o.o.
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie
ważna jeszcze 8 dni

(do 08 paź)


Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
prywatna opieka medyczna
elastyczny czas pracy
brak dress code’u
kawa / herbata
parking dla pracowników

VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny


ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


NOVOMATIC Technologies Poland Sp. z o.o.
Superoferta
.NET Software Developer Hit!
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)


Nexus Polska Sp. z o.o.
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


benett PEOPLE
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa


TeamQuest Sp. z o.o.
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Programista / Programistka, Częstochowa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube
Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

VentiAir Innvations sp. z o.o.
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie
ważna jeszcze 8 dni

(do 08 paź)


Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
prywatna opieka medyczna
elastyczny czas pracy
brak dress code’u
kawa / herbata
parking dla pracowników

VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny


ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


NOVOMATIC Technologies Poland Sp. z o.o.
Superoferta
.NET Software Developer Hit!
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)


Nexus Polska Sp. z o.o.
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


benett PEOPLE
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa


TeamQuest Sp. z o.o.
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Programista / Programistka, Częstochowa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube
Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

VentiAir Innvations sp. z o.o.
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie
ważna jeszcze 8 dni

(do 08 paź)


Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
prywatna opieka medyczna
elastyczny czas pracy
brak dress code’u
kawa / herbata
parking dla pracowników

VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny


ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


NOVOMATIC Technologies Poland Sp. z o.o.
Superoferta
.NET Software Developer Hit!
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)


Nexus Polska Sp. z o.o.
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


benett PEOPLE
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa


TeamQuest Sp. z o.o.
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Programista / Programistka, Częstochowa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube
--------
Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Pracuj.pl
Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
Dla firm
Dodaj ogłoszenie

VentiAir Innvations sp. z o.o.
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie
ważna jeszcze 8 dni

(do 08 paź)


Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
Praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
prywatna opieka medyczna
elastyczny czas pracy
brak dress code’u
kawa / herbata
parking dla pracowników

VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
DIAGNOSTYKA S.A.
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny


ITP IT PERFORMANCE sp. z o.o.
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa


NOVOMATIC Technologies Poland Sp. z o.o.
Superoferta
.NET Software Developer Hit!
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)


Nexus Polska Sp. z o.o.
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań


Eurotronic Sp. z o.o.
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy


benett PEOPLE
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa


TeamQuest Sp. z o.o.
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa



Pokaż więcej podobnych
16
Włącz powiadomienie
Programista / Programistka, Częstochowa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

eRecruiter
Robota.ua
The Protocol
Softgarden
Absence
Kadromierz
Download on the App Store
Get it on Google Play
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
The Network
Facebook
Instagram
TikTok
YouTube

