# Pracuj.pl — kolejne surowe zrzuty

## Chrome tab 2063916234

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Starszy Programista lub Programistka .Net
DIAGNOSTYKA S.A.O firmie

ważna jeszcze 3 dni

(do 03 paź)

Profesora Michała Życzkowskiego 18, Czyżyny, Krakówmałopolskie
umowa o pracę, kontrakt b2b
pełny etat
specjalista / specjalistka (mid / regular), starszy specjalista / starsza specjalistka (senior)
praca zdalna
praca od zaraz
szukamy wielu kandydatów
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
System wynagrodzeń:
stała podstawa wynagrodzenia
Specjalizacje:
Backend
Siedziba firmy

DIAGNOSTYKA S.A.

Profesora Michała Życzkowskiego 18, Czyżyny, Kraków

Sprawdź czas dojazdu

Zlokalizuj się lub podaj dokładny adres

Samochód

-

Komunikacja

-

Rower

-

Pieszo

-

Technologie, których używamy
Wymagane
C#
.NET
Mile widziane
Google Cloud Platform
Microsoft Azure
Kubernetes
O projekcie
Nie szukamy osoby do zamykania kolejnych ticketów w istniejącym systemie. Szukamy Starszego Programisty lub Programistki .NET - osoby, która pomoże nam przebudować architekturę kanałów cyfrowych i tworzyć rozwiązania wykorzystywane w obsłudze klientów na dużą skalę.
Przechodzimy od silnie powiązanych aplikacji i wspólnych komponentów do architektury opartej na autonomicznych domenach biznesowych, mikroserwisach, Backend for Frontend,API-first, komunikacji synchronicznej i zdarzeniowej, konteneryzacji i środowisku chmurowym, automatyzacji procesu wytwórczego, odpowiedzialności zespołu za rozwiązanie od projektu do produkcji.
Budujemy fundament, na którym będą rozwijane kolejne cyfrowe procesy, produkty i doświadczenia klientów.
Rozwój kompetencji cloud-native, DevSecOps i architektury rozproszonej.
Stabilne środowisko pracy połączone z ambitnym zakresem technologicznym.
Współpracę w oparciu o umowę o pracę lub kontrakt.
Pracę w systemie zdalnym lub hybrydowym. Ty wybierasz.
Twój zakres obowiązków
Projektujesz i rozwijasz usługi backendowe w C# i .NET.
Budujesz mikroserwisy i komponenty warstwy Digital Backend / BFF.
Rozdzielasz istniejące logiki na jasno zdefiniowane domeny i odpowiedzialności.
Projektujesz kontrakty API oraz integracji z systemami wewnętrznymi i zewnętrznymi.
Tworzysz rozwiązania zgodne z podejściem Domain-Driven Design i architekturą modularną.
Rozwijasz komunikacje REST, gRPC oraz mechanizmy event-driven.
Zajmujesz się konteneryzacją usług i ich uruchamianiem w środowisku Kubernetes.
Współtworzysz standardy dotyczące bezpieczeństwa, wersjonowania API, logowania, monitoringu i obsługi błędów.
Budujesz testy automatyczne: jednostkowe, integracyjne, kontraktowe i end-to-end.
Bierzesz udział w code review, decyzjach architektonicznych oraz analizie ryzyk technicznych.
Współpracujesz z frontend developerami, architektami, analitykami, QA, DevOps i właścicielami produktów.
Wspierasz mniej doświadczonych developerów i podnosisz jakość pracy całego zespołu.
Bierzesz odpowiedzialność za działanie rozwiązania również po wdrożeniu produkcyjnym.
Nasze wymagania
Bardzo dobrze znasz C# i współczesny .NET.
Masz kilkuletnie doświadczenie w tworzeniu systemów backendowych działających produkcyjnie.
Masz doświadczenia w projektowaniu i rozwijaniu API.
Znasz zasady programowania obiektowego, SOLID oraz wzorce projektowe.
Potrafisz projektować kod, który da się rozwijać, testować i utrzymywać.
Masz doświadczenie z architekturą mikroserwisową lub modularnym monolitem.
Bardzo dobrze znasz bazy danych.
Masz praktyczną znajomość testów automatycznych.
Potrafisz diagnozować problemy wydajnościowe i produkcyjne.
Rozumiesz zagadnienia związane ze skalowalnością, niezawodnością i bezpieczeństwem.
Potrafisz podejmować decyzje techniczne na podstawie kosztu, ryzyka i wartości biznesowej.
Masz otwartość do kwestionowania słabych rozwiązań — niezależnie od tego, kto je zaproponował.
Jasno komunikujesz problemy i rekomendacje rozwiązań.
Mile widziane
Doświadczenie z GCP, Azure lub inną chmurą publiczną.
Praktyczna znajomość Kubernetes.
Doświadczenie z systemami opartymi na zdarzeniach.
Znajomość DDD, CQRS lub wzorca Saga.
Doświadczenie z observability i systemami wysokiej dostępności.
Znajomość zagadnień DevSecOps.
Doświadczenie w migracji systemów legacy.
Praca przy systemach o dużej liczbie użytkowników lub wysokich wymaganiach bezpieczeństwa.
Doświadczenie w bankowości, finansach, e-commerce albo innych środowiskach regulowanych.
To oferujemy
Realny wpływ na powstającą architekturę kanałów cyfrowych.
Pracę przy jednym z najważniejszych programów transformacji technologicznej organizacji.
Możliwość budowania nowych komponentów zamiast wyłącznie utrzymywania systemów legacy.
Skalę, na której decyzje techniczne naprawdę mają znaczenie.
Bezpośrednią współpracę z doświadczonymi developerami, architektami i liderami technologicznymi.
Przestrzeń do proponowania zmian i kwestionowania istniejących rozwiązań.
Rozwój kompetencji cloud-native, DevSecOps i architektury rozproszonej.
Stabilne środowisko pracy połączone z ambitnym zakresem technologicznym.
Współpracę w oparciu o umowę o pracę lub kontrakt.
Pracę w systemie zdalnym lub hybrydowym.
Benefity:
Dofinansowujemy karty sportowe: MultiSport lub Medicover Sport.
Zapewniamy pakiety prywatnej opieki medycznej w Luxmed dla Ciebie i Twoich bliskich.
Mamy zniżki na badania w naszych laboratoriach dla Ciebie (70%) i Twojej rodziny (20%).
Korzystamy ze szkoleń, kursów e-learningowych i uczymy się języków obcych.
Możesz dołączyć do preferencyjnego ubezpieczenia grupowego PZU.
Możesz trenować z nami w regionalnych drużynach siatkarskich, brać udział w maratonach, półmaratonach czy Runmageddonie na terenie całej Polski.
Oferujemy wsparcie finansowe z ZFŚS w trudnych sytuacjach życiowych.
Bierzemy udział w rekrutacjach wewnętrznych i programie poleceń z nagrodami finansowymi.
Benefity
Dofinansowanie zajęć sportowych
Prywatna opieka medyczna
Dofinansowanie nauki języków
Ubezpieczenie na życie
Możliwość pracy zdalnej
Zniżki na firmowe produkty i usługi
Spotkania integracyjne
Firmowa drużyna sportowa
Program rekomendacji pracowników
Inicjatywy dobroczynne
DIAGNOSTYKA S.A.
Przewiń do profilu firmy
DIAGNOSTYKA to największa w Polsce sieć laboratoriów medycznych posiadająca najbogatszy wybór badań laboratoryjnych. Specjalizuje się w realizacji profesjonalnych usług od pobrania i transportu materiału biologicznego, poprzez wykonanie badania, aż do dostarczenia wyniku analiz medycznych w możliwie najkrótszym czasie. Obsługujemy miliony pacjentów rocznie oraz współpracujemy z kilkoma tysiącami placówek ochrony zdrowia.
Aplikuj szybko
Zapisz
Drukuj
Udostępnij

Klikając w przycisk „Wyślij” zgadzasz się na przetwarzanie przez Diagnostyka S.A…  rozwiń

W naszej Spółce obowiązuje Procedura zgłoszeń naruszeń prawa i podejmowania dzia…  rozwiń

Praca
Kraków
IT - Administracja
Administrowanie systemami
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Senior Backend Developer (.NET) (m/f)
Grupa Pracuj
110–125 zł netto (+ VAT) / godz.
Warszawa, Wola
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy
Starszy programista .NET/C# (K/M)
NASK
10 000–16 000 zł brutto / mies.
Warszawa, Wola
Superoferta
Senior C# Developer
Xopero Software S.A.
16 600–23 500 zł / mies. (zal. od umowy)
Gorzów Wielkopolski
Superoferta
Programista Systemów ERP Nowość!
Asco
10 000–17 000 zł netto (+ VAT) / mies.
Kraków, Bronowice
Pokaż więcej podobnych
16
Włącz powiadomienie

Starszy Programista lub Programistka .Net, Profesora Michała Życzkowskiego 18, Czyżyny, Kraków

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916235

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
.NET Developer
ITP IT PERFORMANCE sp. z o.o.O firmie

ważna jeszcze 11 dni

(do 11 paź)

120,00 – 145,00 zł
netto (+ VAT) / godz. | kontrakt B2B
Warszawamazowieckie
kontrakt b2b
pełny etat
specjalista / specjalistka (mid / regular), starszy specjalista / starsza specjalistka (senior)
praca hybrydowa
praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend, Security
Technologie, których używamy
Wymagane
C#
.NET
O projekcie
Poszukujemy osoby (m/k) do roli .NET Developer. Praca jest dedykowana dla naszego klienta.
Dołączysz do zespołu rozwijającego systemy z obszaru Security / Video-CCTV / Data Processing, w których kluczowe znaczenie mają wydajność, stabilność i przetwarzanie danych w czasie rzeczywistym.
Projekt rozwijany jest w środowisku on-premise, z wykorzystaniem .NET 8 i planowaną migracją do .NET 10. Praca może również obejmować, w ograniczonym zakresie, starsze komponenty systemów oparte na .NET Framework.
Tak organizujemy naszą pracę
Tak pracujemy
u klienta
Twój zakres obowiązków
Rozwój i utrzymanie aplikacji backendowych w C#/.NET w obszarze systemów bezpieczeństwa i monitoringu wizyjnego.
Implementacja nowych funkcjonalności oraz rozbudowa istniejących modułów systemu.
Praca nad efektywnym wykorzystaniem i zarządzaniem pamięcią w aplikacjach przetwarzających dane w czasie rzeczywistym.
Integracja oprogramowania z innymi systemami, a w wybranych zadaniach poprzez komunikację socketową.
Diagnozowanie i usuwanie błędów oraz usprawnianie wydajności i stabilności aplikacji.
Tworzenie czytelnego, testowalnego kodu oraz udział w code review.
Współpraca z zespołem przy doborze rozwiązań technicznych i realizacji zadań developerskich.
Nasze wymagania
Minimum 4 lata doświadczenia w tworzeniu aplikacji w C#/.NET.
Dobra znajomość .NET, ASP.NET Core oraz tworzenia i rozwijania Web API.
Praktyczna znajomość programowania asynchronicznego i wielowątkowego.
Rozumienie mechanizmów zarządzania pamięcią w .NET i ich wpływu na wydajność aplikacji.
Doświadczenie w diagnozowaniu błędów i usprawnianiu działania aplikacji, np. pod kątem czasu odpowiedzi lub zużycia pamięci.
Znajomość zasad projektowania czytelnego, łatwego w utrzymaniu kodu oraz umiejętność stosowania wzorców projektowych.
Samodzielność w realizacji zadań i gotowość do poznawania działania systemu poza samą warstwą API, w tym przetwarzania danych i komunikacji między komponentami.
To oferujemy
Kontrakt B2B
Stawka: (120 - 145) pln/h + VAT
Praca w modelu hybrydowym: (2-3 dni w tyg z biura zlokalizowanym w warszawskim Wawrze)
Długoterminowe i rozwojowe projekty
Stabilny projekt z realnym znaczeniem biznesowym
Tak pracujemy nad projektem
dokumentacja
narzędzia do trackowania zadań
środowiska testowe
ITP IT PERFORMANCE sp. z o.o.
Przewiń do profilu firmy
Jako ITP IT Performance specjalizujemy się w outsourcingu, konsultingu i rekrutacji głównie w obszarze IT.
Aplikuj
Zapisz
Drukuj
Udostępnij

Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez ITP IT PERFORMANCE sp. z o.o. z siedzibą w: Długa 29, 00-238 Warszawa (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
IT - Administracja
Bezpieczeństwo / Audyt
Aplikuj
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
.NET Developer Najlepiej dopasowana
Eurotronic Sp. z o.o.
Warszawa, Włochy
Superoferta
Senior Backend Developer (.NET) (m/f)
Grupa Pracuj
110–125 zł netto (+ VAT) / godz.
Warszawa, Wola
Superoferta
.Net Developer Śpiesz się!
OPTIVEUM SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
120 zł netto (+ VAT) / godz.
Warszawa
Starszy programista .NET/C# (K/M)
NASK
10 000–16 000 zł brutto / mies.
Warszawa, Wola
Superoferta
.NET Software Developer
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)
Superoferta
Full Stack Developer (.NET / Angular / SQL)
GOLDENORE ITC sp. z o.o.
Warszawa
Software Developer (.NET) (k/m)
Logisystem Sp. z o.o.
Warszawa, Białołęka
Pokaż więcej podobnych
16
Włącz powiadomienie

.NET Developer, Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916236

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
.NET Developer
Nexus Polska Sp. z o.o.O firmie

ważna jeszcze 21 dni

(do 21 paź)

10 000 – 15 000 zł
brutto / mies. | umowa o pracę
12 000 – 18 000 zł
netto (+ VAT) / mies. | kontrakt B2B
Poznańwielkopolskie
umowa o pracę, kontrakt b2b
pełny etat
specjalista / specjalistka (mid / regular)
praca zdalna
szukamy wielu kandydatów2 wakaty
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Technologie, których używamy
Wymagane
C#
.NET
ASP.NET Core
SQL
Git
Mile widziane
Angular 8+
TypeScript
Docker
PL/SQL
O projekcie
Szukamy programistów z doświadczeniem w pracy nad aplikacjami .NET. Dołączysz do jednego z naszych zespołów tworzących rozwiązania webowe oparte o .NET (Core / Framework) oraz Angular. Znajdziemy miejsce zarówno dla typowego backendowca, jak i full stacka lubiącego JavaScript / TypeScript. Będziesz brał udział w wytwarzaniu aplikacji oraz usług stanowiących elementy systemów szpitalnych, które wspomagają codzienną pracę personelu medycznego.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniemasz wpływ na wybór narzędzi i technologiimasz wpływ na rozwiązania technologiczneagile
Twój zakres obowiązków
tworzenie backendu (.NET / .NET Core) aplikacji w przemyślanej architekturze,
tworzenie testów automatycznych (jednostkowych, integracyjnych, E2E),
ciągły rozwój umiejętności,
projektowanie tworzonych komponentów,
code review i współpraca z innymi programistami oraz testerami (team QA),
tworzenie testów automatycznych,
wsparcie dla konsultantów, którzy zajmują się wdrażaniem tworzonych przez Ciebie funkcjonalności,
udział w spotkaniach agile'owych, brainstormach i sesjach event storming.
Nasze wymagania
dobra znajomość C# / .NET,
znajomość webowych technologii .NETowych (np. ASP.NET Core),
znajomość relacyjnych baz danych i języka SQL,
znajomość dobrych praktyk programistycznych,
znajomość Git,
znajomość języka angielskiego.
Mile widziane
znajomość Angular 8+, TypeScript,
doświadczenie w pracy w zwinnych metodykach,
doświadczenia z konteneryzacją (Docker, Kubernetes),
doświadczenie w tworzeniu rozwiązań chmurowych na platformie Azure,
praktyczna znajomość architektury mikroserwisowej,
znajomość Oracle PL/SQL.
To oferujemy
pracę w firmie o ustabilizowanej pozycji na rynku, będącej częścią grupy NEXUS AG,
czynny udział w pracach samoorganizującego się zespołu: przy projektowaniu rozwiązań, w burzach mózgów, udział w dyskusjach dotyczących organizacji pracy,
dbałość o profesjonalną organizację pracy,
issue tracker (Redmine),
code review (GitLab),
continuous integration (TeamCity / GitLab CI),
statyczna analiza kodu (SonarQube),
testy automatyczne,
elastyczny czas pracy z możliwością Home Office,
praca zdalna,
biuro w centrum miasta z bardzo dobrym dojazdem komunikacją miejską z jednym z najbardziej malowniczych widoków w Poznaniu.
Tak pracujemy nad projektem
code review
statyczna analiza kodu
Continuous Integration
DevOps
automatyzacja testów
testy manualne
Benefity
Dofinansowanie zajęć sportowych
Prywatna opieka medyczna
Dofinansowanie szkoleń i kursów
Ubezpieczenie na życie
Możliwość pracy zdalnej
Elastyczny czas pracy
Spotkania integracyjne
Jeżeli spełniasz nasze oczekiwania, jesteś zainteresowany ofertą i chciałbyś stać się członkiem naszego zespołu, prześlij nam swoje CV wraz ze zgodą na przetwarzanie danych osobowych na potrzeby rekrutacji.
Zrób pierwszy krok, podejmij wyzwanie i kliknij w „Aplikuj teraz”!
Na podstawie art. 8 ust 1 Dyrektywy Parlamentu Europejskiego i Rady (UE) 2019/1937 z dnia 23 października 2019 r. w sprawie ochrony osób zgłaszających naruszenia prawa Unii, Nexus Polska Sp. z o.o. z siedzibą w Poznaniu wprowadził procedurę zgłoszeń wewnętrznych i podejmowania działań następczych, określającą tryb przyjmowania zgłoszeń wewnętrznych dotyczących informacji o naruszeniu prawa lub regulacji i standardów etycznych ustanowionych w Spółce, a także podejmowania działań następczych w związku z tymi zgłoszeniami. Jeżeli uzna Pani/Pan, że doszło do naruszenia prawa, ma Pani/Pan możliwość dokonania zgłoszenia naruszenia prawa zgodnie z przyjętą Procedurą, dostępną na stronie: www.nexuspolska.pl
Nexus Polska Sp. z o.o.
Przewiń do profilu firmy
Nexus Polska jest jednym z największych producentów oprogramowania dla polskiego rynku ochrony zdrowia. Nasze oprogramowanie jest wdrożone w około 130 polskich szpitalach. Jesteśmy częścią grupy NEXUS AG, czołowej europejskiej firmy dostarczającej rozwiązania dla sektora opieki zdrowotnej. Tworzymy ekosystem rozwiązań, na który składa się kilkadziesiąt różnych modułów, począwszy od obsługi ruchu chorych, rejestracji, dokumentacji medycznej przez aptekę, laboratorium, pracownie diagnostyczne, szpitalne magazyny oraz moduł rozliczeń po aplikacje internetowe i usługi umożliwiające współpracę wielu jednostek medycznych. Produkty Nexus Polska budzą zainteresowanie naszych zagranicznych partnerów i mamy plany wdrożeń poza granicami kraju.
Złożone potrzeby pacjentów, lekarzy, pielęgniarek, diagnostów, analityków oraz innych osób zaangażowanych w służbę zdrowia (oraz wymogi prawne) to nasz żywioł. Branża medyczna nieustannie dostarcza nam interesujących wyzwań, tworząc znakomite warunki do rozwoju zawodowego dla programistów oraz specjalistów IT.
Aplikuj szybko
Zapisz
Drukuj
Udostępnij

Klauzula zgody, rekrutacja: Prosimy o przesłanie CV zawierającego dane określone w Art. 221 ust. 1 Kodeksu pracy, tj. imię i nazwisko, datę urodzenia, dane kontaktowe, wykształcenie, kwalifikacje zawodowe, przebieg dotychczasowego zatrudnienia. Jeżeli w Państwa dokumentach aplikacyjnych znajdują się dane wykraczające, poza zakres określony powyżej, prosimy o dodanie klauzuli: „Wyrażam zgodę na przetwarzanie przez Nexus Polska Sp. z o.o. z siedzibą w Poznaniu moich danych osobowych zawartych w przesłanych dokumentach aplikacyjnych wykraczających poza zakres określony w Art. 221 ust. 1. Administratorem Pani/Pana danych osobowych jest spółka Nexus Polska Sp. z o.o. siedzibą w Poznaniu przy ul. Szyperskiej 14, 61-754 Poznań, e-mail: biuro@nexuspolska.pl, 2. W sprawach związanych z Pani/Pana danymi proszę kontaktować się z Inspektorem Ochrony Danych Osobowych: iod@nexuspolska.pl 3. Informujemy, że Pani/Pana dane osobowe określone w przepisach prawa pracy przetwarzane będą w celu przeprowadzenia procesu rekrutacyjnego na podstawie Art. 6 ust. 1 pkt. b) RODO (przetwarzanie jest niezbędne do wykonania umowy, której stroną jest osoba, której dane dotyczą, lub do podjęcia działań na żądanie osoby, której dane dotyczą, przed zawarciem umowy), a w zakresie wykraczającym poza ten dane, na podstawie Państwa zgody - Art. 6 ust. 1 pkt. a RODO, która może zostać odwołana w dowolnym czasie 4. Dane udostępnione przez Panią/Pana nie będą podlegały udostępnieniu podmiotom trzecim. Odbiorcami danych będą tylko instytucje upoważnione z mocy prawa. 5. Pani/Pana dane osobowe będą przechowywane do czasu zakończenia procesu rekrutacji. 6. Posiada Pani/Pan prawo dostępu do treści swoich danych oraz prawo ich sprostowania, usunięcia, ograniczenia przetwarzania, prawo do cofnięcia zgody w dowolnym momencie bez wpływu na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej cofnięciem; 7. Ma Pan/Pani prawo wniesienia skargi do organu nadzorczego, tj. Prezesa Urzędu Ochrony Danych Osobowych gdy uzna Pani/Pan, iż przetwarzanie danych osobowych Pani/Pana dotyczących narusza przepisy RODO. 8. Podanie przez Pana/Panią danych osobowych w zakresie wynikającym z art. 221 Kodeksu pracy jest warunkiem wzięcia udziału w procesie rekrutacji. Podanie innych danych jest dobrowolne. 9. Administrator danych nie ma zamiaru przekazywać danych osobowych do państwa trzeciego lub organizacji międzynarodowej, a dane udostępnione przez Panią/Pana nie będą podlegały profilowaniu.

Praca
Poznań
IT - Rozwój oprogramowania
Analiza biznesowa i systemowa
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy
Starszy programista .NET/C# (K/M)
NASK
10 000–16 000 zł brutto / mies.
Warszawa, Wola
Superoferta
.NET Software Developer Hit!
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)
Superoferta
Backend .NET Developer Najlepiej dopasowana
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa
Superoferta
Full Stack .NET Developer Śpiesz się!
Micro Solutions Sp. z o.o.
Wrocław, Fabryczna
Programista / Programistka Full Stack .NET
POINTER Sp. z o.o.
Poznań, Jeżyce
Programista (m/k)
PEKABEX
Poznań, Jeżyce
Pokaż więcej podobnych
16
Włącz powiadomienie

.NET Developer, Poznań

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916237

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
.Net Developer
EUVIC S.A.O firmie

ważna jeszcze 8 dni

(do 08 paź)

Katowiceśląskie
kontrakt b2b
pełny etat
specjalista / specjalistka (mid / regular), starszy specjalista / starsza specjalistka (senior)
praca hybrydowa
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Technologie, których używamy
Wymagane
.NET
C#
.NET Core
Angular
React.js
SQL
Jira
Bitbucket
Confluence
Mile widziane
Docker
Kubernetes
Microsoft Azure
Jenkins
Nexus
O projekcie
Poszukujemy osoby na stanowisko Mid/Senior .NET Developer do pracy przy rozwoju oraz utrzymaniu aplikacji backendowych w środowisku międzynarodowym. Rola obejmuje projektowanie i implementację skalowalnych rozwiązań, tworzenie API oraz integrację systemów. Współpraca odbywa się z globalnymi klientami z branży retail, przy silnym fokusie na nowoczesne technologie i rozwiązania chmurowe.
Projekt realizowany jest w strukturach globalnej organizacji dostarczającej technologie dla sektora handlu detalicznego. Zespół odpowiada za rozwój i utrzymanie nowoczesnych systemów POS (Point of Sale), integrację rozwiązań oraz wsparcie klientów na rynkach międzynarodowych.
Praca opiera się na nowoczesnym stacku technologicznym i środowisku chmurowym, z naciskiem na wysoką jakość kodu, skalowalność, stabilność oraz długoterminowy rozwój systemów. Developer będzie ściśle współpracować z zespołami frontendowymi, QA oraz interesariuszami biznesowymi.
Technologie: C#, .NET Core / .NET Framework, Angular / React, SQL, Azure, Docker, Kubernetes, Jenkins, Nexus, Atlassian, API Platforms
Model pracy: Hybrydowy – 3 dni w tygodniu z biura klienta w Katowicach, 2 dni Home Office
Czas trwania projektu: Projekt długoterminowy
Rekrutacja: Spotkanie F2F w siedzibie klienta (możliwość pojawienia się zadania praktycznego oraz weryfikacji języka angielskiego)
W trakcie procesu rekrutacji na kolejnych jej etapach wymagana będzie weryfikacja tożsamości kandydata.
Pierwszy dzień pracy odbywać się będzie stacjonarnie w jednym z biur Euvic (onboarding, odbiór sprzętu).
Twój zakres obowiązków
Tworzenie i rozwijanie aplikacji w technologii .NET
Projektowanie oraz implementacja integracji systemowych i API
Rozwój oraz utrzymanie rozwiązań POS i systemów wspierających sprzedaż
Współpraca z międzynarodowym zespołem projektowym
Udział w analizie wymagań oraz projektowaniu rozwiązań technicznych
Dbanie o jakość kodu i stosowanie dobrych praktyk programistycznych
Nasze wymagania
Minimum 3 lata doświadczenia komercyjnego na stanowisku .NET Developera
Bardzo dobra znajomość języka C#
Doświadczenie w pracy z .NET Core lub .NET Framework
Znajomość Angular i/lub React
Praktyczna znajomość SQL
Znajomość wzorców projektowych
Doświadczenie w projektowaniu i integracji API
Komunikatywna znajomość języka angielskiego (preferowane min. B1/B2)
Znajomość narzędzi Atlassian (JIRA, Bitbucket, Confluence)
Mile widziane
Retail domain, integracja systemów, Docker/Kubernetes, Azure, Jenkins/Nexus, API Gateways (np. KrakenD), podstawy DevOps, testy automatyczne
To oferujemy
Sprawny, szybki i przyjazny proces rekrutacyjny (nie tylko umiejętności są dla nas ważne, wspólnie sprawdźmy, czy pasujesz do the Good People)
Pracę i rozwój w renomowanej firmie IT, z ugruntowaną pozycją na rynku
Projekty dla klientów międzynarodowych z wielu branż
Płaską strukturę, politykę „otwartych drzwi” i dbałości o dobre relacje w zespołach
Małe zespoły w dużej firmie i koleżeńską wspólnotę w tych zespołach
Transparentny i atrakcyjny program szkoleniowy oparty na badaniach kompetencji
Bonusowy program poleceń
Wsparcie buddiego w okresie onboardingu
Rozwój wewnątrz organizacji – szkolenia wewnętrzne, „Euvic Talks”, możliwość prowadzenia wewnętrznych szkoleń
Udział w inicjatywach społecznych – wspieramy potrzebujących z udziałem Fundacji The Good People
Ubezpieczenie na życie z możliwością wykupienia dodatkowych pakietów np. opieki onkologicznej
Takie dajemy możliwości rozwoju
budżet rozwojowy
mentoring
szkolenia wewnątrzfirmowe
treningi umiejętności miękkich
wsparcie merytoryczne od liderów technologicznych
wspieramy wydarzenia dla IT
wymiana wiedzy technicznej w firmie
Benefity
Dofinansowanie zajęć sportowych
Prywatna opieka medyczna
Dofinansowanie nauki języków
Dofinansowanie szkoleń i kursów
Ubezpieczenie na życie
Elastyczny czas pracy
Spotkania integracyjne
Brak dress code’u
Kawa / herbata
Napoje
Etapy rekrutacji
1

Spotkanie w siedzibie Klienta

W naszym wewnętrznym badaniu #theGoodPeople wskazali 4 kluczowe aspekty, które cenią najbardziej:
Sam/a decyduję o tym, jak najlepiej wykonać swoją pracę.
Mój manager/ka jest dostępny, otwarty na sugestie i odmienność zdania.
Jestem traktowany/a z należytym szacunkiem.
W moim zespole panuje atmosfera sprzyjająca współpracy.
Dodatkowe Informacje
W Euvic tworzymy środowisko pracy oparte na równości, szacunku i otwartości. Wierzymy, że różnorodność talentów i perspektyw napędza innowacje oraz wspiera zrównoważony rozwój. Dlatego nasze procesy rekrutacyjne są projektowane w sposób, który zapewnia każdemu kandydatowi równe szanse, niezależnie od pochodzenia, płci, wieku, orientacji seksualnej, stanu zdrowia czy innych indywidualnych cech. Dążymy do budowania kultury pracy, w której każdy może rozwijać swój potencjał i czuć się w pełni akceptowany.
EUVIC S.A.
Przewiń do profilu firmy
Euvic - ponad 5000 pracowników i 20 lat doświadczenia niewątpliwie czynią nas dużą firmą. A jednak, mimo upływu czasu i stale powiększającego się grona klientów wciąż jesteśmy firmą stworzoną przez inżynierów IT dla inżynierów IT. Tworzymy prężnie rozwijającą się firmę „z ludzką twarzą”, składającą się z dobrych ludzi, tworzących dobre oprogramowanie. Czyni nas to solidnym partnerem IT skupiających się na własnych osiągnięciach, sukcesach klientów i satysfakcji zawodowej pracowników.
Tak się u nas pracuje
Aplikuj
Zapisz
Drukuj
Udostępnij

Wyrażam zgodę na przetwarzanie przez Euvic S.A. podanych danych w celu prowadzenia przyszłych rekrutacji zgodnie z art.6 ust.1 lit. a RODO. Aby cofnąć zgodę na prowadzenie przyszłych procesów rekrutacyjnych napisz żądanie na adres: rekrutacja@euvic.pl. *Administratorem Danych Osobowych w rozumieniu Rozporządzenia Parlamentu Europejskiego i Rady (UE) 2016/679 z 27.04.2016 w sprawie ochrony osób fizycznych w związku z przetwarzaniem danych osobowych i w sprawie swobodnego przepływu takich danych oraz uchylenia dyrektywy 95/46/WE („RODO") jest Euvic S.A., ul. Przewozowa 32, 44-100 Gliwice. Twoje dane będą przetwarzane w związku z prowadzeniem procesu rekrutacji. Aby skontaktować się z nami, wyślij wiadomość pod e-mail: info@euvic.pl lub zadzwoń pod numer tel. +48 32 279 49 42. Szczegóły dotyczące przetwarzania Twoich danych oraz przysługujących Ci praw możesz przeczytać na stronie: https://www.euvic.com/pl/rodo/. Wszelką korespondencję dotyczącą danych osobowych należy kierować pod adres e-mail: iodo@euvic.pl. Przesłane dane osobowe przetwarzane będą w celu prowadzenia procesu rekrutacji przez Euvic S.A. • Składam aplikację w ramach rekrutacji prowadzonej przez Euvic S.A. Na podstawie ustawy z dnia 14 czerwca 2024 r. o ochronie sygnalistów, niniejszym informuję Panią/Pana, iż w Euvic S.A. obowiązuje procedura zgłoszeń wewnętrznych i podejmowania działań następczych, która dostępna jest na stronie https://www.euvic.com/pl/zglos-naruszenie/ , na podstawie której może Pani/Pan dokonać zgłoszenia naruszenia prawa w zakresie i na zasadach określonych w procedurze

Praca
Katowice
IT - Administracja
Administrowanie systemami
Aplikuj
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
Backend .NET Developer Najlepiej dopasowana
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa
Superoferta
.NET Software Developer
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy
Superoferta
Full Stack .NET Developer Śpiesz się!
Micro Solutions Sp. z o.o.
Wrocław, Fabryczna
Superoferta
.Net Developer Śpiesz się!
OPTIVEUM SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
120 zł netto (+ VAT) / godz.
Warszawa
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
Programista / Programistka w Dziale Serwisu
Mecalux Sp. z o.o.
Gliwice
Pokaż więcej podobnych
16
Włącz powiadomienie

.Net Developer, Katowice

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916238

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Junior Automation Consultant C# (k/m)
benett PEOPLEO firmie

ważna 11 godzin

Warszawamazowieckie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
System wynagrodzeń:
stała podstawa wynagrodzenia
Rekrutujemy dla
Aktualnie, dla naszego klienta, dostawcy zautomatyzowanych procesów biznesowych, poszukujemy kandydata ze znajomością języka C# na stanowisko:
Technologie, których używamy
Wymagane
C#
SQL
Tak organizujemy naszą pracę
Tak pracujemy
u klientamasz wpływ na rozwiązania technologicznekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
Przeprowadzanie testów oprogramowania
Współpraca z partnerami zewnętrznymi w zakresie rozwiązywania błędów platformowych
Tworzenie skryptów z użyciem języków programowania C#/VB/VBA/SQL
Modelowanie i konfiguracja procesów w oparciu o narzędzia platformy Kofax (OCR, Workflow, RPA)
Budowanie procesów z wykorzystaniem predefiniowanych komponentów oraz ich konfiguracja z wykorzystaniem graficznego interfejsu użytkownika
Opracowywanie instrukcji i dokumentacji technicznej
Przygotowanie, zmiana i optymalizacja zapytań, tabel, widoków, rejestrów, procedur składowanych
migracji danych na bazie danych SQL
Tworzenie analiz w zakresie procesów i zbieranie wymagań biznesowych
Nasze wymagania
Doświadczenie w tworzeniu aplikacji
Znajomość programowania w języku C# lub pokrewnym
Umiejętność rozwiązywania problemów i analitycznego myślenia
Organizacja własnej pracy oraz dokładność w wykonywanych obowiązkach
Znajomość składni SQL oraz doświadczenie w pracy z MS SQL Server
Ogólna wiedza z zakresu: infrastruktury IT, systemów Windows, pakietu Office, SOAP/REST
Znajomość systemów kontroli wersji – GIT, SVN
Znajomość języka angielskiego umożliwiająca swobodną komunikację
Mile widziane
Znajomość technologii OCR, RPA
Podział czasu pracy
34
%

Programowanie

33
%

prace projektowe: analiza, wdrożenia, konfirguracje

33
%

współpraca z klientem, rozwiązywanie problemów

To oferujemy
Zatrudnienie na podstawie umowy o pracę
Atrakcyjne wynagrodzenie
Możliwość wdrażania własnych pomysłów i realnego wpływu na wizerunek firmy
Niezbędne narzędzia do pracy
Aplikuj szybko
Zapisz
Drukuj
Udostępnij

Administratorem danych jest Benett PEOPLE Sp. z o.o. z siedzibą w Warszawie (02-…  rozwiń

Praca
Warszawa
IT - Administracja
Administrowanie systemami
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
QA Engineer Śpiesz się!
Polski Standard Płatności S.A.
Warszawa, Mokotów
.NET Developer Najlepiej dopasowana
Eurotronic Sp. z o.o.
Warszawa, Włochy
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
Programista (m/k)
PEKABEX
Warszawa, Śródmieście
Superoferta
Senior QA Automation Engineer – ETL / Data (k/m/n)
Nexio Management Sp. z o.o.
Warszawa
Superoferta
Backend Developer (Golang)
Wirtualna Polska Media S.A.
Warszawa, Włochy
Superoferta
Middle Java Developer
Integral Solutions
80–97 zł netto (+ VAT) / godz.
Warszawa
Pokaż więcej podobnych
16
Włącz powiadomienie

Junior Automation Consultant C# (k/m), Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916239

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Backend .NET Developer
TeamQuest Sp. z o.o.About the company

valid for 17 days

(to 17 Oct)

18 000 – 23 000 zł
net (+ VAT) / mth. | B2B contract
Company location:
WarszawaMasovian
Workplace:
Whole Poland (remote work)
b2b contract
full-time
specialist (mid / regular), senior specialist (senior)
home office work
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Additional information
Specializations:
Backend
Required languages:
English
Technologies we use
Expected
.NET
About the project
Our client develops IT solutions, mainly for prestigious clients in the financial and automotive sectors.
This is how we organize our work
This is how we work
at the client's site
Your responsibilities
Designing and implementing integrations with external systems (SOAP/XML and REST/JSON services), including data model mapping and partner error handling.
Maintaining and developing an asynchronous data exchange mechanism (message queues, callbacks, statuses, request idempotency).
Generating and updating API clients based on OpenAPI contracts provided by the client; responding to contract version changes.
Building and maintaining mocks of external systems for test environments.
Implementing business process logic in a BPMN engine (handlers in C#, process variables, signals) and decision rule models.
Configuring environments (installation parameters, Docker, CI/CD pipeline), participating in preparing releases and hotfixes.
Analyzing defects from business tests and production based on logs, quick fixes, collaborating with client analysts and testers.
Documenting solutions and transferring knowledge within the team.
Our requirements
Minimum 3-4 years of experience in a similar position.
Very good knowledge of C# and .NET (ASP.NET Core, .NET 8 or newer).
Practical experience with SOAP / XML integrations, REST/OpenAI integrations.
Asynchronous architecture - message queues (RabbitMQ or equivalent), request-callback pattern, idempotency, persistence of exchange state.
Good knowledge of databases.
Mapping of domain models.
Docker and CI/CD.
Git in gitflow model.
English language proficiency for reading technical documentation.
Communicative, open to collaboration with client-side personnel.
Ability to work independently.
Optional
Experience in the financial/banking industry or in projects for these industries.
What we offer
Attractive salary.
Possibility of fully remote work.
Real opportunity for professional development.
Possibility to genuinely influence the shape of projects.
Benefits
Sharing the costs of sports activities
Private medical care
Recruitment stages
1

Recruitment Interview

Aplikuj
Zapisz
Drukuj
Udostępnij

Klikając w przycisk „Aplikuj” lub w inny sposób wysyłając zgłoszenie rekrutacyjne, zgadzasz się na przetwarzanie Twoich danych osobowych przez TEAMQUEST sp. z o.o. z siedzibą w: Srebrna 16/308D, 00-810 Warszawa (Pracodawca), jako administratora danych osobowych w celu przeprowadzenia rekrutacji na stanowisko wskazane w ogłoszeniu.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
IT - Administracja
Administrowanie systemami
Aplikuj
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
.NET Software Developer Najlepiej dopasowana
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)
.NET Developer Hit!
Eurotronic Sp. z o.o.
Warszawa, Włochy
Superoferta
.Net Developer Śpiesz się!
OPTIVEUM SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
120 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Full Stack .NET Developer Śpiesz się!
Micro Solutions Sp. z o.o.
Wrocław, Fabryczna
Superoferta
Senior Odoo Developer Wyprzedź innych kandydatów
YOUR ITEAMS sp. z o.o.
150–220 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Full Stack Developer (.NET / Angular / SQL)
GOLDENORE ITC sp. z o.o.
Warszawa
Superoferta
Fullstack Developer (Python+React)
YOUR ITEAMS sp. z o.o.
140–170 zł netto (+ VAT) / godz.
Warszawa
Pokaż więcej podobnych
16
Włącz powiadomienie

Backend .NET Developer, Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

---

## Chrome tab 2063916240

Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
.NET Developer
Eurotronic Sp. z o.o.O firmie

ważna jeszcze 14 dni

(do 14 paź)

Jutrzenki 137A, Włochy, Warszawamazowieckie
umowa o pracę, kontrakt b2b
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca hybrydowa
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend, Frontend
Wymagane języki:
angielski
Siedziba firmy

Eurotronic Sp. z o.o.

Jutrzenki 137A, Włochy, Warszawa

Sprawdź czas dojazdu

Zlokalizuj się lub podaj dokładny adres

Samochód

-

Komunikacja

-

Rower

-

Pieszo

-

Technologie, których używamy
Wymagane
C#
SQL
T-SQL
.NET
System operacyjny
Tak organizujemy naszą pracę
Tak pracujemy
agile
Twój zakres obowiązków
Rozwój i utrzymywanie autorskiego oprogramowania Eurotronic z obszaru systemów EAM / CMMS.
Projektowanie, budowa i wdrożenia nowych modułów funkcjonalnych oprogramowania.
Utrzymywanie dokumentacji technicznej.
Nasze wymagania
Wymagamy co najmniej trzyletniego doświadczenia w roli programisty .NET (C#).
Praktycznej znajomości bazy danych MS SQL (T/SQL, optymalizacja zapytań).
Znajomość wzorców projektowych, dobrych praktyk programowania.
Chęci do nauki i poznawania nowych frameworków i narzędzi.
Umiejętności analitycznego myślenia.
Znajomości języka angielskiego na poziomie min. B1/B2.
Mile widziane
Znajomość Blazor, .NET MAUI.
Umiejętność integracji systemów z wykorzystaniem REST/JSON i SOAP/XML.
Znajomość zagadnień bezpieczeństwa aplikacji webowych.
Znajomość narzędzi i zagadnień CI/CD.
To oferujemy
Pracę w firmie o ugruntowanej pozycji rynkowej i dynamicznym rozwoju,
Pakiet benefitów (pakiet medyczny, pakiet sportowy),
Atrakcyjne wynagrodzenie,
Owocowe wtorki,
Pakiet szkoleń technicznych i biznesowych,
Zdefiniowaną ścieżkę rozwoju,
Umowa o pracę lub B2B.
Tak pracujemy nad projektem
Continuous Deployment
Continuous Integration
Benefity
Dofinansowanie zajęć sportowych
Prywatna opieka medyczna
Owoce
Spotkania integracyjne
Eurotronic Sp. z o.o.
Przewiń do profilu firmy
Eurotronic Sp. z o.o. (www.eurotronic.net.pl) od przeszło 25 lat wspiera przedsiębiorstwa w optymalizacji procesów związanych z zarządzaniem majątkiem oraz zwiększających efektywność energetyczną. Specjalizujemy się w projektowaniu, tworzeniu i wdrażaniu specjalistycznych rozwiązań z zakresu informatyki. Pomagamy udoskonalać obszary utrzymania ruchu i zarządzania zasobami technicznymi. Ponad 200 zrealizowanych z sukcesem wdrożeń systemów klasy CMMS i EAM oraz dedykowanych rozwiązań informatycznych, zarówno w średnich, dużych, jak i największych przedsiębiorstwach w Polsce i zagranicą pozwoliło nam uzyskać pozycję lidera na polskim rynku.
Aplikuj szybko
Zapisz
Drukuj
Udostępnij

Administratorem danych osobowych, które otrzymamy w związku z rekrutacją, jest Eurotronic Sp. z o.o. (Oxygen Park / 5p., ul. Jutrzenki 137 A, 02-231 Warszawa, email: sales@eurotronic.net.pl). Uprzejmie informujemy, że będziemy przetwarzać wskazane powyżej dane w celu przeprowadzenia procesu rekrutacji (oceny kwalifikacji kandydatów i ewentualnego dokonania wyboru osoby, której zaproponujemy współpracę), na podstawie naszego prawnie uzasadnionego interesu w sprawdzeniu kalifikacji kandydatów, a w pozostałym zakresie na podstawie zgody osób, których dane dotyczą. Dane będą przetwarzane do zakończenia rekrutacji lub do wycofania zgody. W przypadku wyrażenia zgody na przetwarzanie danych na potrzeby dalszych rekrutacji, dane będą przetwarzane dla potrzeb kolejnych rekrutacji przez rok od zakończenia obecnej rekrutacji lub do czasu cofnięcia zgody. Przekazane nam dane będą przez nas przetwarzane z pomocą firm hostingowych i dostawców poczty e-mail, z którymi współpracujemy (odbiorcy danych). Osoby, które przekażą nam dane, mają prawo dostępu do nich, a także ich sprostowania, usunięcia, ograniczenia przetwarzania lub przeniesienia do innego podmiotu. Osoby te mogą też w dowolnym momencie cofnąć zgodę na przetwarzanie danych, jednak bez wpływu na zgodność z prawem przetwarzania dokonanego na podstawie zgody przed jej cofnięciem. Mają też prawo skargi do Prezesa Urzędu Ochrony Danych Osobowych. Uprzejmie prosimy o dołączenie do aplikacji wyraźnej pisemnej zgody na przetwarzanie udostępnianych nam danych osobowych dla celów prowadzonej przez nas rekrutacji. Ponadto zachęcamy do wyrażenia dodatkowej zgody na przetwarzanie przez nas tych danych dla potrzeb kolejnych rekrutacji.

Praca
Warszawa
IT - Administracja
Administrowanie bazami danych i storage
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
Superoferta
.NET Software Developer Najlepiej dopasowana
NOVOMATIC Technologies Poland Sp. z o.o.
14 000–23 000 zł netto (+ VAT) / mies.
Zabierzów (pow. krakowski)
Programista .NET / Programistka .NET w Obszarze Rozwoju Systemów Korporacyjnych
Bank Millennium S.A.
Warszawa, Mokotów
Superoferta
Full Stack Developer (.NET / Angular / SQL)
GOLDENORE ITC sp. z o.o.
Warszawa
Software Developer (.NET) (k/m)
Logisystem Sp. z o.o.
Warszawa, Białołęka
Starszy programista .NET/C# (K/M) Hit!
NASK
10 000–16 000 zł brutto / mies.
Warszawa, Wola
Superoferta
Senior Backend Developer (.NET) (m/f)
Grupa Pracuj
110–125 zł netto (+ VAT) / godz.
Warszawa, Wola
Pokaż więcej podobnych
16
Włącz powiadomienie

.NET Developer, Jutrzenki 137A, Włochy, Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.
