# Surowe zrzuty z kart Chrome

Zrzuty z kart Chrome. Metoda pozyskania jest opisana osobno przy każdym wpisie; nie zakłada się ręcznego Ctrl+A/Ctrl+C bez potwierdzenia.

## Tab 2063916165

<browser__document__url>https://www.pracuj.pl/praca/programista-programistka-czestochowa,oferta,1005077598?sug=oferta_bottom_bd_7</browser__document__url>
<browser__document__title>Oferta pracy Programista / Programistka, VentiAir Innvations sp. z o.o., Częstochowa</browser__document__title>

<browser__document__content>
<user__selection>
Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie

ważna jeszcze 8 dni

(do 08 paź)

Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
Prywatna opieka medyczna
Elastyczny czas pracy
Brak dress code’u
Kawa / herbata
Parking dla pracowników
VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań
Superoferta
.Net Developer
EUVIC S.A.
Katowice
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy
Pokaż więcej podobnych
15
Włącz powiadomienie

Programista / Programistka, Częstochowa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

</user__selection>
</browser__document__content>

---

## Tab 2063916166

<browser__document__url>https://www.pracuj.pl/praca/senior-java-microservices-developer-banking-technology-warszawa,oferta,1005124568?sug=list_top_cr_bd_1_boosterAI_L0&s=1f7c2c91&searchId=MTc5MDc2NDE0OTAyMS4zOTM4</browser__document__url>
<browser__document__title>Oferta pracy Senior Java Microservices Developer – Banking Technology, ITDS Polska Sp. z o.o., Warszawa</browser__document__title>

<browser__document__content>
<user__selection>
Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
New
Senior Java Microservices Developer – Banking Technology
ITDS Polska Sp. z o.o.About the company

valid for a month

(to 29 Oct)

18 900 – 23 100 zł
net (+ VAT) / mth. | B2B contract
Company location:
WarszawaMasovian
Workplace:
Whole Poland (remote work)
b2b contract
full-time
senior specialist (senior)
home office work
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Additional information
Specializations:
Backend
Required languages:
English, Polish
Technologies we use
Expected
Java
REST APIs
microservices
RabbitMQ
Git
Maven
Jenkins
OpenShift
Agile
CI/CD
Optional
Domain-Driven Design (DDD)
AI tools
cloud technologies
About the project
As a Senior Java Developer / Technical Lead, you will be working for our client, a leader in the financial services industry dedicated to transforming credit processes for corporate clients. You will play a pivotal role in building and enhancing a critical application that supports decision-making across banking, leasing, and factoring services, leveraging modern microservices architecture to deliver innovative solutions with a significant impact on millions of financial transactions. Join us to push the boundaries of banking technology and accelerate your career growth.
Your responsibilities
Lead the design and development of scalable, event-driven microservices within the CLP credit workflow application.
Collaborate with cross-functional teams in an Agile environment to ensure the high-quality delivery of system features.
Define, implement, and enforce standards for code quality, testing, and code reviews.
Mentor and guide less experienced developers, fostering technical excellence within the team.
Implement and optimize CI/CD pipelines using tools such as Git, Maven, Jenkins, and OpenShift.
Develop and maintain integrations with external systems via REST APIs and asynchronous messaging with RabbitMQ.
Leverage domain-driven design (DDD) principles and incorporate AI tools for SDLC efficiency.
Ensure the system’s architecture adheres to best practices in security, performance, and scalability.
Our requirements
Minimum of 5 years’ experience in back-end development, especially in Java.
Deep expertise in RESTful API design and implementation.
Practical knowledge of distributed system architecture and microservices design.
Hands-on experience with messaging systems, particularly RabbitMQ.
Proficiency with DevOps tools: Git, Maven, Jenkins, and OpenShift.
Strong analytical skills with the ability to solve complex technical problems.
Experience working in Agile and CI/CD environments.
Optional
Knowledge of Domain-Driven Design (DDD).
Experience with AI tools integration into SDLC processes.
Certifications in cloud or related technologies.
What we offer
Stable and long-term cooperation with very good conditions
Enhance your skills and develop your expertise in the financial industry
Work on the most strategic projects available in the market
Define your career roadmap and develop yourself in the best and fastest possible way by delivering strategic projects for different clients of ITDS over several years
Participate in Social Events, training, and work in an international environment
Access to attractive Medical Package
Access to Multisport Program
Access to Pluralsight
Flexible hours
Benefits
Sharing the costs of sports activities
Private medical care
Flexible working time
Fruits
Integration events
Corporate gym
Saving & investment scheme
No dress code
Coffee / tea
Drinks
Christmas gifts
Birthday celebration
Sharing the costs of a streaming platform subscription
Access to +100 projects
Access to Pluralsight
Recruitment stages
1

first online interview

2

second online interview

#MAKEYourCareerBETTER
Interested? Apply now and include your CV (preferably in English) along with a statement confirming your consent to the processing and storage of your personal data.
ITDS Polska Sp. z o.o.
Scroll to company's profile
ITDS supports financial service providers to take the next steps.
We identify what’s possible, every day. Opportunities in the areas of technology, organization, and digitization.
We see where banks, insurers, payment companies, or fintech can go and how they can get there.
That’s why we want to stimulate you to ramp up your ambition. Forget what you perceive as restraints and step towards the new reality.
ITDS in Poland - Pure player in new Technologies & Financial Industry
+300 IT implementation professionals
+20 clients in the Banking, Insurance, Payment & Fintech Industry
ITDS excels in digital strategy delivery and implementation of best-of-breed lending solutions. ITDS has delivered successful strategic projects throughout Europe since 1998. We combine the experience we’ve accumulated with in-depth knowledge of technologies, business processes, and EU legislation to unlock new business opportunities.
This is how we work
10185
Aplikuj
Zapisz
Drukuj
Udostępnij

Informujemy, że administratorem danych jest ITDS z siedzibą w Warszawie, ul. Złota 59 (dalej jako "administrator"). Masz prawo do żądania dostępu do swoich danych osobowych, ich sprostowania, usunięcia lub ograniczenia przetwarzania, prawo do wniesienia sprzeciwu wobec przetwarzania, a także prawo do przenoszenia danych oraz wniesienia skargi do organu nadzorczego. Dane osobowe przetwarzane będą w celu realizacji procesu rekrutacji. Podanie danych w zakresie wynikającym z ustawy z dnia 26 czerwca 1974 r. Kodeks pracy jest obowiązkowe. W pozostałym zakresie podanie danych jest dobrowolne. Odmowa podania danych obowiązkowych może skutkować brakiem możliwości przeprowadzenia procesu rekrutacji. Administrator przetwarza dane obowiązkowe na podstawie ciążącego na nim obowiązku prawnego, zaś w zakresie danych dodatkowych podstawą przetwarzania jest zgoda. Dane osobowe będą przetwarzane do czasu zakończenia postępowania rekrutacyjnego i przez okres możliwości dochodzenia ewentualnych roszczeń, a w przypadku wyrażenia zgody na udział w przyszłych postępowaniach rekrutacyjnych - do czasu wycofania tej zgody. Zgoda na przetwarzanie danych osobowych może zostać wycofana w dowolnym momencie. Odbiorcą danych jest serwis Hello HR oraz inne podmioty, którym powierzyliśmy przetwarzanie danych w związku z rekrutacją.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
IT - Administracja
Administrowanie bazami danych i storage
Aplikuj
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
Senior Java Developer – AI Integration and Microservices
ITDS Polska Sp. z o.o.
21 000–22 785 zł / mies. (zal. od umowy)
Warszawa
Superoferta
Calypso Developer Tu zarobisz najwięcej!
VISTULO sp. z o.o.
220–250 zł netto (+ VAT) / godz.
Warszawa
Software Engineer Senior Najlepiej dopasowana
FIS Technology Services Poland Sp. z o.o.
13 800–19 500 zł brutto / mies.
Warszawa, Wola
Full-stack Developer (Java, Angular)
Capgemini Polska
Warszawa, Włochy
Superoferta
Senior Java Software Engineer
Sportradar Polska Sp. z o.o.
Warszawa, Wola
Superoferta
Fullstack Mobile Developer (Kotlin) (m/k)
Integral Solutions
Warszawa
Superoferta
Ekspert Programista (Java / Spring Boot) - K/M Wyprzedź innych kandydatów
B2B.NET S.A.
110–130 zł netto (+ VAT) / godz.
Warszawa
Pokaż więcej podobnych
16
Włącz powiadomienie

Senior Java Microservices Developer – Banking Technology, Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

</user__selection>
</browser__document__content>

---

## Tab 2063916167

<browser__document__url>https://www.pracuj.pl/praca/magazynier-magazynierka-warszawa,oferta,1005062473?sug=oferta_bottom_bd_2</browser__document__url>
<browser__document__title>Oferta pracy Magazynier / Magazynierka, UniGast S.A., Warszawa</browser__document__title>

<browser__document__content>
<user__selection>
Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Magazynier / Magazynierka
UniGast S.A.O firmie

ważna jeszcze dzień

(do 01 paź)

Warszawamazowieckie
umowa o pracę, umowa zlecenie, umowa o pracę tymczasową
pełny etat, część etatu, dodatkowa / tymczasowa
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
praca od zaraz
pracodawca nie wymaga cv
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Tryb wypłaty:
miesięczna
Twój zakres obowiązków
Zatrudniona osoba będzie wykonywała pracę w charakterze magazyniera i będzie odpowiedzialna za:
Kompletowanie zamówień do klientów
Przyjmowanie dostaw do magazynu
Utrzymanie porządku w magazynie
Nasze wymagania
Umiejętność pracy w zespole
Punktualność, dyspozycyjność, uczciwość, samodzielność
Mile widziane
Uprawnienia na wózki widłowe
To oferujemy
Stabilne warunki zatrudnienia w dużej polskiej firmie
Terminowe wypłaty wynagrodzenia
Pracę w młodym i zgranym zespole
Motywacyjny system wynagrodzenia
Benefity
Ubezpieczenie na życie
Aplikuj szybko
Zapisz
Drukuj
Udostępnij

„Wyrażam zgodę na przetwarzanie danych osobowych zawartych w mojej ofercie pracy dla potrzeb niezbędnych do realizacji procesu rekrutacji prowadzonego przez UniGast S.A.. z siedzibą w Warszawie zgodnie z ustawą z dnia 29 sierpnia 1997 r. o ochronie danych osobowych (tj. Dz. U. z 2014 r. poz. 1182, 1662)”.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
Praca fizyczna
Kurierzy / Dostawcy
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
Magazynier/ka Śpiesz się!
Steriscience Sp. z o.o.
Warszawa
Superoferta
Magazynier (k/m) Hit!
Mennica Polska S.A.
6 500 zł brutto / mies.
Warszawa, Białołęka
Magazynier / Magazynierka Najlepiej dopasowana
HEBAR SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
Warszawa
Magazynier - kompletacja (k/m)
BAG-POL ADAM GOŹDZICKI, BARBARA GOŹDZICKA SPÓŁKA KOMANDYTOWA
5 500–8 300 zł brutto / mies.
Warszawa, Włochy
Superoferta
Magazynier (K/M)
Franke Polska Sp. z o.o.
Sękocin Nowy (pow. pruszkowski)
Superoferta
Magazynier / Magazynierka
Job Impulse Polska Sp. z o.o.
od 37 zł brutto / godz.
Warszawa
Magazynier
MANTA S.A.
Warszawa, Targówek
Pokaż więcej podobnych
16
Włącz powiadomienie

Magazynier / Magazynierka, Warszawa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

</user__selection>
</browser__document__content>

---

## Tab 2063916168

<browser__document__url>https://www.pracuj.pl/praca/kucharz-sniadaniowy-kucharka-sniadaniowa-warszawa-zwyciezcow-49,oferta,1005073905?sug=list_top_cr_bd_12&s=1f7c2c91&searchId=MTc5MDc2NDE0OTAyMS4zOTM4</browser__document__url>
<browser__document__title>Oferta pracy Kucharz śniadaniowy / Kucharka śniadaniowa, SUKCES sp. z o.o., Warszawa</browser__document__title>

<browser__document__content>
<user__selection>
Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Kucharz śniadaniowy / Kucharka śniadaniowa
SUKCES sp. z o.o.O firmie

ważna jeszcze 5 dni

(do 05 paź)

40,00 – 50,00 zł
brutto / godz. | umowa zlecenie
Zwycięzców 49, Praga-Południe, Warszawamazowieckie
umowa zlecenie
pełny etat
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
praca od zaraz
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Praca zmianowa:
tak
Godziny pracy:
7:00-15:00
Możliwa praca w godzinach nocnych:
nie
Tryb wypłaty:
miesięczna
System wynagrodzeń:
stała podstawa wynagrodzenia + premia za wyniki
Więcej szczegółów
Siedziba firmy

SUKCES sp. z o.o.

Zwycięzców 49, Praga-Południe, Warszawa

Sprawdź czas dojazdu

Zlokalizuj się lub podaj dokładny adres

Samochód

-

Komunikacja

-

Rower

-

Pieszo

-

Twój zakres obowiązków
Zakres obowiązków:
• samodzielne przygotowywanie śniadań i dań z karty zgodnie z recepturami i standardami lokalu
• przygotowywanie produktów do serwisu – mise en place
• dbanie o estetykę i powtarzalność wydawanych dań
• organizacja pracy kuchni podczas serwisu
• przygotowywanie śniadan, sosów, dodatków i innych elementów menu
• kontrolowanie jakości i świeżości produktów
• dbanie o prawidłowe przechowywanie żywności i przestrzeganie zasad HACCP
• kontrolowanie stanów magazynowych i zgłaszanie zapotrzebowania na produkty
• utrzymywanie porządku i czystości na stanowisku pracy oraz w kuchni
• racjonalne gospodarowanie produktami i ograniczanie strat
• współpraca z zespołem sali oraz pozostałymi pracownikami lokalu
• dbanie o sprzęt kuchenny i prawidłowe korzystanie z urządzeń
• udział w tworzeniu i rozwijaniu oferty śniadaniowej
Nasze wymagania
• doświadczenie przy kuchni śniadaniowej
• samodzielność i dobra organizacja pracy
• umiejętność sprawnego przygotowywania dań podczas intensywnego serwisu
• znajomość podstawowych technik kulinarnych
• dbałość o smak, jakość i estetykę wydawanych dań
• umiejętność pracy według receptur i standardów lokalu
• znajomość zasad higieny i bezpieczeństwa żywności
• odpowiedzialność za powierzone stanowisko i produkty
• punktualność, zaangażowanie i pozytywne nastawienie do pracy
• umiejętność pracy w zespole
• aktualna książeczka sanepidowska / orzeczenie do celów sanitarno-epidemiologicznych lub gotowość do jej wyrobienia
• dyspozycyjność do pracy w systemie 2/2 po 8 h
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Praca
Warszawa
Hotelarstwo / Gastronomia / Turystyka
Katering / Restauracje / Gastronomia
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Kucharz / Kucharka Tu zarobisz najwięcej!
MOTTO sp. z o.o.
7 000–10 000 zł brutto / mies.
Warszawa, Śródmieście
Kucharz / Kucharka Hit!
RESTRO sp. z o.o.
42–46 zł / godz. (zal. od umowy)
Warszawa, Wola
Superoferta
Kucharz/ Kucharka (śniadania) Śpiesz się!
Royal Tulip Warsaw Centre
Warszawa, Wola
Kucharz śniadaniowy - kuchnia zimna
VARSOWICZ sp. z o.o.
31,50–35 zł brutto / godz.
Warszawa, Śródmieście
Superoferta
Kucharz do grupy sen Najlepiej dopasowana
SEN WARSAW
Warszawa
Kucharz / Kucharka (kuchnia gorąca)
2F2 sp. z o.o.
31,40–40 zł / godz. (zal. od umowy)
Warszawa, Wola
Kucharz / Kucharka Wyprzedź innych kandydatów
PRZEDSIĘBIORSTWO HANDLOWE AMD S.C.
od 45 zł brutto / godz.
Wołomin
Pokaż więcej podobnych
16
Włącz powiadomienie

Kucharz śniadaniowy / Kucharka śniadaniowa, Zwycięzców 49, Praga-Południe, Warszawa

Chcesz dowiedzieć się więcej o firmie?

Zobacz pełny profil firmy

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

</user__selection>
</browser__document__content>

---

## Tab 2063916156

<browser__document__url>https://www.olx.pl/oferta/praca/amazon-38-52-zl-godz-brutto-2200-brutto-CID4-ID1ceE1l.html?search_reason=search%7Corganic</browser__document__url>
<browser__document__title>Amazon | 38,52 zł/godz. brutto* | +2200 brutto** Trzebnica • OLX.pl</browser__document__title>

<browser__document__content>
<user__selection>Przejdź do głównej części
Przejdź do stopki
Czat
Powiadomienia

Twoje konto

Dodaj ogłoszenie
Dla biznesu
opens in a new tab
Strona głównaPracaPrace magazynowePrace magazynowe - DolnośląskiePrace magazynowe - Trzebnica
Dodane dzisiaj o 12:11
Amazon | 38,52 zł/godz. brutto* | +2200 brutto**
Randstad Polska Sp. z o.o. Dowiedz się więcej

LOKALIZACJA

Trzebnica

WYMIAR PRACY

Pełny etat

TYP UMOWY

Umowa o pracę

Doświadczenie nie jest wymagane
Dyspozycyjność: Praca zmianowa
Miejsce pracy: W siedzibie firmy
Rekrutacja online
🇺🇦 Автоматичний переклад українською
LOKALIZACJA

Trzebnica

OPIS

Poszukujemy pracowników na stanowisko pracownika magazynu w Bielanach Wrocławskich k. Wrocławia.

 

Centrum Logistyki Amazon, podwyższa stawkę! Pracuj i zyskaj więcej, bo to Twoja zmiana i Twoja nowa, wyższa stawka godzinowa 38,52 zł/godz. brutto*     

Oprócz tego możesz liczyć na +2200 zł brutto** ekstra. Poleć znajomych do pracy, Ty i osoba polecona zyskacie wspólnie do 5000 zł brutto***!

 

Nie wymagamy od Ciebie doświadczenia. Możesz liczyć na  wsparcie wyspecjalizowanych instruktorów.

zadania

rozkładanie towarów na półki magazynu
załadunek i rozładunek przesyłek
kompletowanie, pakowanie i przygotowywanie towaru do wysyłki
obsługa skanera ręcznego

oczekujemy

gotowości i zdolności do pracy w trybie zmianowym - na zmianie dziennej i nocnej
braku przeciwwskazań do stania/chodzenia przez 10 godzin
sumienności i skrupulatności w wykonywaniu obowiązków

oferujemy

stawkę do 38,52 zł/godz. brutto*
+2200 brutto** ekstra
bonus za polecenie - poleć do pracy swojego znajomego i otrzymajcie razem bonus w wysokości do 5000 zł**
dodatek za pracę w godzinach nocnych
praca 4 dni w tygodniu, 3 dni wolnego (praca w pełnym wymiarze godzin)
umowę o pracę tymczasową (ze składką ZUS i płatnymi urlopami)
pakiet RANDSTAD PLUS, a w nim takie atrakcje, jak: karta sportowa Medicover Sport, pakiet medyczny Medicover oraz rabaty do 50% w wybranych sklepach
długą, stabilną, rozwijającą współpracę
gorące napoje i obiady z pysznym i różnorodnym menu za złotówkę
bezpłatny dojazd autobusem pracowniczym na wybranych trasach

Zaaplikuj lub zadzwoń na nr 22 454 44 44 lub +488*****777 (numer bezpłatny)

*Suma podstawowej stawki godzinowej oraz premii specjalnej za frekwencję.

**Szczegóły podczas rekrutacji.

***zgodnie z regulaminem dostępnym na stanowisku Randstad.

 

Agencja zatrudnienia – nr wpisu 47

ta oferta pracy przeznaczona jest dla osób powyżej 18 roku życia

 

 

 

Aplikuj teraz
opens in a new tab
ID: 1096939299
Zgłoś
O FIRMIE
Randstad Polska Sp. z o.o.
Partner for talent.
Branża
Zasoby Ludzkie i Rekrutacja
Wielkość firmy
751-1000
Lokalizacja
Warszawa

Randstad Polska jest częścią Randstad N.V. – najbardziej wyspecjalizowanej firmy na świecie działającej na rzecz talentów, która dba o wyrównywanie szans.

Działając w ramach czterech specjalizacji – Operational, Professional, Digital i Enterprise – zapewniamy firmom wykwalifikowane, zróżnicowane i elastyczne zespoły, które wspierają ich w osiąganiu biznesowych sukcesów w świecie deficytu talentów. Poszukujących zatrudnienia wspieramy w zdobywaniu ważnych dla nich ról zawodowych, rozwoju właściwych kompetencji, odnajdywaniu celu i poczucia przynależności w miejscu pracy.

W Randstad pomożemy Ci znaleźć pracę, która odpowiada Twoim kwalifikacjom, wspiera równowagę między życiem zawodowym a prywatnym i Twoje cele. Współpracujemy z najlepszymi pracodawcami na rynku, zapewniając szerszy dostęp do całej gamy różnorodnych możliwości, które w większym stopniu wspierają Twoje ambicje zawodowe - bez względu na to, czy poszukujesz zatrudnienia stałego, tymczasowego czy kontraktowego. Nie tylko pomożemy znaleźć Ci pracę; pomagamy też rozwijać Twoje umiejętności i wiedzę. Dzięki inicjatywom wspierającym rozwój, wsparciu online, indywidualnemu coachingowi i centrach talentów na całym świecie, zapewniamy narzędzia i zasoby umożliwiające rozwój umiejętności i utrzymanie pozycji na konkurencyjnym rynku pracy.

Naszym priorytetem jest pozostawanie z Tobą w relacji na każdym etapie Twojego życia zawodowego. Współpracując z Randstad, zyskujesz partnera, który dba o Twoje dobre samopoczucie, zapewnia indywidualne podejście i nieustannie wspiera Cię w podążaniu satysfakcjonującą ścieżką kariery.

Pokaż więcej
Zobacz profil pracodawcy

REKRUTER

Randstad Polska Sp. z o.o.

Na OLX od wrzesień 2017

Ostatnio online w dniu 28 września 2026

Zadzwoń / SMS
Aplikuj teraz
opens in a new tab
Zobacz profil pracodawcy
Więcej od tego ogłoszeniodawcy
Zobacz wszystkie
magazynier z UDT lub kat.B (k/m) > Radom > zarób do 7500zł brutto! > 13 pensja > super bonusy!

Randstad Polska Sp. z o.o.

Radom

Pełny etat

Umowa o pracę

Dzisiaj o 12:34

praca na produkcji> Od zaraz> zatrudnienie bezpośrednie po okresie próbnym> 5510 zł brutto> dojazd pod sama bramę

Randstad Polska Sp. z o.o.

Kraków, Nowa Huta

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:32

Amazon | 38,52 zł/godz. brutto* | +2200 brutto**

Randstad Polska Sp. z o.o.

Trzebnica

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:23

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Trzebnica

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:23

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Głuchołazy

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Brzeg

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Strzegom

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Oborniki Śląskie

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Oleśnica, Oleśnica

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Kamiennik

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Bożnowice

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Dzierżoniów

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Wrocław, Stare Miasto

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:22

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Oleśnica, Oleśnica

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11

Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса

Randstad Polska Sp. z o.o.

Bożnowice

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11

pracownik produkcji ( k / m) | od zaraz | zorganizowany transport z Lubawki oraz Kamiennej Góry !

Randstad Polska Sp. z o.o.

Kamienna Góra

Pełny etat

Umowa o pracę

Odświeżono dzisiaj o 12:11

Zobacz też
Zlecenie związane z wykładaniem towaru w Trzebnicy

Instore Solution Services Polska UA Sp. z o.o.

32 - 32,50 zł / godz. brutto

Trzebnica

Niepełny etat

Umowa zlecenie

Doświadczenie nie jest wymagane

Odświeżono dnia 28 września 2026

Amazon | 38,52 zł/godz. brutto* | +2200 brutto**

Randstad Polska Sp. z o.o.

Trzebnica

Pełny etat

Umowa o pracę

Doświadczenie nie jest wymagane
Dyspozycyjność: Praca zmianowa
Miejsce pracy: W siedzibie firmy
Rekrutacja online

Odświeżono dzisiaj o 12:23

Magazynier z doświadczeniem SKLEPCARAUDIO PL

SKLEPCARAUDIO PL

Wrocław, Krzyki

Pełny etat

Umowa o pracę, Samozatrudnienie, Umowa zlecenie

Odpowiednie doświadczenie zawodowe
Wymagane CV: Wymagane
Miejsce pracy: W siedzibie firmy

29 września 2026

Pracownik sklepu Żabka

GOWER

Trzebnica

Pełny etat

Umowa zlecenie

Specjalne wymagania: Książeczka sanepidowska
Doświadczenie nie jest wymagane
Wymagane CV: Opcjonalne
Dyspozycyjność: Praca zmianowa, Praca w weekendy

Odświeżono dnia 24 września 2026

Praca Specjalista / Specjalistka Obsługi Klienta Stacja Paliw bp Wisznia Mała

bp Polska Services sp. z. o.o.

5 650 - 5 800 zł / mies. brutto

Trzebnica

Pełny etat

Umowa o pracę

Doświadczenie nie jest wymagane
Dyspozycyjność: Elastyczny czas pracy, Praca zmianowa, Praca w weekendy

24 września 2026

Magazynier do hurtowni w Krzykach

Lun Fix Sp. z o.o.

31,40 - 36 zł / godz. brutto

Wrocław, Krzyki

Pełny etat

Umowa zlecenie

Doświadczenie nie jest wymagane
Miejsce pracy: W siedzibie firmy
Pracownicy z Ukrainy: 🇺🇦 Запрошуємо людей з України (Zapraszamy pracowników z Ukrainy)

29 września 2026

Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies

Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl</user__selection>
</browser__document__content>

---

## Tab 2063916155

<browser__document__url>https://www.olx.pl/oferta/praca/doradca-klienta-salon-sprzedazy-drzwi-i-podlog-CID4-ID19JzoE.html?search_reason=search%7Cpromoted</browser__document__url>
<browser__document__title>DORADCA KLIENTA - Salon sprzedaży drzwi i podłóg Oświęcim • OLX.pl</browser__document__title>

<browser__document__content>
<user__selection>Przejdź do głównej części
Przejdź do stopki
Czat
Powiadomienia

Twoje konto

Dodaj ogłoszenie
Dla biznesu
opens in a new tab
Strona głównaPracaSprzedażDoradca klienta, sprzedawcaDoradca klienta, sprzedawca - MałopolskieDoradca klienta, sprzedawca - Oświęcim
Dodane 24 września 2026
DORADCA KLIENTA - Salon sprzedaży drzwi i podłóg

WYNAGRODZENIE

5 000 - 10 000 zł / mies. brutto

LOKALIZACJA

Oświęcim

WYMIAR PRACY

Pełny etat

TYP UMOWY

Umowa o pracę

Odpowiednie doświadczenie zawodowe
System wynagrodzeń: Podstawa + prowizja
Samochód służbowy: Nie
Miejsce pracy: W siedzibie firmy
🇺🇦 Автоматичний переклад українською
LOKALIZACJA

Oświęcim

OPIS

Jesteśmy salonem sprzedaży drzwi i podłóg działającym głównie na lokalnym rynku. Poszukujemy do naszego zespołu osoby ambitnej i kreatywnej, która jest gotowa związać się z nami na dłuższy okres czasu, niewykluczone na stałe.

Co oferujemy naszym pracownikom :

Zatrudnienie w oparciu o umowę o pracę (pierwsze 3 miesiące umowa zlecenie)

Stabilny system wynagradzania: płacę podstawową + premię uzależnioną od osiąganych wyników sprzedażowych,

Program szkoleń produktowych i sprzedażowych, stacjonarnych jak i wyjazdowych,które ułatwią wdrożenie się na nowym stanowisku,

Pracę w zespole fachowców i specjalistów, którzy służą pomocą w każdej sytuacji i postarają się przekazać jak największą porcję wiedzy nowemu pracownikowi,

Elastyczny grafik pracy i w miarę naszych możliwości dopasowany do potrzeb pracownika

Czego oczekujemy od naszych pracowników :

Umiejętności komunikacyjnych i interpersonalnych - najważniejsza cecha każdego handlowca

Komputer nie może być Ci obcy, pracujemy na licznych systemach zamówień oraz wykonujemy dziennie szereg wycen

Odporności na stres, bo jak wiadomo życie handlowca do łatwych nie należy i czasami trzeba zaparzyć kubek melisy ;)

Znajomość asortymentu z branży drzwi i podłogi jest warunkiem koniecznym.

Wymagamy min. rocznego doświadczenia na podobnym stanowisku.

Czym będziesz się zajmował :

Obsługa klientów w specjalistycznym salonie wykończenia wnętrz,

Doradztwo techniczne w temacie dostępnego w salonie asortymentu,

Prowadzenie dokumentacji sprzedażowej - sporządzanie umów z klientami, wystawianie faktur,

Dbanie o porządek w miejscu pracy oraz o estetykę i czystość ekspozycji

Bardzo prosimy o kontakt mailowy - zostaw nam swoje CV. Odezwiemy się do wybranych kandydatów i zaprosimy na rozmowę.

Aplikuj
ID: 1059980684
Zgłoś

Masz pytanie do pracodawcy odnośnie tej oferty?

Zadaj pytanie

REKRUTER

Justyna

Na OLX od styczeń 2018

Ostatnio online w dniu 24 września 2026

Zadzwoń / SMS
Aplikuj
Zobacz też
Kasjer-Sprzedawca (m/k) - Oświęcim

Agata S.A.

Oświęcim

Pełny etat

Umowa o pracę

Odpowiednie doświadczenie zawodowe
Dyspozycyjność: Praca zmianowa, Praca w weekendy
Miejsce pracy: W siedzibie firmy

25 września 2026

Praca na produkcji Jedna Zmiana 7-15

5 800 - 8 000 zł / mies. brutto

Oświęcim

Pełny etat

Umowa o pracę

Doświadczenie nie jest wymagane
Wymagane CV: Wymagane
Dyspozycyjność: Praca zmianowa
Miejsce pracy: W siedzibie firmy
+ 3 inne

26 września 2026

Praca w firmie ogrodniczej

Brzeszcze

Pełny etat

Umowa o pracę, Umowa zlecenie

Doświadczenie nie jest wymagane

Odświeżono dnia 28 września 2026

Specjalista ds. Obsługi Klienta / Back Office – Oświęcim

5 600 - 7 300 zł / mies. brutto

Oświęcim

Pełny etat

Umowa o dzieło, Inny, Umowa o pracę, Samozatrudnienie, Umowa zlecenie

Doświadczenie nie jest wymagane
Wymagane CV: Wymagane
Dyspozycyjność: Elastyczny czas pracy

Odświeżono dzisiaj o 08:32

Specjalista/Specjalistka ds. obsługi klienta

Honesta Market Service

4 900 - 5 500 zł / mies. brutto

Oświęcim

Pełny etat

Umowa o pracę

Odpowiednie doświadczenie zawodowe
Miejsce pracy: W siedzibie firmy

Odświeżono dnia 23 września 2026

Placek i Skórka - KUCHARZ/PIZZER

35 - 60 zł / godz. brutto

Brzeszcze

Pełny etat

Umowa o pracę, Umowa zlecenie

Specjalne wymagania: Książeczka sanepidowska
Odpowiednie doświadczenie zawodowe
Dyspozycyjność: Elastyczny czas pracy
Miejsce pracy: W siedzibie firmy

Odświeżono dnia 28 września 2026

Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies

Darmowa aplikacja na Twój telefon

OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl</user__selection>
</browser__document__content>

---

## Tab 2063916164

<browser__document__url>https://nofluffjobs.com/pl/job/analityk-systemowy-k-m-finture-warszawa-1</browser__document__url>
<browser__document__title>Praca Analityk Systemowy (k/m) | Business Analysis | Finture Sp. z o.o | Warszawa | No Fluff Jobs.</browser__document__title>

<browser__document__content>
__CODEX_USER_SELECTION_START_1790766180506-77VFADTT2MO__OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
1
Powrót do wyszukiwania
Business Analysis
Warszawa
Analityk Systemowy (k/m)
Analityk Systemowy (k/m)
Finture Sp. z o.o
Kategoria:
Business Analysis
Mid
Hybrydowo
+2

Lokalizacje:

Warszawa
 , ul. Skierniewicka 10A 
Lublin
 40% stacjonarnie, 60% zdalnie 
  
Oferta ważna do: 16.10.2026 (zostało 16 dni)
Obowiązkowe
Analiza systemowa
Analityka
Sektor Bankowy
AS-IS
Logi aplikacyjne
Komunikatywność
Polski (C1)
Opis wymagań
minimum 3 lata doświadczenia w roli analityka
minimum 2 lata doświadczenia analitycznego zdobytego w projektach rozwojowych w sektorze bankowym
umiejętność zbierania i analizy wymagań biznesowych oraz technicznych, zarówno funkcjonalnych, jak i pozafunkcjonalnych
doświadczenie w analizie procesów AS-IS oraz analizie systemowej wprowadzanych zmian
praktyka w samodzielnym tworzeniu dokumentacji technicznej
umiejętność czytania i analizowania logów aplikacyjnych
swobodna komunikacja z interesariuszami po stronie biznesu i IT
samodzielność w organizacji własnej pracy i odpowiedzialność za rezultat
Znajomość języka polskiego na poziomie C1
Zakres obowiązków
projektowanie architektury logicznej oraz komponentów systemowych, z uwzględnieniem wymagań pozafunkcjonalnych
analiza wymagań biznesowych i przełożenie ich na analizę systemową umożliwiającą rozwój zmian w aplikacji
badanie i opisywanie istniejących rozwiązań w modelu AS-IS
projektowanie i opisywanie integracji między systemami oraz standardów wymiany danych
tworzenie specyfikacji rozwiązań, modeli logicznych oraz dokumentacji technicznej i eksploatacyjnej
przygotowywanie konfiguracji aplikacji oraz bieżąca współpraca z administratorami aplikacji
pokaż wszystko (8)
Opis oferty

Dla naszego Klienta z branży bankowej poszukujemy Analityka Systemowego / Analityczki Systemowej do zespołu rozwijającego aplikację bankowości elektronicznej.
Zatrudnienie ramach grupy kapitałowej – przez spółkę Exorigo-Upos.

Praca hybrydowa w wymiarze 2 dni w tygodniu z biura w Warszawie lub Lublinie.

Oferujemy:

Pracę w renomowanej organizacji (ITwiz BEST100), działającej w oparciu o międzynarodowe standardy jakości i bezpieczeństwa (ISO 9001, ISO 27001)
Niekorporacyjną atmosferę i płaską strukturę organizacyjną
Możliwość ciągłego rozwoju poprzez:
pracę z wykorzystaniem różnorodnych technologii w projektach dla renomowanych klientów
współpracę z doświadczonym zespołem ekspertów, którzy chętnie dzielą się wiedzą
dofinansowanie do szkoleń i certyfikatów
Program Poleceń Pracowniczych
Kulturę organizacyjną opartą na wartościach:
działamy z dobrą intencją
dzielimy się wiedzą
bierzemy odpowiedzialność
stale się doskonalimy
ludzie są dla nas najważniejsi
działamy, znając cel i sens naszej pracy
komunikujemy się szczerze i profesjonalnie
Udział w inicjatywach dobroczynnych, w tym współpracę z Fundacja im. Joanny Radziwiłł "Opiekuńcze Skrzydła" oraz udział w świątecznej akcji „Gwiazdorzymy”
Różnorodne i inkluzywne środowisko pracy – w naszej firmie współpracują przedstawiciele czterech pokoleń
Równe szanse rozwoju – 50% stanowisk menedżerskich i liderskich zajmują kobiety
Szczegóły oferty
Rekrutacja online
  
Start ASAP
  
Praca zdalna przez 3 dni w tygodniu
  
Kroki w procesie rekrutacyjnym
selekcja CV
rozmowa rekrutacyjna
oferta
Benefity
Pakiet sportowy
Budżet na szkolenia
Prywatna opieka medyczna
Integration events
English lessons
Płaska struktura
O firmie Finture 

Utworzona w:
2016

Wielkość firmy:
+120

Siedziba:
01 -230 Warszawa

FINTURE to dynamiczny i ambitny zespół tworzący rozwiązania informatyczne, odpowiadające aktualnym trendom rynkowym – głównie w sektorze finansowym i ubezpieczeniowym.

BAZUJEMY na szerokim wachlarzu technologii i narzędzi, aby docelowe rozwiązania optymalnie komponowały się ze środowiskiem informatycznym naszych klientów. 

 

DBAMY o właściwą komunikację projektową, która według nas stanowi fundament w osiąganiu zamierzonych celów biznesowych.

 

WSPIERAMY naszych klientów na każdym etapie projektowym, począwszy od koncepcji rozwiązania, doboru właściwych narzędzi i technologii, planowania projektowego, dewelopmentu, testowania, utrzymania produkcyjnego i wsparcia serwisowego.

X XXX - XX XXX PLN

Sprawdź, czy wynagrodzenie Ci pasuje

B2B netto
> 4 000 PLN
> 4 500 PLN
> 5 000 PLN
> 5 500 PLN
> 6 000 PLN
> 7 000 PLN
> 8 000 PLN
> 9 000 PLN
> 10 000 PLN
> 12 000 PLN
> 14 000 PLN
> 16 000 PLN
> 18 000 PLN
> 20 000 PLN
> 22 000 PLN
> 24 000 PLN
> 26 000 PLN
> 28 000 PLN
> 30 000 PLN
> 33 000 PLN
> 36 000 PLN
> 39 000 PLN
> 42 000 PLN
> 45 000 PLN
> 50 000 PLN
> 60 000 PLN
> 70 000 PLN
> 80 000 PLN
> 90 000 PLN
> 100 000 PLN

Dokładne widełki poznasz przed pierwszą rozmową.

Poznaj funkcję
Aplikuj
Zapisz ofertę
Analiza CV
BETA

Oceń funkcję Salary Match

😫
🙁
😐
🙂
😃
ZOBACZ PODOBNE OFERTY
Analityk Biznesowy (k/m) | kredyty hipoteczne
Sprawdź wynagrodzenie
Business Analysis
Analiza biznesowa
Sektor Bankowy
Kredyty hipoteczne
 Finture Sp. z o.o
Warszawa
  
 Zapisz ofertę   
IT Business Analyst (K/M)
18 480 – 21 000 PLN / mies.
Business Analysis
MS Office
AML
STIR
 ASTEK Polska
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy/Analityczka Systemowa - obszar kart i płatności (f/m/x)
19 000 – 21 600 PLN / mies.
Business Analysis
UML
BPMN
SQL
 Sii Polska
Warszawa
  
 Zapisz ofertę   
IT Business Analyst (K/M) K/M
13 000 – 14 600 PLN / mies.
Business Analysis
MS Office
AML
STIR
 ASTEK Polska
Warszawa
  
 Zapisz ofertę   
Analityk Biznesowy (K/M)
21 840 – 25 200 PLN / mies.
Business Analysis
SDLC
SQL
Excel
 Antal
Warszawa
  
 Zapisz ofertę   
Analityk biznesowy (modelowanie procesów, API) (K/M)
19 950 – 22 890 PLN / mies.
Business Analysis
Jira
API
SQL
 ASTEK Polska
Warszawa
 +2
  
 Zapisz ofertę   
Ekspert ds. Transformacji Cyfrowej (k/m/d)
Sprawdź wynagrodzenie
Business Analysis
RPA
Automatyzacja
Analiza biznesowa
 Generali Polska
Warszawa
 +2
  
 Zapisz ofertę   
System Analyst – sektor bankowy (f/m/x)
18 000 – 23 000 PLN / mies.
Business Analysis
UML
BPMN
Sparx Systems Enterprise Architect
 Sii Polska
Zdalnie
 +14
  
 Zapisz ofertę   
Salesforce Business Analyst (f/m/x)
26 000 – 30 000 PLN / mies.
Business Analysis
Salesforce
Service Cloud (Salesforce)
polski
 Sii Polska
Kraków
 +13
  
 Zapisz ofertę   
Analityk Systemowy
22 680 – 23 856 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Business Analysis
Warszawa
Analityk Systemowy (k/m)
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria:
Business Analysis
Warszawa
Adres e-mail 
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria *
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert i skorzystaj z dadatkowych benefitów:
100 złotych rabatu na księgowość w inFakcie

W każdej chwili możesz zrezygnować z subskrypcji

© No Fluff Jobs
Więcej
Załóż konto i zgarnij dodatkowe korzyści! 💪
Sprawdź zmiany w swoich aplikacjach.

Załóż konto lub subskrypcję ofertową i zgarnij 100zł rabatu od infaktu

Załóż konto
Zaloguj się</user__selection>
</browser__document__content>

---

## Tab 2063916163

OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
1
Powrót do wyszukiwania
Business Analysis
Remote
Senior Analityk Systemowy
Senior Analityk Systemowy
apreel Sp. z o.o.
Kategoria:
Business Analysis
Senior
100% współpraca zdalna
 Dolnośląskie 
 Kujawsko-Pomorskie 
 Łódzkie 
 Lubelskie 
 Lubuskie 
 Opolskie 
 Podkarpackie 
 Podlaskie 
 Pomorskie 
 Śląskie 
 Świętokrzyskie 
 Warmińsko-Mazurskie 
 Wielkopolskie 
 Zachodniopomorskie 
  
Warszawa, Kraków

Lokalizacje:

Praca zdalna
Warszawa
Kraków
  
Oferta ważna do: 23.10.2026 (zostało 23 dni)
Obowiązkowe
R
API
Kafka
SLA
Jira
Confluence
Enterprise Architect
REST API
HTTP
JSON
XML
Swagger
UI
OpenAPI
Postman
SoapUI
Apache Kafka
UML
BPMN
SQL
Python
Java
C#
Microsoft Azure
Angielski (B2)
Polski (Biegły)
Mile widziane
CRM
Microsoft Dynamics 365
Opis wymagań

Wymagania:

Doświadczenie w samodzielnym prowadzeniu analiz systemowych lub integracyjnych min. 3 lata w roli samodzielnego analityka systemowego.  
Umiejętność przekładania potrzeb biznesowych na jednoznaczne wymagania dla zespołów technicznych.  
Praktyczna znajomość Jira, Confluence oraz Enterprise Architect.  
Znajomość REST API i SOAP w tym metod HTTP, struktur żądań i odpowiedzi oraz formatów JSON i XML, praktyczna znajomość Swagger UI, Swagger Edito.  
Znajomość OpenAPI oraz zasad tworzenia i dokumentowania kontraktów API.  
Praktyczna umiejętność wykorzystania narzędzi typu: Postman, SoapUI, Kafka UI lub podobnych.  
Znajomość integracji synchronicznych i asynchronicznych oraz Apache Kafka.  
Znajomość wzorców i architektur integracyjnych.  
Umiejętność modelowania procesów z wykorzystaniem UML lub BPMN.  
Znajomość podstaw projektowania relacyjnych baz danych i SQL.  
Podstawowa znajomość Python, Java, C# lub innego języka programowania.  
Znajomość podstawowych usług Microsoft Azure.  
Umiejętność analizy dokumentacji technicznej, logów oraz przepływów danych.  
Wykształcenie wyższe o profilu informatycznym lub pokrewnym.  
Samodzielność, analityczne myślenie, dokładność i dobra organizacja pracy umiejętność proponowania wariantów realizacyjnych.  
Doświadczenie w pracy w zespołach Agile lub Scrum.  

Mile widziane:

Doświadczenie w projektach CRM, Microsoft Dynamics 365, Power Platform lub Dataverse, CRM kampanijne.  
Znajomość Azure API Management.  
Doświadczenie w projektach realizowanych w sektorze finansowym lub innym środowisku regulowanym.  
Język angielski na poziomie komunikatywnym w mowie i piśmie.  
Zakres obowiązków
Weryfikacja wymagań biznesowych pod kątem ich kompletności, spójności i wykonalności technicznej i przekładanie ich na wymagania systemowe, integracyjne i niefunkcjonalne.
Samodzielne prowadzenie analizy systemowej będącej elementem projektowania rozwiązania, doskonała komunikacja z rolami biznesowymi i technicznymi.
Opisywanie logiki systemowej, algorytmów, walidacji, reguł biznesowych, przypadków brzegowych oraz modelowanie danych, encji, relacji oraz logicznych modeli danych.
Identyfikowanie systemów źródłowych i właścicieli danych oraz weryfikacja dostępności wymaganych danych w systemach źródłowych oraz przygotowywanie specyfikacji integracyjnych, kontraktów API, struktur komunikatów Kafka, oraz mapowania pól.
Określanie sposobu obsługi błędów, ponowień, timeoutów, logowania i monitoringu.
Definiowanie wymagań dotyczących bezpieczeństwa, integralności danych, dostępności, SLA, wydajności, backupu i infrastruktury.
pokaż wszystko (9)
Opis oferty

Opis projektu: Realizacja strategii banku w obszarze klienta biznesowego – do projektu Nowa Platforma Kampanijna.

Oferta:

Lokalizacja: Warszawa lub Kraków;współpraca ZDALNA 😊
Start: ASAP
Zatrudnienie: przez apreel na zasadach B2B
Stawka: do 160 PLN netto/h
Szczegóły oferty
Start ASAP
  
100% współpraca zdalna
  
Benefity
Modern technologies
O firmie apreel Sp. z o.o. 

Utworzona w:
2010

Wielkość firmy:
200+

Siedziba:
Warsaw

140 – 160 PLN
+ VAT (B2B) godzinowo 
Aplikuj
Zapisz ofertę
Analiza CV
BETA

Oceń tę ofertę

😫
🙁
😐
🙂
😃
ZOBACZ PODOBNE OFERTY
Analityk Systemowy (m/k)
25 200 – 26 880 PLN / mies.
Business Analysis
REST API
SQL
Kafka
 Devire
Zdalnie
  
 Zapisz ofertę   
Analityk Systemowy
17 640 – 19 320 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy
22 680 – 23 856 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy/Analityczka Systemowa - obszar kart i płatności (f/m/x)
19 000 – 21 600 PLN / mies.
Business Analysis
UML
BPMN
SQL
 Sii Polska
Warszawa
  
 Zapisz ofertę   
Analityk systemowy / Analityczka systemowa
21 840 – 22 680 PLN / mies.
Business Analysis
Jira
Confluence
PuTTY
 Diverse CG Sp. z o.o. Sp.k.
Warszawa
 +1
  
 Zapisz ofertę   
Analityk Systemowy / Analityczka Systemowa | Obszar Bankowy
Sprawdź wynagrodzenie
Business Analysis
SQL
BPMN
UML
 Finture Sp. z o.o
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy
Sprawdź wynagrodzenie
Business Analysis
SQL
Visio
Enterprise Architect
 PKO Finat Sp. z o.o.
Warszawa
  
 Zapisz ofertę   
Analityk Systemowa / Analityczka Systemowa
21 840 – 25 200 PLN / mies.
Business Analysis
Python
System analysis
GCP
 ASTEK Polska
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy (k/m)
Sprawdź wynagrodzenie
Business Analysis
Analiza systemowa
Analityka
Sektor Bankowy
 Finture Sp. z o.o
Warszawa
 +1
  
 Zapisz ofertę   
Analityk Systemowy
10 920 – 11 760 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Business Analysis
Remote
Senior Analityk Systemowy
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria:
Business Analysis
Praca zdalna
Adres e-mail 
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria *
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert i skorzystaj z dadatkowych benefitów:
100 złotych rabatu na księgowość w inFakcie

W każdej chwili możesz zrezygnować z subskrypcji

© No Fluff Jobs
Więcej
Załóż konto i zgarnij dodatkowe korzyści! 💪
Sprawdź zmiany w swoich aplikacjach.

Załóż konto lub subskrypcję ofertową i zgarnij 100zł rabatu od infaktu

Załóż konto
Zaloguj się

---

## Tab 2063916162

OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
1
Powrót do wyszukiwania
Business Analysis
Warszawa
Analityk Systemowy Bankowy
Analityk Systemowy Bankowy
PKO Finat Sp. z o.o.
Kategoria:
Business Analysis
Mid
Hybrydowo
+1

Lokalizacje:

Warszawa
 , 89 ul. Chmielna 
 40% stacjonarnie, 60% zdalnie 
  
Oferta ważna do: 15.10.2026 (zostało 15 dni)
Obowiązkowe
Analiza systemowa
Postman
Jira
Confluence
UML
BPMN
Enterprise Architect
System analysis
Business analysis
Polski
Opis wymagań
umiejętności analizy wymagań biznesowych i technicznych, funkcjonalnych i niefunkcjonalnych
umiejętności analizy procesów AS-IS, analizy systemowej zmian oraz analizy logów
umiejętność tworzenia dokumentacji technicznej
znajomość narzędzi: Postman, Putty, narzędzi modelowania, JIRA, Confluence,
umiejętność komunikacji z interesariuszami
Zakres obowiązków
projektowanie architektury logicznej i komponentów systemowych z uwzględnieniem wymagań niefunkcjonalnych
opracowanie dokumentacji technicznej, specyfikacji rozwiązań oraz modeli logicznych
definiowanie i dokumentowanie integracji między systemami oraz standardów wymiany danych
współpraca z architektami i zespołami deweloperskimi w zakresie implementacji rozwiązań
przygotowywanie konfiguracji aplikacji i współpraca z administratorami aplikacji
analiza wymagań biznesowych i analiza systemowej pozwalającej na development zmian w aplikacji iPKO
pokaż wszystko (9)
Opis oferty
Szeroki zakres zmian funkcjonalnych w bankowości elektronicznej klienta detalicznego


Szczegóły oferty
Rekrutacja online
  
Start ASAP
  
Praca zdalna przez 3 dni w tygodniu
  
O firmie PKO Finat 

Utworzona w:
2001

Wielkość firmy:
250

Lokalizacje:
Warszawa + 1

PKO Finat  - Spółka z Grupy PKO BP, która świadczy kompleksowe usługi firmom z sektora finansowego – m.in.: usługi agenta transferowego, księgowości funduszy i spółek. Specjalizuje się również w usługach IT. Oferuje najwyższe standardy obsługi i wsparcia, opierając się na autorskich systemach informatycznych i korzystając z wieloletniego doświadczenia.
130 – 145 PLN
+ VAT (B2B) godzinowo 
Aplikuj
Zapisz ofertę
Analiza CV
BETA

Oceń tę ofertę

😫
🙁
😐
🙂
😃
ZOBACZ PODOBNE OFERTY
Analityk Systemowy Bankowy / ERP
21 000 – 24 360 PLN / mies.
Business Analysis
ERP
CA
UML
 PKO Finat Sp. z o.o.
Warszawa
  
 Zapisz ofertę   
Senior Analityk Systemowy
23 520 – 26 880 PLN / mies.
Business Analysis
R
API
Kafka
 apreel Sp. z o.o.
Zdalnie
 +2
  
 Zapisz ofertę   
Business Analyst
23 520 – 26 880 PLN / mies.
Business Analysis
Business analysis
BPMN
UML
 PKO Finat Sp. z o.o.
Warszawa
  
 Zapisz ofertę   
Analityk AI/LLM
23 520 – 26 040 PLN / mies.
Business Analysis
AI
UML
BPMN
 PKO Finat Sp. z o.o.
Warszawa
  
 Zapisz ofertę   
Business Analyst
20 160 – 22 680 PLN / mies.
Business Analysis
UML
BPMN
SQL
 Connectis_
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy (Bankowość) K/M
18 900 – 24 990 PLN / mies.
Business Analysis
UML
BPMN
Jira
 ASTEK Polska
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy
17 640 – 19 320 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy
10 920 – 11 760 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy (Bankowość) K/M
12 000 – 17 650 PLN / mies.
Business Analysis
UML
BPMN
Confluence
 ASTEK Polska
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy
22 680 – 23 856 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Business Analysis
Warszawa
Analityk Systemowy Bankowy
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria:
Business Analysis
Warszawa
Adres e-mail 
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria *
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert i skorzystaj z dadatkowych benefitów:
100 złotych rabatu na księgowość w inFakcie

W każdej chwili możesz zrezygnować z subskrypcji

© No Fluff Jobs
Więcej
Załóż konto i zgarnij dodatkowe korzyści! 💪
Sprawdź zmiany w swoich aplikacjach.

Załóż konto lub subskrypcję ofertową i zgarnij 100zł rabatu od infaktu

Załóż konto
Zaloguj się

---

## Tab 2063916161

OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
1
Powrót do wyszukiwania
Business Analysis
Warsaw
IT Senior Consultant for Technology Strategy and M&A | Poland
IT Senior Consultant for Technology Strategy and M&A | Poland
Deloitte
Kategoria:
Business Analysis
Senior
Hybrydowo
+1

Lokalizacje:

Warsaw
 40% stacjonarnie, 60% zdalnie 
  
Oferta ważna do: 29.10.2026 (zostało 29 dni)
Obowiązkowe
Enterprise Architect
PowerPoint
Visio
Miro
Degree
Polski (C2)
Angielski (C1)
Mile widziane
BPMN
UML
ITIL
Cloud
Cybersecurity
Opis wymagań
Oryginalny tekst. 
Pokaż tłumaczenie
To succeed in this role, you should have:
3+ years of professional experience in IT, technology consulting, IT strategy, digital transformation, enterprise architecture, or related areas.
Strong analytical and problem-solving skills, with the ability to translate complex technology topics into practical business recommendations.
Understanding of IT processes, operating models, and the role technology plays in achieving business objectives.
Experience creating clear and compelling presentations, process flows, and architecture diagrams using tools such as PowerPoint, Visio, Miro, Google Slides, or similar.
A Bachelor’s or Master’s degree in Information Technology, Business Informatics, Engineering, or another relevant discipline.
Proficiency in Polish (C2/native level) and English (C1 or higher).
Valid authorization to work in Poland.
What will set you apart?

The following qualifications will be considered a strong advantage:

Experience in IT strategy, technology-enabled transformations, IT M&A, or CIO advisory projects.
Previous experience in a consulting environment (Big Four, MBB, or other leading consulting firms).
Knowledge of financial management, IT cost optimization, or business case development.
Practical experience with BPMN, UML, or other process and architecture modeling frameworks.
Relevant certifications in ITIL, project management, cloud technologies, cybersecurity, enterprise architecture, or related areas.
German or another European language.

If your profile matches these qualifications, you'll have an excellent opportunity to thrive in this role and contribute effectively to our team!

Zakres obowiązków
Oryginalny tekst. 
Pokaż tłumaczenie
Joining our team comes with a range of exciting opportunities and benefits, including:
Impactful projects: take on a key role in local and international IT strategy and M&A projects, with a strong focus on technology.
Accelerated career growth: benefit from a fast-track development program aimed at enhancing your professional capabilities and expertise.
Expanded knowledge base: work alongside specialists in IT, allowing you to deepen your understanding and broaden your skills.
Personalized career coaching: gain support from your own career coach, who will facilitate your integration into the organization and guide your professional journey.
Professional development opportunities: access funding for market-recognized IT training and certifications such as CISSP, ITIL, TOGAF, PMP, cloud (AWS, Azure, or GCP) to advance your expertise.
pokaż wszystko (9)
Opis oferty
Oryginalny tekst. 
Pokaż tłumaczenie

About the team: 

The Business of Technology Team provides expert support to clients in the development and operationalization of IT strategies, as well as during international M&A transactions from an IT and technology perspective. Our specialists are skilled in crafting and refining IT strategies, assessing IT processes, designing target operating models, and delivering comprehensive services such as due diligence, carve-outs, and post-merger integration. Our advisory services cover a broad range of technological areas, including: * IT Strategy analysis and optimization: evaluating and improving existing strategies. * Application and infrastructure assessment: determining capabilities for integration and scalability. * Internal IT process enhancement: reviewing and streamlining key workflows. * Cybersecurity & regulatory compliance: strengthening security measures and ensuring compliance with industry regulations. We collaborate with major players across varied industries, offering you outstanding opportunities for personal growth and the chance to develop an extensive understanding of IT and technology. By joining our team, you will gain exposure to meaningful challenges and contribute to transformative projects that drive innovation and business success.

What we offer:

Joining our team comes with a range of exciting opportunities and benefits, including:
Impactful projects: take on a key role in local and international IT strategy and M&A projects, with a strong focus on technology.
Accelerated career growth: benefit from a fast-track development program aimed at enhancing your professional capabilities and expertise.
Expanded knowledge base: work alongside specialists in IT, allowing you to deepen your understanding and broaden your skills.
Personalized career coaching: gain support from your own career coach, who will facilitate your integration into the organization and guide your professional journey.
Professional development opportunities: access funding for market-recognized IT training and certifications such as CISSP, ITIL, TOGAF, PMP, cloud (AWS, Azure, or GCP) to advance your expertise.
Flexible working options: enjoy the freedom to work remotely or from the office, with arrangements tailored to your preferences.
Collaborative environment: be part of a friendly workplace culture that fosters team engagement and regular opportunities for social integration.
We’re dedicated to empowering you to thrive in your career while maintaining a positive and supportive work environment.







Szczegóły oferty
Start ASAP
  
Praca zdalna przez 3 dni w tygodniu
  
O firmie Deloitte 

Utworzona w:
1845

Wielkość firmy:
1000+

Lokalizacje:
Warsaw + 9

Deloitte to zespół konsultantów, których wyróżniają kompetencje marketingowe, wiedza branżowa oraz doświadczenie w doradztwie strategicznym i technologicznym. Wspieramy naszych klientów w zarządzaniu zmianą, wpierającą procesy Digital Transformation.

Chcesz budować swoją karierę w zespołach technologicznych? Lista obszarów, w których możesz się z nami rozwijać jest długa: cloud computing, SAP, Salesforce, digital marketing, sprzedaż, architektura, wdrażanie, konsulting, development czy cyberbepieczeństwo to tylko niektóre z nich.

X XXX - XX XXX PLN

Sprawdź, czy wynagrodzenie Ci pasuje

UoP brutto
> 4 000 PLN
> 4 500 PLN
> 5 000 PLN
> 5 500 PLN
> 6 000 PLN
> 7 000 PLN
> 8 000 PLN
> 9 000 PLN
> 10 000 PLN
> 12 000 PLN
> 14 000 PLN
> 16 000 PLN
> 18 000 PLN
> 20 000 PLN
> 22 000 PLN
> 24 000 PLN
> 26 000 PLN
> 28 000 PLN
> 30 000 PLN
> 33 000 PLN
> 36 000 PLN
> 39 000 PLN
> 42 000 PLN
> 45 000 PLN
> 50 000 PLN
> 60 000 PLN
> 70 000 PLN
> 80 000 PLN
> 90 000 PLN
> 100 000 PLN

Dokładne widełki poznasz na pierwszej rozmowie.

Poznaj funkcję
Aplikuj
Zapisz ofertę
Analiza CV
BETA

Oceń funkcję Salary Match

😫
🙁
😐
🙂
😃
ZOBACZ PODOBNE OFERTY
IT Consultant for Technology Strategy and M&A | Poland
Sprawdź wynagrodzenie
Business Analysis
PowerPoint
Visio
Miro
 Deloitte
Warsaw
  
NOWA
 Zapisz ofertę   
Analityk Systemowy Bankowy
21 840 – 24 360 PLN / mies.
Business Analysis
Analiza systemowa
Postman
Jira
 PKO Finat Sp. z o.o.
Warszawa
  
 Zapisz ofertę   
Senior Analityk Systemowy
23 520 – 26 880 PLN / mies.
Business Analysis
R
API
Kafka
 apreel Sp. z o.o.
Zdalnie
 +2
  
NOWA
 Zapisz ofertę   
Analityk Systemowy
22 680 – 23 856 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy
17 640 – 19 320 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Analityk AI/LLM
23 520 – 26 040 PLN / mies.
Business Analysis
AI
UML
BPMN
 PKO Finat Sp. z o.o.
Warszawa
  
 Zapisz ofertę   
System Analyst
Sprawdź wynagrodzenie
Business Analysis
UML
BPMN
Enterprise Architect
 Connectis_
Zdalnie
  
 Zapisz ofertę   
Business/System Analyst
21 840 – 27 720 PLN / mies.
Business Analysis
System analyst
UML
BPMN
 Devire
Zdalnie
  
 Zapisz ofertę   
Starszy Analityk Systemowy (K/M)
21 840 – 25 200 PLN / mies.
Business Analysis
UML
BPMN
Enterprise Architect
 Neontri
Zdalnie
  
NOWA
 Zapisz ofertę   
Analityk Systemowy
21 840 – 23 520 PLN / mies.
Business Analysis
Enterprise Architect
UX
UI
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Zdalnie
  
NOWA
 Zapisz ofertę   
Business Analysis
Warsaw
IT Senior Consultant for Technology Strategy and M&A | Poland
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria:
Business Analysis
Warszawa
Adres e-mail 
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria *
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert i skorzystaj z dadatkowych benefitów:
100 złotych rabatu na księgowość w inFakcie

W każdej chwili możesz zrezygnować z subskrypcji

© No Fluff Jobs
Więcej
Załóż konto i zgarnij dodatkowe korzyści! 💪
Sprawdź zmiany w swoich aplikacjach.

Załóż konto lub subskrypcję ofertową i zgarnij 100zł rabatu od infaktu

Załóż konto
Zaloguj się

---

## Tab 2063916160

OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
1
Powrót do wyszukiwania
Business Analysis
Warsaw
IT Consultant for Technology Strategy and M&A | Poland
IT Consultant for Technology Strategy and M&A | Poland
Deloitte
Kategoria:
Business Analysis
Mid
Hybrydowo
+1

Lokalizacje:

Warsaw
 40% stacjonarnie, 60% zdalnie 
  
Oferta ważna do: 29.10.2026 (zostało 29 dni)
Obowiązkowe
PowerPoint
Visio
Miro
Degree
Polski (C2)
Angielski (B2)
Opis wymagań
Oryginalny tekst. 
Pokaż tłumaczenie

To succeed in this role, you should have:

Up to 3 years of professional experience in IT, technology consulting, digital transformation, business technology, or a related field.
Strong analytical and problem-solving skills, with the ability to structure complex topics and develop practical recommendations.
A good understanding of IT processes, operating models, and how technology supports business objectives.
Experience creating clear and compelling presentations, process maps, and architecture visualizations using tools such as PowerPoint, Visio, Miro, Google Slides, or similar.
A Bachelor's or Master's degree in Information Technology, Business Informatics, Engineering, or another relevant discipline.
Professional proficiency in Polish (native or C2 level) and English (minimum B2 level).
Valid authorization to work in Poland.
Zakres obowiązków
Oryginalny tekst. 
Pokaż tłumaczenie
As part of our team, you will have the opportunity to:
Develop strategic solutions: drive the design and implementation of IT strategies, operating models, and process assessments aimed at improving organizational efficiency and effectiveness.
Conduct evaluations: assess companies' IT strategies, systems, business applications, organizational structures, IT infrastructures, security practices, and internal processes.
Support M&A processes: provide guidance during the M&A lifecycle with a focus on the pre-deal phase, including IT Due Diligence, Technology/Software Due Diligence, Vendor Support, and Synergy Assessments.
Advise IT Leaders: support team in collaboration with top IT executives (CIOs, CTOs, IT Directors) across diverse industries and global geographies.
Provide tailored recommendations: offer bespoke advisory services and develop risk mitigation strategies tailored to transaction-specific needs.
pokaż wszystko (8)
Opis oferty
Oryginalny tekst. 
Pokaż tłumaczenie

About the team: 

The Business of Technology Team provides expert support to clients in the development and operationalization of IT strategies, as well as during international M&A transactions from an IT and technology perspective. Our specialists are skilled in crafting and refining IT strategies, assessing IT processes, designing target operating models, and delivering comprehensive services such as due diligence, carve-outs, and post-merger integration. Our advisory services cover a broad range of technological areas, including: * IT Strategy analysis and optimization: evaluating and improving existing strategies. * Application and infrastructure assessment: determining capabilities for integration and scalability. * Internal IT process enhancement: reviewing and streamlining key workflows. * Cybersecurity & regulatory compliance: strengthening security measures and ensuring compliance with industry regulations. We collaborate with major players across varied industries, offering you outstanding opportunities for personal growth and the chance to develop an extensive understanding of IT and technology. By joining our team, you will gain exposure to meaningful challenges and contribute to transformative projects that drive innovation and business success.

What we offer:

Joining our team comes with a range of exciting opportunities and benefits, including:
Impactful projects: take on a key role in local and international IT strategy and M&A projects, with a strong focus on technology.
Accelerated career growth: benefit from a fast-track development program aimed at enhancing your professional capabilities and expertise.
Expanded knowledge base: work alongside specialists in IT, allowing you to deepen your understanding and broaden your skills.
Personalized career coaching: gain support from your own career coach, who will facilitate your integration into the organization and guide your professional journey.
Professional development opportunities: access funding for market-recognized IT training and certifications such as CISSP, ITIL, TOGAF, PMP, cloud (AWS, Azure, or GCP) to advance your expertise.
Flexible working options: enjoy the freedom to work remotely or from the office, with arrangements tailored to your preferences.
Collaborative environment: be part of a friendly workplace culture that fosters team engagement and regular opportunities for social integration.
We’re dedicated to empowering you to thrive in your career while maintaining a positive and supportive work environment.







Szczegóły oferty
Start ASAP
  
Praca zdalna przez 3 dni w tygodniu
  
O firmie Deloitte 

Utworzona w:
1845

Wielkość firmy:
1000+

Lokalizacje:
Warsaw + 9

Deloitte to zespół konsultantów, których wyróżniają kompetencje marketingowe, wiedza branżowa oraz doświadczenie w doradztwie strategicznym i technologicznym. Wspieramy naszych klientów w zarządzaniu zmianą, wpierającą procesy Digital Transformation.

Chcesz budować swoją karierę w zespołach technologicznych? Lista obszarów, w których możesz się z nami rozwijać jest długa: cloud computing, SAP, Salesforce, digital marketing, sprzedaż, architektura, wdrażanie, konsulting, development czy cyberbepieczeństwo to tylko niektóre z nich.

X XXX - XX XXX PLN

Sprawdź, czy wynagrodzenie Ci pasuje

UoP brutto
> 4 000 PLN
> 4 500 PLN
> 5 000 PLN
> 5 500 PLN
> 6 000 PLN
> 7 000 PLN
> 8 000 PLN
> 9 000 PLN
> 10 000 PLN
> 12 000 PLN
> 14 000 PLN
> 16 000 PLN
> 18 000 PLN
> 20 000 PLN
> 22 000 PLN
> 24 000 PLN
> 26 000 PLN
> 28 000 PLN
> 30 000 PLN
> 33 000 PLN
> 36 000 PLN
> 39 000 PLN
> 42 000 PLN
> 45 000 PLN
> 50 000 PLN
> 60 000 PLN
> 70 000 PLN
> 80 000 PLN
> 90 000 PLN
> 100 000 PLN

Dokładne widełki poznasz na pierwszej rozmowie.

Poznaj funkcję
Aplikuj
Zapisz ofertę
Analiza CV
BETA

Oceń funkcję Salary Match

😫
🙁
😐
🙂
😃
ZOBACZ PODOBNE OFERTY
IT Senior Consultant for Technology Strategy and M&A | Poland
Sprawdź wynagrodzenie
Business Analysis
Enterprise Architect
PowerPoint
Visio
 Deloitte
Warsaw
  
NOWA
 Zapisz ofertę   
Analityk Systemowy
17 640 – 19 320 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy
22 680 – 23 856 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
Analityk Systemowy
10 920 – 11 760 PLN / mies.
Business Analysis
UML
BPMN
API
 AVENGA (Agencja Pracy, nr KRAZ: 8448)
Warszawa
  
 Zapisz ofertę   
QA and SDLC Control Analyst
23 100 – 29 400 PLN / mies.
Business Analysis
Business Analyst
SDLC
QA
 Mindbox Sp. z o.o.
Kraków
  
 Zapisz ofertę   
IDPP Technical Business Analyst
21 000 – 25 200 PLN / mies.
Business Analysis
Business Analyst
IAM
AD
 Mindbox Sp. z o.o.
Kraków
  
 Zapisz ofertę   
System Analyst (Discovery)
23 520 – 31 920 PLN / mies.
Business Analysis
Business analysis
BPMN
UML
 Upvanta
Zdalnie
  
 Zapisz ofertę   
System Analyst (Discovery)
21 840 – 26 880 PLN / mies.
Business Analysis
Business analysis
BPMN
UML
 Upvanta
Zdalnie
  
 Zapisz ofertę   
Business Analyst - Data Strategy & Banking
Sprawdź wynagrodzenie
Business Analysis
Business Analyst
Stakeholder management
Excel
 Belvedere Recruitment
Krakow
  
 Zapisz ofertę   
Cost Transformation – CTA Tracking & Reporting Business Analyst
Sprawdź wynagrodzenie
Business Analysis
Excel
PowerPoint
Analytical skills
 Belvedere Recruitment
Krakow
  
NOWA
 Zapisz ofertę   
Business Analysis
Warsaw
IT Consultant for Technology Strategy and M&A | Poland
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria:
Business Analysis
Warszawa
Adres e-mail 
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria *
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert i skorzystaj z dadatkowych benefitów:
100 złotych rabatu na księgowość w inFakcie

W każdej chwili możesz zrezygnować z subskrypcji

© No Fluff Jobs
Więcej
Załóż konto i zgarnij dodatkowe korzyści! 💪
Sprawdź zmiany w swoich aplikacjach.

Załóż konto lub subskrypcję ofertową i zgarnij 100zł rabatu od infaktu

Załóż konto
Zaloguj się

---

## Tab 2063916159

OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
Powrót do wyszukiwania
PHP
Backend
Gdańsk
Senior PHP Software Engineer
Senior PHP Software Engineer
Wakacje.pl
Kategoria:
Backend
, 
PHP
Senior
Hybrydowo
+1

Lokalizacje:

Gdańsk
 , Aleja Grunwaldzka 413 
 20% stacjonarnie, 80% zdalnie 
  
Oferta ważna do: 24.10.2026 (zostało 24 dni)
Obowiązkowe
Architecture
Communication skills
PHP
PHPunit
Symfony
Laravel
Slim
PostgreSQL
REST API
NoSQL
Event-driven
Angielski (B2)
Polski (Biegły)
Mile widziane
SAFe
AI
API
E-commerce
Elasticsearch
Docker
Opis wymagań
Oryginalny tekst. 
Pokaż tłumaczenie
7+ years of experience with PHP 7.x/8.x
Proficiency in a major PHP framework — multi-framework environment (Symfony, Laravel, Slim); minimum 3–4 years of production experience with at least one, with working knowledge of the others and the ability to move between frameworks comfortably
Hands-on experience with REST API design and development
Experience writing automated tests with PHPUnit (unit and integration testing)
Familiarity with the Linux command line (basic level required)
Strong understanding of relational databases and SQL (PostgreSQL) — schema design, query optimization, indexing, transactions
NoSQL / caching technologies (Redis, Elasticsearch) — working level
Git / GitHub (pull requests, code review), Docker
OOP, SOLID principles, design patterns
Sound architectural judgment — ability to select solutions appropriate to actual needs and avoid over-engineering (key aspect of this role)
Event-driven architecture / message queues
English proficiency at a B2+ level (communicative)

Soft Skills (Required)

Strong communication — able to clearly explain and justify technical decisions to the Team Lead and the wider team
Analytical thinking, problem-solving, and the ability to weigh trade-offs
Collaboration and mentoring — planning with the Team Lead and leading regular development sessions

Nice to Have / Willingness to Learn

Hands-on experience with Docker and Elasticsearch
Experience with message brokers like RabbitMQ
Knowledge of visualization tools like Kibana or Grafana
Contributing to CI/CD pipelines
An additional programming language (Go, Python, JS/TS)
SEO in e-commerce context
Zakres obowiązków
Oryginalny tekst. 
Pokaż tłumaczenie
Support the Team Lead in designing the architecture of services and broader technical solutions, collaborating closely on planning and roadmap decisions
Consult with the area Architect to ensure proposed solutions align with overall system architecture and standards
Lead regular mentoring sessions with developers, supporting their technical growth and code quality
Evaluate architectural options critically, selecting solutions that fit actual business and technical needs while avoiding over-engineering
Design and maintain REST APIs and event-driven/queue-based integrations across services
Ensure code quality and reliability through unit and integration testing (PHPUnit) and active participation in code reviews
Opis oferty
Oryginalny tekst. 
Pokaż tłumaczenie

About us:

We are an e-commerce platform and a network of travel agencies offering a wide range of travel products. Since 2015, we have been part of Wirtualna Polska Holding – Poland’s largest group of media and e-commerce companies. Together with Travelplanet.pl and the Invia brands across CEE, we are building a unified travel group driven by a shared #TravelMindset. In our daily work, we #Explore better ways to grow, #Engage through real ownership and teamwork, and #Enjoy building experiences that people genuinely look forward to.
Send us your CV and… see you at Invia CEE x Travelplanet.pl x Wakacje.pl! ✈️

This role sits within a team responsible for designing and evolving the architecture of core backend services that power the product's e-commerce and platform capabilities. The team owns the technical direction of key service areas, ensuring solutions are scalable, maintainable, and aligned with the broader system architecture. Working closely with the Team Lead and area Architect, this position contributes directly to shaping how services are built and integrated, ensuring technical decisions support both immediate feature delivery and the long-term health of the platform. The role plays a key part in bridging hands-on development with architectural planning, helping the team avoid both technical debt and unnecessary complexity.

Szczegóły oferty
Rekrutacja online
  
Język rekrutacji: polski&angielski
  
Start ASAP
  
Płatny urlop dla: B2B
  
Praca zdalna przez 4 dni w tygodniu
  
Elastyczne godziny
  
Trochę podróży służbowych
  
Sprzęt
 Linux 
 Apple 
 Windows 
 Komputer: Notebook 
 Monitory: Opcjonalnie 
Metodologia
Integration tests
Unit tests
Tester(s)
Agile management
Code reviews
SAFe
Udogodnienia w biurze
Darmowa kawa
Bez wymaganego dress code'u
Benefity
Prywatna opieka medyczna
Flexible working hours
Life insurance
Discounts
X XXX - XX XXX PLN

Sprawdź, czy wynagrodzenie Ci pasuje

B2B netto
> 4 000 PLN
> 4 500 PLN
> 5 000 PLN
> 5 500 PLN
> 6 000 PLN
> 7 000 PLN
> 8 000 PLN
> 9 000 PLN
> 10 000 PLN
> 12 000 PLN
> 14 000 PLN
> 16 000 PLN
> 18 000 PLN
> 20 000 PLN
> 22 000 PLN
> 24 000 PLN
> 26 000 PLN
> 28 000 PLN
> 30 000 PLN
> 33 000 PLN
> 36 000 PLN
> 39 000 PLN
> 42 000 PLN
> 45 000 PLN
> 50 000 PLN
> 60 000 PLN
> 70 000 PLN
> 80 000 PLN
> 90 000 PLN
> 100 000 PLN

Dokładne widełki poznasz na pierwszej rozmowie.

Poznaj funkcję
Aplikuj
Zapisz ofertę
Analiza CV
BETA

Oceń funkcję Salary Match

😫
🙁
😐
🙂
😃
PHP
Backend
Gdańsk
Senior PHP Software Engineer
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria:
Backend
Php
Gdańsk
Adres e-mail 
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria *
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert i skorzystaj z dadatkowych benefitów:
100 złotych rabatu na księgowość w inFakcie

W każdej chwili możesz zrezygnować z subskrypcji

© No Fluff Jobs
Więcej

---

## Tab 2063916158

OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
Powrót do wyszukiwania
Java
Backend
Kraków
Expert Java Engineer
Expert Java Engineer
GFT Poland
Kategoria:
Backend
, 
Java
Expert
Hybrydowo
+1

Lokalizacje:

Kraków
 , ul. Wadowicka 7 
 40% stacjonarnie, 60% zdalnie 
  
Oferta ważna do: 17.10.2026 (zostało 17 dni)
Obowiązkowe
Java
Microservices
REST API
SQL
NoSQL
Kubernetes
GKE
GCP
CI/CD
DevOps
Angielski
Opis wymagań
Oryginalny tekst. 
Pokaż tłumaczenie
5+ years of hands-on experience in Java backend development
Experience building microservices, REST APIs, and distributed systems
Experience developing high-performance, scalable, and highly available applications
Experience with SQL, NoSQL, and large-scale data processing platforms
Experience with Kubernetes, GKE, and cloud platforms, preferably GCP
Experience with CI/CD, DevSecOps, and modern software engineering practices
Strong understanding of system design, reliability, and maintainability
Experience working in Agile teams within complex enterprise environments
Zakres obowiązków
Oryginalny tekst. 
Pokaż tłumaczenie
Design and develop high-performance Java Services
Build scalable microservices and distributed dystems
Create and maintain REST APIs
Optimize application performance and reliability
Implement CI/CD pipelines and DevSecOps practices
Work with SQL and NoSQL databases
pokaż wszystko (12)
Opis oferty
Oryginalny tekst. 
Pokaż tłumaczenie

What will you do?

Join a team building and operating high-performance, highly available distributed systems for the financial sector. You will design and develop scalable backend services, work with modern cloud-native technologies, and contribute to the full software development lifecycle, from architecture and implementation to deployment and production support.

We offer

Hybrid work in one of our client's office (Kraków) 8 days a month
Working in a highly experienced and dedicated team
Benefit package tailored to your needs (medical, sport, lunch subsidy, life insurance, etc.)
Online training and certifications
Access to e‑learning platform
Social events

Szczegóły oferty
Rekrutacja online
  
Język rekrutacji: polski
  
Start ASAP
  
Praca zdalna przez 3 dni w tygodniu
  
Sprzęt
 Windows 
 Komputer: Notebook 
Udogodnienia w biurze
Darmowa kawa
Parking dla rowerów
Darmowe przekąski
Darmowe napoje
Darmowy parking
Szkolenia wewnętrzne
Benefity
Life insurance
Pakiet sportowy
Budżet na szkolenia
Prywatna opieka medyczna
Międzynarodowe projekty
O firmie GFT Technologies Poland 

Utworzona w:
2014

Wielkość firmy:
1000+

Lokalizacje:
Łódź + 4

17 400 – 26 700 PLN
brutto miesięcznie (UoP) 
oblicz netto
Aplikuj
Zapisz ofertę
Analiza CV
BETA

Oceń tę ofertę

😫
🙁
😐
🙂
😃
ZOBACZ PODOBNE OFERTY
Senior Java Developer
31 920 – 38 640 PLN / mies.
Backend
Java
REST API
Microservices
 Antal
Kraków
  
 Zapisz ofertę   
Tech Lead Java Engineer
17 400 – 26 700 PLN / mies.
Backend
Java
Spring Framework
Hibernate
 GFT Poland
Kraków
  
 Zapisz ofertę   
Expert Java Consultant
26 040 – 34 440 PLN / mies.
Backend
Java
Spring Framework
Hibernate
 GFT Poland
Kraków
  
 Zapisz ofertę   
Senior Java Engineer
14 600 – 22 300 PLN / mies.
Backend
Java
Spring
Performance tuning
 GFT Poland
Kraków
  
 Zapisz ofertę   
Senior Java Engineer
14 600 – 22 300 PLN / mies.
Backend
Java
Microservices
DevOps
 GFT Poland
Kraków
  
 Zapisz ofertę   
Tech Lead Java Engineer
17 400 – 26 700 PLN / mies.
Backend
Java
Spring Boot
JPA
 GFT Poland
Kraków
  
 Zapisz ofertę   
Senior Java Consultant
21 000 – 26 880 PLN / mies.
Backend
Java
Microservices
DevOps
 GFT Poland
Kraków
  
 Zapisz ofertę   
Expert Java Consultant
26 040 – 34 440 PLN / mies.
Backend
Java
Spring Boot
JPA
 GFT Poland
Kraków
  
 Zapisz ofertę   
Tech Lead Java Engineer
17 400 – 26 700 PLN / mies.
Backend
Java
Spring Boot
JPA
 GFT Poland
Kraków
  
 Zapisz ofertę   
Senior Java Consultant
21 000 – 26 880 PLN / mies.
Backend
Java
Spring
Performance tuning
 GFT Poland
Kraków
  
 Zapisz ofertę   
Java
Backend
Kraków
Expert Java Engineer
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria:
Backend
Java
Kraków
Adres e-mail 
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria *
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert i skorzystaj z dadatkowych benefitów:
100 złotych rabatu na księgowość w inFakcie

W każdej chwili możesz zrezygnować z subskrypcji

© No Fluff Jobs
Więcej

---

## Tab 2063916157

OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
Powrót do wyszukiwania
Java
Backend
Kraków
Tech Lead Java Engineer
Tech Lead Java Engineer
GFT Poland
Kategoria:
Backend
, 
Java
Expert
Hybrydowo
+1

Lokalizacje:

Kraków
 60% stacjonarnie, 40% zdalnie 
  
Oferta ważna do: 23.10.2026 (zostało 23 dni)
Obowiązkowe
Java
Spring Framework
Hibernate
Kafka
JMS
Azure DevOps
SQL
Git
TDD
BDD
Angielski (B2)
Mile widziane
Cloud
Microservices
CI/CD
Opis wymagań
Oryginalny tekst. 
Pokaż tłumaczenie
7+ years of commercial experience with Java development
Strong knowledge of Spring Framework
Experience with Hibernate
Experience with Apache Kafka
Knowledge of JMS
Experience with Azure DevOps
Good knowledge of SQL
Experience with Git
Understanding of TDD and BDD methodologies
Strong problem-solving and debugging skills
Experience with software design and development best practices

Nice to have

Experience with cloud-based solutions
Knowledge of microservices architecture
Experience with performance optimization
Experience with containerization technologies
Knowledge of CI/CD automation
Zakres obowiązków
Oryginalny tekst. 
Pokaż tłumaczenie
Design and develop enterprise-level Java applications
Implement scalable and maintainable software solutions
Develop integrations using Apache Kafka and JMS
Create and maintain applications based on Spring Framework and Hibernate
Participate in architecture discussions and code reviews
Write unit and integration tests using TDD and BDD practices
pokaż wszystko (9)
Opis oferty
Oryginalny tekst. 
Pokaż tłumaczenie
We are GFT Poland

WE KNOW how to tackle complex issues with innovative approach to deliver the highest value. Our reputation has been built around one simple rule: we do not overpromise, WE DELIVER. We deliver to our employees, clients and partners. WE GROW as you grow, so investing in you is our business strategy. Caring for each other is our priority. WE CARE who you are, what you need, how you feel. WE CARE to smile, have fun and develop as human beings.

Why Choose GFT?
A culture of top performance
Deep tech IT engineering & consulting
1200 skilled & top-class experts
77% of the team are regular/senior
Products that contribute to a sustainable world
Competitive salary and benefits
Ambitious projects, trainings and tools you need to flourish
Google Cloud Partner of the Year - for going above and beyond for customers
What will you do?

Join a team responsible for developing enterprise-grade Java applications supporting critical business processes. You will design, develop, and test scalable solutions, participate in architecture discussions and code reviews, and contribute to delivering modern, high-quality software using Java and event-driven technologies.

We offer

Hybrid work in our client's office (Kraków) 3 days a week
Working in a highly experienced and dedicated team
Benefit package tailored to your needs (medical, sport, lunch subsidy, life insurance, etc.)
Online training and certifications
Access to e-learning platform
Social events

Szczegóły oferty
Rekrutacja online
  
Język rekrutacji: polski
  
Start ASAP
  
Praca zdalna przez 2 dni w tygodniu
  
Sprzęt
 Windows 
 Komputer: Notebook 
Udogodnienia w biurze
Darmowa kawa
Parking dla rowerów
Darmowe przekąski
Darmowe napoje
Darmowy parking
Szkolenia wewnętrzne
Benefity
Life insurance
Pakiet sportowy
Budżet na szkolenia
Prywatna opieka medyczna
Międzynarodowe projekty
O firmie GFT Technologies Poland 

Utworzona w:
2014

Wielkość firmy:
1000+

Lokalizacje:
Łódź + 4

17 400 – 26 700 PLN
brutto miesięcznie (UoP) 
oblicz netto
Aplikuj
Zapisz ofertę
Analiza CV
BETA

Oceń tę ofertę

😫
🙁
😐
🙂
😃
ZOBACZ PODOBNE OFERTY
Expert Java Consultant
26 040 – 34 440 PLN / mies.
Backend
Java
Spring Framework
Hibernate
 GFT Poland
Kraków
  
 Zapisz ofertę   
Java Developer
23 100 – 27 300 PLN / mies.
Backend
Java
Spring Framework
Hibernate
 Mindbox Sp. z o.o.
Kraków
 +1
  
 Zapisz ofertę   
Senior Java Engineer
30 000 – 42 000 PLN / mies.
Backend
Java
REST API
API
 1dea
Kraków
  
 Zapisz ofertę   
Senior Java Developer
20 160 – 26 880 PLN / mies.
Backend
Java
Kafka
Spring
 Moondigo Sp. z o.o.
Warszawa
 +5
  
 Zapisz ofertę   
Software Security Backend Engineer (Java)
25 200 – 29 400 PLN / mies.
Backend
Java
JVM
Spring
 Mindbox Sp. z o.o.
Kraków
  
 Zapisz ofertę   
Senior Java Developer
Sprawdź wynagrodzenie
Backend
Java
Microservices
Spring Boot
 Antal
Kraków
  
 Zapisz ofertę   
Expert Java Engineer
17 400 – 26 700 PLN / mies.
Backend
Java
Microservices
REST API
 GFT Poland
Kraków
  
 Zapisz ofertę   
Software Engineer (Java)
25 000 – 27 000 PLN / mies.
Backend
Java
REST API
SQL
 Keepit
Kraków
  
 Zapisz ofertę   
Senior Java Consultant
21 000 – 26 880 PLN / mies.
Backend
Java
Microservices
DevOps
 GFT Poland
Kraków
  
 Zapisz ofertę   
Expert Java Consultant
26 040 – 34 944 PLN / mies.
Backend
Java
Microservices
REST API
 GFT Poland
Kraków
  
 Zapisz ofertę   
Java
Backend
Kraków
Tech Lead Java Engineer
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria:
Backend
Java
Kraków
Adres e-mail 
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria *
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert i skorzystaj z dadatkowych benefitów:
100 złotych rabatu na księgowość w inFakcie

W każdej chwili możesz zrezygnować z subskrypcji

© No Fluff Jobs
Więcej


## Zrzut z aktywnej karty (30.09.2026)

Źródło: Chrome getTabContext; to nie jest potwierdzenie ręcznego Ctrl+A/Ctrl+C.
URL: https://www.pracuj.pl/praca/programista-programistka-czestochowa,oferta,1005077598?sug=oferta_bottom_bd_7
Tytuł: Oferta pracy Programista / Programistka, VentiAir Innvations sp. z o.o., Częstochowa
Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie

ważna jeszcze 8 dni

(do 08 paź)

Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
Prywatna opieka medyczna
Elastyczny czas pracy
Brak dress code’u
Kawa / herbata
Parking dla pracowników
VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań
Superoferta
.Net Developer
EUVIC S.A.
Katowice
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy
Pokaż więcej podobnych
15
Włącz powiadomienie

Programista / Programistka, Częstochowa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

## Clipboard: Oferta pracy Programista / Programistka, VentiAir Innvations sp. z o.o., Częstochowa

URL: https://www.pracuj.pl/praca/programista-programistka-czestochowa,oferta,1005077598?sug=oferta_bottom_bd_7
Metoda: Ctrl+A, Ctrl+C; schowek sprawdzony w karcie (3969 znaków). Ten zapis treści pochodzi z getTabContext.


Przejdź do treści ogłoszenia
Przejdź do panelu aplikowania
Przejdź do panelu bocznego
Przejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Programista / Programistka
VentiAir Innvations sp. z o.o.O firmie

ważna jeszcze 8 dni

(do 08 paź)

Częstochowaśląskie
umowa o pracę
pełny etat
specjalista / specjalistka (mid / regular)
praca stacjonarna, praca zdalna, praca hybrydowa
praca od zaraz
rekrutacja zdalna
Asystent Pracuj.pl

Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty

Zobacz
Dodatkowe informacje
Specjalizacje:
Backend
Wymagane języki:
angielski
Technologie, których używamy
Wymagane
.NET
ASP.NET
C#
System operacyjny
O projekcie
Praca polega na rozwoju wewnętrznego sytemu do kompleksowej obsługi procesów firmowych. Od konfiguratora produktów, ofert, zamówień po produkcję, rozliczenia serwis. Rozwój aplikacji mobilnej i innych systemów. Stanowisko jest samodzielne, jesteśmy otwarci na pomysły, innowacje, usprawnienia. Poszukujemy osoby ambitnej chcącej wdrożyć się w nasze rozwiązania. Do zadań należy również bieżące utrzymanie systemów, administracja, backupy itp.
Tak organizujemy naszą pracę
Tak pracujemy
wewnątrz organizacjirozwijasz kilka projektów jednocześniekoncentrujesz się na rozwoju produktu
Twój zakres obowiązków
rozwój wewnętrznego systemu firmy do kompleksowej obsługi procesów
bieżące utrzymanie infrastruktury informatycznej
backup, aktualizacje
administracja użytkownikami
Nasze wymagania
wykształcenie z zakresu informatyki
znajomość technologii .net, asp.net, html, sql
znajomość systemów rodziny Windows Server
umiejętność administracji urządzeniami sieciowymi
dokładność, sumienność, umiejętność współpracy w grupie
samodzielność, silna motywacja
zaangażowanie oraz dobra organizacja pracy
znajomość języka angielskiego
To oferujemy
Dużą samodzielność;
Pracę w stabilnej i dynamicznie rozwijającej się firmie
Atrakcyjne wynagrodzenie
Benefity
Prywatna opieka medyczna
Elastyczny czas pracy
Brak dress code’u
Kawa / herbata
Parking dla pracowników
VentiAir Innvations sp. z o.o.
Przewiń do profilu firmy
Jesteśmy producentem urządzeń wentylacyjnych oraz chłodniczych. Nasze produkty znajdują się w wielu budynkach użyteczności publicznej począwszy od domów jednorodzinnych (rekuperatory), aż po duże fabryki (centrale wentylacyjne). W związku z rozwojem Naszej firmy poszukujemy, programisty/administratora(ka) do naszego działu rozwoju.
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Praca
Częstochowa
IT - Administracja
Administrowanie systemami
Aplikuj szybko
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Starszy Programista lub Programistka .Net Najlepiej dopasowana
DIAGNOSTYKA S.A.
Kraków, Czyżyny
Superoferta
.NET Developer
ITP IT PERFORMANCE sp. z o.o.
120–145 zł netto (+ VAT) / godz.
Warszawa
.NET Developer
Nexus Polska Sp. z o.o.
10 000–18 000 zł / mies. (zal. od umowy)
Poznań
Superoferta
.Net Developer
EUVIC S.A.
Katowice
Junior Automation Consultant C# (k/m) Śpiesz się!
benett PEOPLE
Warszawa
Superoferta
Backend .NET Developer
TeamQuest Sp. z o.o.
18 000–23 000 zł netto (+ VAT) / mies.
Warszawa
.NET Developer
Eurotronic Sp. z o.o.
Warszawa, Włochy
Pokaż więcej podobnych
15
Włącz powiadomienie

Programista / Programistka, Częstochowa

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty

Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.




## Clipboard: Oferta pracy Senior Java Microservices Developer – Banking Technology

URL: https://www.pracuj.pl/praca/senior-java-microservices-developer-banking-technology-warszawa,oferta,1005124568?sug=list_top_cr_bd_1_boosterAI_L0&s=1f7c2c91&searchId=MTc5MDc2NDE0OTAyMS4zOTM4
Metoda: Ctrl+A, Ctrl+C; clipboard text odczytany i zweryfikowany (8264 znaki).

Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki

Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia


Moje konto
DLA FIRM
Dodaj ogłoszenie

New
Senior Java Microservices Developer – Banking Technology
ITDS Polska Sp. z o.o.About the company
valid for a month

(to 29 Oct)


18 900 – 23 100 zł
net (+ VAT) / mth. | B2B contract
Company location:
WarszawaMasovian
Workplace:
Whole Poland (remote work)
b2b contract
full-time
senior specialist (senior)
home office work
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Additional information
Specializations:
Backend
Required languages:
English, Polish
Technologies we use
Expected
Java
REST APIs
microservices
RabbitMQ
Git
Maven
Jenkins
OpenShift
Agile
CI/CD
Optional
Domain-Driven Design (DDD)
AI tools
cloud technologies
About the project
As a Senior Java Developer / Technical Lead, you will be working for our client, a leader in the financial services industry dedicated to transforming credit processes for corporate clients. You will play a pivotal role in building and enhancing a critical application that supports decision-making across banking, leasing, and factoring services, leveraging modern microservices architecture to deliver innovative solutions with a significant impact on millions of financial transactions. Join us to push the boundaries of banking technology and accelerate your career growth.
Your responsibilities
Lead the design and development of scalable, event-driven microservices within the CLP credit workflow application.
Collaborate with cross-functional teams in an Agile environment to ensure the high-quality delivery of system features.
Define, implement, and enforce standards for code quality, testing, and code reviews.
Mentor and guide less experienced developers, fostering technical excellence within the team.
Implement and optimize CI/CD pipelines using tools such as Git, Maven, Jenkins, and OpenShift.
Develop and maintain integrations with external systems via REST APIs and asynchronous messaging with RabbitMQ.
Leverage domain-driven design (DDD) principles and incorporate AI tools for SDLC efficiency.
Ensure the system’s architecture adheres to best practices in security, performance, and scalability.
Our requirements
Minimum of 5 years’ experience in back-end development, especially in Java.
Deep expertise in RESTful API design and implementation.
Practical knowledge of distributed system architecture and microservices design.
Hands-on experience with messaging systems, particularly RabbitMQ.
Proficiency with DevOps tools: Git, Maven, Jenkins, and OpenShift.
Strong analytical skills with the ability to solve complex technical problems.
Experience working in Agile and CI/CD environments.
Optional
Knowledge of Domain-Driven Design (DDD).
Experience with AI tools integration into SDLC processes.
Certifications in cloud or related technologies.
What we offer
Stable and long-term cooperation with very good conditions
Enhance your skills and develop your expertise in the financial industry
Work on the most strategic projects available in the market
Define your career roadmap and develop yourself in the best and fastest possible way by delivering strategic projects for different clients of ITDS over several years
Participate in Social Events, training, and work in an international environment
Access to attractive Medical Package
Access to Multisport Program
Access to Pluralsight
Flexible hours
Benefits
Sharing the costs of sports activities
Private medical care
Flexible working time
Fruits
Integration events
Corporate gym
Saving & investment scheme
No dress code
Coffee / tea
Drinks
Christmas gifts
Birthday celebration
Sharing the costs of a streaming platform subscription
Access to +100 projects
Access to Pluralsight

Recruitment stages
1
first online interview

2
second online interview

#MAKEYourCareerBETTER
Interested? Apply now and include your CV (preferably in English) along with a statement confirming your consent to the processing and storage of your personal data.
ITDS Polska Sp. z o.o.
Scroll to company's profile
ITDS supports financial service providers to take the next steps.
We identify what’s possible, every day. Opportunities in the areas of technology, organization, and digitization.
We see where banks, insurers, payment companies, or fintech can go and how they can get there.
That’s why we want to stimulate you to ramp up your ambition. Forget what you perceive as restraints and step towards the new reality.
ITDS in Poland - Pure player in new Technologies & Financial Industry
+300 IT implementation professionals
+20 clients in the Banking, Insurance, Payment & Fintech Industry
ITDS excels in digital strategy delivery and implementation of best-of-breed lending solutions. ITDS has delivered successful strategic projects throughout Europe since 1998. We combine the experience we’ve accumulated with in-depth knowledge of technologies, business processes, and EU legislation to unlock new business opportunities.
This is how we work

10185
Aplikuj

Zapisz

Drukuj

Udostępnij
Informujemy, że administratorem danych jest ITDS z siedzibą w Warszawie, ul. Złota 59 (dalej jako "administrator"). Masz prawo do żądania dostępu do swoich danych osobowych, ich sprostowania, usunięcia lub ograniczenia przetwarzania, prawo do wniesienia sprzeciwu wobec przetwarzania, a także prawo do przenoszenia danych oraz wniesienia skargi do organu nadzorczego. Dane osobowe przetwarzane będą w celu realizacji procesu rekrutacji. Podanie danych w zakresie wynikającym z ustawy z dnia 26 czerwca 1974 r. Kodeks pracy jest obowiązkowe. W pozostałym zakresie podanie danych jest dobrowolne. Odmowa podania danych obowiązkowych może skutkować brakiem możliwości przeprowadzenia procesu rekrutacji. Administrator przetwarza dane obowiązkowe na podstawie ciążącego na nim obowiązku prawnego, zaś w zakresie danych dodatkowych podstawą przetwarzania jest zgoda. Dane osobowe będą przetwarzane do czasu zakończenia postępowania rekrutacyjnego i przez okres możliwości dochodzenia ewentualnych roszczeń, a w przypadku wyrażenia zgody na udział w przyszłych postępowaniach rekrutacyjnych - do czasu wycofania tej zgody. Zgoda na przetwarzanie danych osobowych może zostać wycofana w dowolnym momencie. Odbiorcą danych jest serwis Hello HR oraz inne podmioty, którym powierzyliśmy przetwarzanie danych w związku z rekrutacją.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
IT - Administracja
Administrowanie bazami danych i storage
Aplikuj

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:

Superoferta
Senior Java Developer – AI Integration and Microservices
ITDS Polska Sp. z o.o.
21 000–22 785 zł / mies. (zal. od umowy)
Warszawa

Superoferta
Calypso Developer Tu zarobisz najwięcej!
VISTULO sp. z o.o.
220–250 zł netto (+ VAT) / godz.
Warszawa

Software Engineer Senior Najlepiej dopasowana
FIS Technology Services Poland Sp. z o.o.
13 800–19 500 zł brutto / mies.
Warszawa, Wola

Full-stack Developer (Java, Angular)
Capgemini Polska
Warszawa, Włochy

Superoferta
Senior Java Software Engineer
Sportradar Polska Sp. z o.o.
Warszawa, Wola

Superoferta
Fullstack Mobile Developer (Kotlin) (m/k)
Integral Solutions
Warszawa

Superoferta
Ekspert Programista (Java / Spring Boot) - K/M Wyprzedź innych kandydatów
B2B.NET S.A.
110–130 zł netto (+ VAT) / godz.
Warszawa

Pokaż więcej podobnych
16
Włącz powiadomienie
Senior Java Microservices Developer – Banking Technology, Warszawa


Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty









Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.


## Clipboard: Oferta pracy Magazynier / Magazynierka, UniGast S.A.

URL: https://www.pracuj.pl/praca/magazynier-magazynierka-warszawa,oferta,1005062473?sug=oferta_bottom_bd_2
Metoda: Ctrl+A, Ctrl+C; clipboard text odczytany i zweryfikowany (3169 znaków).

Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki

Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
DLA FIRM
Dodaj ogłoszenie


Magazynier / Magazynierka
UniGast S.A.O firmie
ważna jeszcze dzień

(do 01 paź)


Warszawamazowieckie
umowa o pracę, umowa zlecenie, umowa o pracę tymczasową
pełny etat, część etatu, dodatkowa / tymczasowa
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
praca od zaraz
pracodawca nie wymaga cv
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Tryb wypłaty:
miesięczna
Twój zakres obowiązków
Zatrudniona osoba będzie wykonywała pracę w charakterze magazyniera i będzie odpowiedzialna za:
Kompletowanie zamówień do klientów
Przyjmowanie dostaw do magazynu
Utrzymanie porządku w magazynie
Nasze wymagania
Umiejętność pracy w zespole
Punktualność, dyspozycyjność, uczciwość, samodzielność
Mile widziane
Uprawnienia na wózki widłowe
To oferujemy
Stabilne warunki zatrudnienia w dużej polskiej firmie
Terminowe wypłaty wynagrodzenia
Pracę w młodym i zgranym zespole
Motywacyjny system wynagrodzenia
Benefity
Ubezpieczenie na życie

Aplikuj szybko

Zapisz

Drukuj

Udostępnij
„Wyrażam zgodę na przetwarzanie danych osobowych zawartych w mojej ofercie pracy dla potrzeb niezbędnych do realizacji procesu rekrutacji prowadzonego przez UniGast S.A.. z siedzibą w Warszawie zgodnie z ustawą z dnia 29 sierpnia 1997 r. o ochronie danych osobowych (tj. Dz. U. z 2014 r. poz. 1182, 1662)”.

Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz  tutaj.

Praca
Warszawa
Praca fizyczna
Kurierzy / Dostawcy
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:

Superoferta
Magazynier/ka Śpiesz się!
Steriscience Sp. z o.o.
Warszawa

Superoferta
Magazynier (k/m) Hit!
Mennica Polska S.A.
6 500 zł brutto / mies.
Warszawa, Białołęka

Magazynier / Magazynierka Najlepiej dopasowana
HEBAR SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ
Warszawa

Magazynier - kompletacja (k/m)
BAG-POL ADAM GOŹDZICKI, BARBARA GOŹDZICKA SPÓŁKA KOMANDYTOWA
5 500–8 300 zł brutto / mies.
Warszawa, Włochy

Superoferta
Magazynier (K/M)
Franke Polska Sp. z o.o.
Sękocin Nowy (pow. pruszkowski)

Superoferta
Magazynier / Magazynierka
Job Impulse Polska Sp. z o.o.
od 37 zł brutto / godz.
Warszawa

Magazynier
MANTA S.A.
Warszawa, Targówek

Pokaż więcej podobnych
16
Włącz powiadomienie
Magazynier / Magazynierka, Warszawa



Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty









Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

## Clipboard: Oferta pracy Kucharz śniadaniowy / Kucharka śniadaniowa, SUKCES sp. z o.o.

URL: https://www.pracuj.pl/praca/kucharz-sniadaniowy-kucharka-sniadaniowa-warszawa-zwyciezcow-49,oferta,1005073905?sug=list_top_cr_bd_12&s=1f7c2c91&searchId=MTc5MDc2NDE0OTAyMS4zOTM4
Metoda: Ctrl+A, Ctrl+C; clipboard text odczytany i zweryfikowany (4335 znaków).

Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki

Oferty pracy

Pобота
Profile pracodawców
Porady i narzędzia



Moje konto
DLA FIRM
Dodaj ogłoszenie
Kucharz śniadaniowy / Kucharka śniadaniowa
SUKCES sp. z o.o.O firmie
ważna jeszcze 5 dni

(do 05 paź)


40,00 – 50,00 zł
brutto / godz. | umowa zlecenie
Zwycięzców 49, Praga-Południe, Warszawamazowieckie
umowa zlecenie
pełny etat
pracownik fizyczny / pracowniczka fizyczna
praca stacjonarna
praca od zaraz
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje

Podsumowanie oferty


Zobacz
Dodatkowe informacje
Praca zmianowa:
tak
Godziny pracy:
7:00-15:00
Możliwa praca w godzinach nocnych:
nie
Tryb wypłaty:
miesięczna
System wynagrodzeń:
stała podstawa wynagrodzenia + premia za wyniki

Więcej szczegółów
Siedziba firmy
SUKCES sp. z o.o.

Zwycięzców 49, Praga-Południe, Warszawa

Sprawdź czas dojazdu


Zlokalizuj się lub podaj dokładny adres
Samochód
-
Komunikacja
-
Rower
-
Pieszo
-

Twój zakres obowiązków
Zakres obowiązków:
• samodzielne przygotowywanie śniadań i dań z karty zgodnie z recepturami i standardami lokalu
• przygotowywanie produktów do serwisu – mise en place
• dbanie o estetykę i powtarzalność wydawanych dań
• organizacja pracy kuchni podczas serwisu
• przygotowywanie śniadan, sosów, dodatków i innych elementów menu
• kontrolowanie jakości i świeżości produktów
• dbanie o prawidłowe przechowywanie żywności i przestrzeganie zasad HACCP
• kontrolowanie stanów magazynowych i zgłaszanie zapotrzebowania na produkty
• utrzymywanie porządku i czystości na stanowisku pracy oraz w kuchni
• racjonalne gospodarowanie produktami i ograniczanie strat
• współpraca z zespołem sali oraz pozostałymi pracownikami lokalu
• dbanie o sprzęt kuchenny i prawidłowe korzystanie z urządzeń
• udział w tworzeniu i rozwijaniu oferty śniadaniowej
Nasze wymagania
• doświadczenie przy kuchni śniadaniowej
• samodzielność i dobra organizacja pracy
• umiejętność sprawnego przygotowywania dań podczas intensywnego serwisu
• znajomość podstawowych technik kulinarnych
• dbałość o smak, jakość i estetykę wydawanych dań
• umiejętność pracy według receptur i standardów lokalu
• znajomość zasad higieny i bezpieczeństwa żywności
• odpowiedzialność za powierzone stanowisko i produkty
• punktualność, zaangażowanie i pozytywne nastawienie do pracy
• umiejętność pracy w zespole
• aktualna książeczka sanepidowska / orzeczenie do celów sanitarno-epidemiologicznych lub gotowość do jej wyrobienia
• dyspozycyjność do pracy w systemie 2/2 po 8 h
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Praca
Warszawa
Hotelarstwo / Gastronomia / Turystyka
Katering / Restauracje / Gastronomia
Aplikuj szybko

Zapisz

Drukuj

Udostępnij
Sprawdź podobne oferty:
Kucharz / Kucharka Tu zarobisz najwięcej!
MOTTO sp. z o.o.
7 000–10 000 zł brutto / mies.
Warszawa, Śródmieście

Kucharz / Kucharka Hit!
RESTRO sp. z o.o.
42–46 zł / godz. (zal. od umowy)
Warszawa, Wola

Superoferta
Kucharz/ Kucharka (śniadania) Śpiesz się!
Royal Tulip Warsaw Centre
Warszawa, Wola

Kucharz śniadaniowy - kuchnia zimna
VARSOWICZ sp. z o.o.
31,50–35 zł brutto / godz.
Warszawa, Śródmieście

Superoferta
Kucharz do grupy sen Najlepiej dopasowana
SEN WARSAW
Warszawa

Kucharz / Kucharka (kuchnia gorąca)
2F2 sp. z o.o.
31,40–40 zł / godz. (zal. od umowy)
Warszawa, Wola

Kucharz / Kucharka Wyprzedź innych kandydatów
PRZEDSIĘBIORSTWO HANDLOWE AMD S.C.
od 45 zł brutto / godz.
Wołomin

Pokaż więcej podobnych
16
Włącz powiadomienie
Kucharz śniadaniowy / Kucharka śniadaniowa, Zwycięzców 49, Praga-Południe, Warszawa

Chcesz dowiedzieć się więcej o firmie?
Zobacz pełny profil firmy

Dla kandydatów

Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT

Narzędzia

Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop

Dla firm

Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR

Grupa Pracuj

O nas
Centrum Prasowe
Reklama
Partnerzy

Nasze produkty









Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.

## Clipboard: OLX Amazon magazyn, Randstad Polska (Trzebnica)

URL: https://www.olx.pl/oferta/praca/amazon-38-52-zl-godz-brutto-2200-brutto-CID4-ID1ceE1l.html?search_reason=search%7Corganic
Metoda: Ctrl+A, Ctrl+C; clipboard text odczytany i zweryfikowany (8475 znaków).

Przejdź do głównej części
Przejdź do stopki
Czat
Twoje konto
Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaPrace magazynowePrace magazynowe - DolnośląskiePrace magazynowe - Trzebnica
Dodane dzisiaj o 12:11
Amazon | 38,52 zł/godz. brutto* | +2200 brutto**
Randstad Polska Sp. z o.o. Dowiedz się więcej
LOKALIZACJA
Trzebnica
WYMIAR PRACY
Pełny etat
TYP UMOWY
Umowa o pracę
LOKALIZACJA
Trzebnica
OPIS
Poszukujemy pracowników na stanowisko pracownika magazynu w Bielanach Wrocławskich k. Wrocławia.
Centrum Logistyki Amazon, podwyższa stawkę! Pracuj i zyskaj więcej, bo to Twoja zmiana i Twoja nowa, wyższa stawka godzinowa 38,52 zł/godz. brutto*
Oprócz tego możesz liczyć na +2200 zł brutto** ekstra. Poleć znajomych do pracy, Ty i osoba polecona zyskacie wspólnie do 5000 zł brutto***!
Nie wymagamy od Ciebie doświadczenia. Możesz liczyć na wsparcie wyspecjalizowanych instruktorów.
zadania
rozkładanie towarów na półki magazynu
załadunek i rozładunek przesyłek
kompletowanie, pakowanie i przygotowywanie towaru do wysyłki
obsługa skanera ręcznego
oczekujemy
gotowości i zdolności do pracy w trybie zmianowym - na zmianie dziennej i nocnej
braku przeciwwskazań do stania/chodzenia przez 10 godzin
sumienności i skrupulatności w wykonywaniu obowiązków
oferujemy
stawkę do 38,52 zł/godz. brutto*
+2200 brutto** ekstra
bonus za polecenie - poleć do pracy swojego znajomego i otrzymajcie razem bonus w wysokości do 5000 zł**
dodatek za pracę w godzinach nocnych
praca 4 dni w tygodniu, 3 dni wolnego (praca w pełnym wymiarze godzin)
umowę o pracę tymczasową (ze składką ZUS i płatnymi urlopami)
pakiet RANDSTAD PLUS, karta sportowa Medicover Sport, pakiet medyczny Medicover oraz rabaty
długą, stabilną, rozwijającą współpracę
gorące napoje i obiady z pysznym i różnorodnym menu za złotówkę
bezpłatny dojazd autobusem pracowniczym na wybranych trasach
Zaaplikuj lub zadzwoń na nr 22 454 44 44 lub +488*****777 (numer bezpłatny)
*Suma podstawowej stawki godzinowej oraz premii specjalnej za frekwencję.
**Szczegóły podczas rekrutacji.
***zgodnie z regulaminem dostępnym na stanowisku Randstad. Agencja zatrudnienia – nr wpisu 47
ta oferta pracy przeznaczona jest dla osób powyżej 18 roku życia
Aplikuj teraz
ID: 1096939299
Zgłoś
O FIRMIE
Randstad Polska Sp. z o.o.
Partner for talent.
Branża
Zasoby Ludzkie i Rekrutacja
Wielkość firmy
751-1000
Lokalizacja
Warszawa
Randstad Polska jest częścią Randstad N.V. – najbardziej wyspecjalizowanej firmy na świecie działającej na rzecz talentów, która dba o wyrównywanie szans.
Działając w ramach czterech specjalizacji – Operational, Professional, Digital i Enterprise – zapewniamy firmom wykwalifikowane, zróżnicowane i elastyczne zespoły.
Poszukujących zatrudnienia wspieramy w zdobywaniu ważnych dla nich ról zawodowych, rozwoju właściwych kompetencji.
W Randstad pomożemy Ci znaleźć pracę, która odpowiada Twoim kwalifikacjom, wspiera równowagę między życiem zawodowym a prywatnym i Twoje cele.
Współpracujemy z najlepszymi pracodawcami na rynku, zapewniając szerszy dostęp do całej gamy możliwości.
Naszym priorytetem jest pozostawanie z Tobą w relacji na każdym etapie Twojego życia zawodowego.
Pokaż więcej
Zobacz profil pracodawcy
REKRUTER
Randstad Polska Sp. z o.o.
Na OLX od wrzesień 2017
Ostatnio online w dniu 28 września 2026
Zadzwoń / SMS
Aplikuj teraz
Zobacz profil pracodawcy
Więcej od tego ogłoszeniodawcy
Zobacz wszystkie
praca na produkcji > SZYBKI START > do 5700 zł brutto >BEZ DOŚWIADCZENIA
Pracownik Wsparcia Działu Agronomii (K/M/N)
praca na produkcji > OD Zaraz> Bezpośrednio> wolne weekendy
Praca na magazynie Yusen - do 5500 zł - Kąty Wrocławskie - 2 zmiany
pracownik produkcji (k/m) | wolne weekendy | 1 lub 2 zmiany | Dobczyce
magazynier z UDT lub kat.B (k/m) > Radom
Praca na produkcji> zatrudnienie bezpośrednie
Amazon | 38,52 zł/godz. brutto* | +2200 brutto**
Amazon! Новая ставка до 38,52 зл/час брутто* | +2200 зл** бонуса
Zlecenie związane z wykładaniem towaru w Trzebnicy
Magazynier z doświadczeniem SKLEPCARAUDIO PL
Pracownik sklepu Żabka
Praca Specjalista / Specjalistka Obsługi Klienta Stacja Paliw bp Wisznia Mała
Magazynier do hurtowni w Krzykach
Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Darmowa aplikacja na Twój telefon
OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl

## Clipboard: OLX doradca klienta, salon drzwi i podłóg (Oświęcim)

URL: https://www.olx.pl/oferta/praca/doradca-klienta-salon-sprzedazy-drzwi-i-podlog-CID4-ID19JzoE.html?search_reason=search%7Cpromoted
Metoda: Ctrl+A, Ctrl+C; clipboard text odczytany i zweryfikowany (3775 znaków).

Przejdź do głównej części
Przejdź do stopki
Czat
Twoje konto
Dodaj ogłoszenie
Dla biznesu
Strona głównaPracaSprzedażDoradca klienta, sprzedawcaDoradca klienta, sprzedawca - MałopolskieDoradca klienta, sprzedawca - Oświęcim
Dodane 24 września 2026
DORADCA KLIENTA - Salon sprzedaży drzwi i podłóg
WYNAGRODZENIE
5 000 - 10 000 zł / mies. brutto
LOKALIZACJA
Oświęcim
WYMIAR PRACY
Pełny etat
TYP UMOWY
Umowa o pracę
LOKALIZACJA
Oświęcim
OPIS
Jesteśmy salonem sprzedaży drzwi i podłóg działającym głównie na lokalnym rynku. Poszukujemy do naszego zespołu osoby ambitnej i kreatywnej, która jest gotowa związać się z nami na dłuższy okres czasu, niewykluczone na stałe.
Co oferujemy naszym pracownikom :
Zatrudnienie w oparciu o umowę o pracę (pierwsze 3 miesiące umowa zlecenie)
Stabilny system wynagradzania: płacę podstawową + premię uzależnioną od osiąganych wyników sprzedażowych,
Program szkoleń produktowych i sprzedażowych, stacjonarnych jak i wyjazdowych, które ułatwią wdrożenie się na nowym stanowisku,
Pracę w zespole fachowców i specjalistów, którzy służą pomocą w każdej sytuacji i postarają się przekazać jak największą porcję wiedzy nowemu pracownikowi,
Elastyczny grafik pracy i w miarę naszych możliwości dopasowany do potrzeb pracownika
Czego oczekujemy od naszych pracowników :
Umiejętności komunikacyjnych i interpersonalnych - najważniejsza cecha każdego handlowca
Komputer nie może być Ci obcy, pracujemy na licznych systemach zamówień oraz wykonujemy dziennie szereg wycen
Odporności na stres, bo jak wiadomo życie handlowca do łatwych nie należy i czasami trzeba zaparzyć kubek melisy ;)
Znajomość asortymentu z branży drzwi i podłogi jest warunkiem koniecznym.
Wymagamy min. rocznego doświadczenia na podobnym stanowisku.
Czym będziesz się zajmował :
Obsługa klientów w specjalistycznym salonie wykończenia wnętrz,
Doradztwo techniczne w temacie dostępnego w salonie asortymentu,
Prowadzenie dokumentacji sprzedażowej - sporządzanie umów z klientami, wystawianie faktur,
Dbanie o porządek w miejscu pracy oraz o estetykę i czystość ekspozycji
Bardzo prosimy o kontakt mailowy - zostaw nam swoje CV. Odezwiemy się do wybranych kandydatów i zaprosimy na rozmowę.
Aplikuj
ID: 1059980684
Zgłoś
Masz pytanie do pracodawcy odnośnie tej oferty?
Zadaj pytanie
REKRUTER
Justyna
Na OLX od styczeń 2018
Ostatnio online w dniu 24 września 2026
Zadzwoń / SMS
Aplikuj
Zobacz też
Kasjer-Sprzedawca (m/k) - Oświęcim
Agata S.A.
Oświęcim
Pełny etat
Umowa o pracę
Praca na produkcji Jedna Zmiana 7-15
5 800 - 8 000 zł / mies. brutto
Oświęcim
Pełny etat
Umowa o pracę
Praca w firmie ogrodniczej
Brzeszcze
Pełny etat
Umowa o pracę, Umowa zlecenie
Specjalista ds. Obsługi Klienta / Back Office – Oświęcim
5 600 - 7 300 zł / mies. brutto
Oświęcim
Pełny etat
Specjalista/Specjalistka ds. obsługi klienta
Honesta Market Service
4 900 - 5 500 zł / mies. brutto
Oświęcim
Pełny etat
Placek i Skórka - KUCHARZ/PIZZER
35 - 60 zł / godz. brutto
Brzeszcze
Pełny etat
Umowa o pracę, Umowa zlecenie
Aplikacje mobilne OLX.pl
Pomoc
Wyróżnione ogłoszenia
Oferta dla firm
Blog
Regulamin
Polityka prywatności
Reklama
Informacja o realizowanej strategii podatkowej
Ustawienia plików cookie
Zasady bezpieczeństwa
Mapa kategorii
Mapa miejscowości
Mapa ministron
Popularne wyszukiwania
Kariera
Pracodawcy na OLX
Jak działa OLX.pl
Cennik
Zawodowo OLX - serwis o pracy
Polityka cookies
Darmowa aplikacja na Twój telefon
OLX.bg
OLX.ro
OLX.ua
OLX.pt
Otodom.pl
Otomoto.pl
obido.pl

## Clipboard: No Fluff Jobs — Analityk Systemowy (k/m), Finture

URL: https://nofluffjobs.com/pl/job/analityk-systemowy-k-m-finture-warszawa-1
Metoda: Ctrl+A, Ctrl+C; clipboard text odczytany i zweryfikowany (6910 znaków).

OFERTY PRACY
PROFILE FIRM
KALKULATOR WYNAGRODZEŃ
NEW
DLA PRACODAWCY
CENNIK
PUBLIKUJ
ZALOGUJ SIĘ
Powrót do wyszukiwania
Business Analysis
Warszawa
Analityk Systemowy (k/m)
Analityk Systemowy (k/m)
Finture Sp. z o.o
Kategoria:
Business Analysis
Mid
Hybrydowo
+2
Lokalizacje:
Warszawa, ul. Skierniewicka 10A
Lublin 40% stacjonarnie, 60% zdalnie
Oferta ważna do: 16.10.2026 (zostało 16 dni)
Obowiązkowe
Analiza systemowa
Analityka
Sektor Bankowy
AS-IS
Logi aplikacyjne
Komunikatywność
Polski (C1)
Opis wymagań
minimum 3 lata doświadczenia w roli analityka
minimum 2 lata doświadczenia analitycznego zdobytego w projektach rozwojowych w sektorze bankowym
umiejętność zbierania i analizy wymagań biznesowych oraz technicznych, zarówno funkcjonalnych, jak i pozafunkcjonalnych
doświadczenie w analizie procesów AS-IS oraz analizie systemowej wprowadzanych zmian
praktyka w samodzielnym tworzeniu dokumentacji technicznej
umiejętność czytania i analizowania logów aplikacyjnych
swobodna komunikacja z interesariuszami po stronie biznesu i IT
samodzielność w organizacji własnej pracy i odpowiedzialność za rezultat
Znajomość języka polskiego na poziomie C1
Zakres obowiązków
projektowanie architektury logicznej oraz komponentów systemowych, z uwzględnieniem wymagań pozafunkcjonalnych
analiza wymagań biznesowych i przełożenie ich na analizę systemową umożliwiającą rozwój zmian w aplikacji
badanie i opisywanie istniejących rozwiązań w modelu AS-IS
projektowanie i opisywanie integracji między systemami oraz standardów wymiany danych
tworzenie specyfikacji rozwiązań, modeli logicznych oraz dokumentacji technicznej i eksploatacyjnej
przygotowywanie konfiguracji aplikacji oraz bieżąca współpraca z administratorami aplikacji
pokaż wszystko (8)
Opis oferty
Dla naszego Klienta z branży bankowej poszukujemy Analityka Systemowego / Analityczki Systemowej do zespołu rozwijającego aplikację bankowości elektronicznej.
Zatrudnienie ramach grupy kapitałowej – przez spółkę Exorigo-Upos.
Praca hybrydowa w wymiarze 2 dni w tygodniu z biura w Warszawie lub Lublinie.
Oferujemy:
Pracę w renomowanej organizacji (ITwiz BEST100), działającej w oparciu o międzynarodowe standardy jakości i bezpieczeństwa (ISO 9001, ISO 27001)
Niekorporacyjną atmosferę i płaską strukturę organizacyjną
Możliwość ciągłego rozwoju poprzez:
pracę z wykorzystaniem różnorodnych technologii w projektach dla renomowanych klientów
współpracę z doświadczonym zespołem ekspertów, którzy chętnie dzielą się wiedzą
dofinansowanie do szkoleń i certyfikatów
Program Poleceń Pracowniczych
Kulturę organizacyjną opartą na wartościach:
działamy z dobrą intencją
dzielimy się wiedzą
bierzemy odpowiedzialność
stale się doskonalimy
ludzie są dla nas najważniejsi
działamy, znając cel i sens naszej pracy
komunikujemy się szczerze i profesjonalnie
Udział w inicjatywach dobroczynnych, w tym współpracę z Fundacja im. Joanny Radziwiłł "Opiekuńcze Skrzydła"
Różnorodne i inkluzywne środowisko pracy – współpracują przedstawiciele czterech pokoleń
Równe szanse rozwoju – 50% stanowisk menedżerskich i liderskich zajmują kobiety
Szczegóły oferty
Rekrutacja online
Start ASAP
Praca zdalna przez 3 dni w tygodniu
Kroki w procesie rekrutacyjnym
selekcja CV
rozmowa rekrutacyjna
oferta
Benefity
Pakiet sportowy
Budżet na szkolenia
Prywatna opieka medyczna
Integration events
English lessons
Płaska struktura
O firmie Finture
Utworzona w: 2016
Wielkość firmy: +120
Siedziba: 01 -230 Warszawa
FINTURE to dynamiczny i ambitny zespół tworzący rozwiązania informatyczne, odpowiadające aktualnym trendom rynkowym – głównie w sektorze finansowym i ubezpieczeniowym.
BAZUJEMY na szerokim wachlarzu technologii i narzędzi.
DBAMY o właściwą komunikację projektową.
WSPIERAMY naszych klientów na każdym etapie projektowym: koncepcji, doboru technologii, planowania, dewelopmentu, testowania, utrzymania produkcyjnego i wsparcia serwisowego.
X XXX - XX XXX PLN
Sprawdź, czy wynagrodzenie Ci pasuje
B2B netto
> 4 000 PLN
> 4 500 PLN
> 5 000 PLN
> 5 500 PLN
> 6 000 PLN
> 7 000 PLN
> 8 000 PLN
> 9 000 PLN
> 10 000 PLN
> 12 000 PLN
> 14 000 PLN
> 16 000 PLN
> 18 000 PLN
> 20 000 PLN
> 22 000 PLN
> 24 000 PLN
> 26 000 PLN
> 28 000 PLN
> 30 000 PLN
> 33 000 PLN
> 36 000 PLN
> 39 000 PLN
> 42 000 PLN
> 45 000 PLN
> 50 000 PLN
> 60 000 PLN
> 70 000 PLN
> 80 000 PLN
> 90 000 PLN
> 100 000 PLN
Dokładne widełki poznasz przed pierwszą rozmową.
Poznaj funkcję
Aplikuj
Zapisz ofertę
Analiza CV BETA
Oceń funkcję Salary Match
😫 🙁 😐 🙂 😃
ZOBACZ PODOBNE OFERTY
Analityk Biznesowy (k/m) | kredyty hipoteczne
IT Business Analyst (K/M) 18 480 – 21 000 PLN / mies. ASTEK Polska
Analityk Systemowy/Analityczka Systemowa - obszar kart i płatności (f/m/x) 19 000 – 21 600 PLN / mies. Sii Polska
IT Business Analyst (K/M) K/M 13 000 – 14 600 PLN / mies. ASTEK Polska
Analityk Biznesowy (K/M) 21 840 – 25 200 PLN / mies. Antal
Analityk biznesowy (modelowanie procesów, API) (K/M) 19 950 – 22 890 PLN / mies. ASTEK Polska
Ekspert ds. Transformacji Cyfrowej (k/m/d) Generali Polska
System Analyst – sektor bankowy (f/m/x) 18 000 – 23 000 PLN / mies. Sii Polska
Salesforce Business Analyst (f/m/x) 26 000 – 30 000 PLN / mies. Sii Polska
Analityk Systemowy 22 680 – 23 856 PLN / mies. AVENGA
OTRZYMUJ DOPASOWANE OFERTY PRACY
Twoje kryteria: Business Analysis Warszawa
Adres e-mail
Subskrybuj
Chcę otrzymywać nowe oferty pracy spełniające wybrane kryteria
Chcę otrzymywać informacje o wynagrodzeniach, trendach i innych ofertach IT
Załóż konto lub subskrypcję ofert
100 złotych rabatu na księgowość w inFakcie
W każdej chwili możesz zrezygnować z subskrypcji
© No Fluff Jobs
Więcej

## Clipboard: Pracuj.pl Senior Java Developer – AI Integration and Microservices (ITDS)

URL: https://www.pracuj.pl/praca/senior-java-developer-ai-integration-and-microservices-warszawa,oferta,1005094773
Metoda: Ctrl+A, Ctrl+C; clipboard text odczytany i zweryfikowany (9567 znaków).

Przejdź do treści ogłoszeniaPrzejdź do panelu aplikowaniaPrzejdź do panelu bocznegoPrzejdź do stopki
Oferty pracy
Pобота
Profile pracodawców
Porady i narzędzia
Moje konto
DLA FIRM
Dodaj ogłoszenie
Senior Java Developer – AI Integration and Microservices
ITDS Polska Sp. z o.o.About the company
valid for 15 days
(to 15 Oct)
21 000 – 22 785 zł
net (+ VAT) / mth. | B2B contract
WarszawaMazowieckie
contract of employment, b2b contract
full-time
senior specialist (senior)
hybrid work
immediate employment
remote recruitment
Asystent Pracuj.pl
Sprawdź, jak dobrze ta oferta do Ciebie pasuje
Podsumowanie oferty
Zobacz
Additional information
Specializations:
Backend
Required languages:
Polish
Technologies we use
Expected
Java
Spring Framework
Spring Boot
Git
Oracle
PostgreSQL
JUnit
Spock
Optional
Angular
About the project
As a Senior Java Developer – AI Integration and Microservices, you will be working for our client, a leader in the insurance industry, committed to revolutionizing claims management. You'll contribute to building scalable, enterprise-grade backend solutions and intelligent automation systems that transform traditional workflows, enhance operational excellence, and deliver exceptional customer experiences. This role offers a strategic opportunity to grow within a forward-thinking organization at the forefront of insurance technology innovation.
Unleash the future of enterprise solutions—drive innovation with advanced backend development and AI-powered automation!
Location & Work Model: Warsaw-based opportunity with a hybrid work model (up to 4 remote days per week).
Only candidates with a valid legal right to work in the European Union will be considered.
This is how we organize our work
This is how we work
at the client's site
Your responsibilities
Design, develop, and maintain high-quality Java services (Java 8/11/17/21) and Spring Boot frameworks aligned with claims management business needs
Collaborate with cross-functional teams to ensure seamless integration and delivery of scalable microservices solutions
Participate in code reviews, testing, and documentation to uphold high software quality standards
Implement architectures based on DDD, CQRS, Hexagonal Architecture, and EDA to support robust, event-driven microservices ecosystems
Utilize containerization and orchestration tools such as Kubernetes for deployment efficiency
Develop and integrate AI-enabled components including automation, classification, and information extraction modules
Contribute actively to Agile/Scrum teams, proposing innovative solutions and delivering end-to-end features with ownership and independence
Drive product stability and continual improvement of enterprise solutions in a production environment
Our requirements
Minimum 4 years of experience in Java enterprise development
Strong knowledge of Spring and Spring Boot frameworks
Practical experience with microservices architecture and basic Kubernetes knowledge
Proficiency in GIT, relational databases (Oracle/PostgreSQL), and transactional data systems
Experience with testing tools like JUnit, Spock, Testcontainers, and automated CI/CD pipelines
Familiarity with messaging systems and asynchronous integration techniques
Demonstrated ability to work autonomously with a strong ownership mindset, combined with excellent team collaboration skills
Proven track record of delivering AI-based solutions or integrating ML/LLM services
Optional
Experience with Angular 14+ for full-stack development
Hands-on experience designing AI solutions with considerations for security, compliance, and enterprise constraints
A product-oriented mindset with a good understanding of business processes
What we offer
Stable and long-term cooperation with very good conditions
Enhance your skills and develop your expertise in the financial industry
Work on the most strategic projects available in the market
Define your career roadmap and develop yourself in the best and fastest possible way by delivering strategic projects for different clients of ITDS over several years
Participate in Social Events, training, and work in an international environment
Access to attractive Medical Package
Access to Multisport Program
Access to Pluralsight
Flexible hours
Benefits
Sharing the costs of sports activities
Private medical care
Flexible working time
Fruits
Integration events
Corporate gym
Saving & investment scheme
No dress code
Coffee / tea
Drinks
Christmas gifts
Birthday celebration
Sharing the costs of a streaming platform subscription
Access to +100 projects
Access to Pluralsight
Recruitment stages
1
online interview
2
online interview
#GETREADY to meet with us!
ITDS Business Consultants is involved in many various, innovative and professional IT projects for international companies in the financial industry in Europe. We offer an environment for professional, ambitious, and driven people.
We would like to meet you. If you are interested please apply and attach your CV in English or Polish, including a statement that you agree to our processing and storing of your personal data.
ITDS’s Whistleblower Procedure
You can report violations in accordance with ITDS’s Whistleblower Procedure available here: https://itds.pl/wp-content/uploads/2025/03/INFORMATION-ON-PROCEDURE-FOR-REPORTING-BREACHES-AND-PROTECTION-OF-WHISTLEBLOWERS-AT-ITDS-POLSKA.pdf
ITDS Polska Sp. z o.o.
Scroll to company's profile
ITDS supports financial service providers to take the next steps.
We identify what’s possible, every day. Opportunities in the areas of technology, organization, and digitization.
We see where banks, insurers, payment companies, or fintech can go and how they can get there.
That’s why we want to stimulate you to ramp up your ambition. Forget what you perceive as restraints and step towards the new reality.
ITDS in Poland - Pure player in new Technologies & Financial Industry
+300 IT implementation professionals
+20 clients in the Banking, Insurance, Payment & Fintech Industry
ITDS excels in digital strategy delivery and implementation of best-of-breed lending solutions.
10060
Aplikuj
Zapisz
Drukuj
Udostępnij
Informujemy, że administratorem danych jest ITDS z siedzibą w Warszawie. Masz prawo do żądania dostępu do swoich danych osobowych, ich sprostowania, usunięcia lub ograniczenia przetwarzania.
Pełną informację odnośnie przetwarzania Twoich danych osobowych znajdziesz tutaj.
Praca
Warszawa
IT - Administracja
Administrowanie systemami
Aplikuj
Zapisz
Drukuj
Udostępnij
Sprawdź podobne oferty:
Superoferta
Senior Java Microservices Developer – Banking Technology
ITDS Polska Sp. z o.o.
18 900–23 100 zł netto (+ VAT) / mies.
Warszawa
Projektant Programista / Projektantka Programistka
Compensa Towarzystwo Ubezpieczeń S.A. Vienna Insurance Group
Warszawa, Ochota
Superoferta
Fullstack Java Developer (k/m/n)
Nexio Management Sp. z o.o.
Warszawa
Superoferta
Java Developer Hit!
Team Connect Sp. z o.o.
130–145 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Senior Software Engineer (Python/AI)
SQUARE ONE RESOURCES sp. z o.o.
140–160 zł netto (+ VAT) / godz.
Warszawa
Superoferta
Senior Fullstack Developer Java with Angular (f/m/x)
Sii Sp. z o.o.
Warszawa, Mokotów
Superoferta
Java Developer – Microservices and Cloud Infrastructure
ITDS Polska Sp. z o.o.
22 000–30 000 zł netto (+ VAT) / mies.
Warszawa
Pokaż więcej podobnych
16
Włącz powiadomienie
Senior Java Developer – AI Integration and Microservices, Warszawa
Dla kandydatów
Pomoc
Pracuj w Grupie Pracuj
Festiwal Pracy
Porady zawodowe
Zarobki
Blog IT
Słownik pojęć IT
Narzędzia
Kreator CV
Kalkulator wynagrodzeń
Kalkulator godzinowy
Kalkulator VAT
Kalkulator urlopu macierzyńskiego
Kalkulator podróży służbowej
Kalkulator ekwiwalentu za urlop
Dla firm
Dodaj ogłoszenie
Konto pracodawcy
Pomoc dla firm
Porady dla firm
Porady rekrutacyjne
Słownik biznesowy HR
Kalkulator kosztów pracodawcy
Blog Wyzwania HR
Grupa Pracuj
O nas
Centrum Prasowe
Reklama
Partnerzy
Nasze produkty
Regulamin
Polityka Prywatności
Polityka plików cookies
Akt o usługach cyfrowych
Ustawienia plików cookies
© Grupa Pracuj S.A.